import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';

// Import routes
import authRoutes from './routes/auth';
import eventsRoutes from './routes/events';
import incidentsRoutes from './routes/incidents';
import alertsRoutes from './routes/alerts';
import rulesRoutes from './routes/rules';
import intelRoutes from './routes/intel';
import forensicsRoutes from './routes/forensics';
import usersRoutes from './routes/users';
import dashboardRoutes from './routes/dashboard';

// Import middleware
import { authMiddleware } from './middleware/auth';
import { tenantMiddleware } from './middleware/tenant';
import { auditMiddleware } from './middleware/audit';
import { errorHandler } from './middleware/errorHandler';

// Import services
import { IngestionService } from './services/ingestion';
import { DetectionEngine } from './services/detection';
import { NotificationService } from './services/notifications';
import { ThreatIntelService } from './services/threatIntel';

const app = express();
const server = createServer(app);
const io = new SocketIOServer(server, {
  cors: {
    origin: process.env.FRONTEND_URL || "http://localhost:3000",
    methods: ["GET", "POST"]
  }
});

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "ws:", "wss:"],
    },
  },
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // Limit each IP to 1000 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// CORS configuration
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:3000",
  credentials: true
}));

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(`${req.method} ${req.path} - ${res.statusCode} - ${duration}ms`);
  });
  next();
});

// Initialize services
const ingestionService = new IngestionService();
const detectionEngine = new DetectionEngine();
const notificationService = new NotificationService(io);
const threatIntelService = new ThreatIntelService();

// Make services available globally
app.set('ingestionService', ingestionService);
app.set('detectionEngine', detectionEngine);
app.set('notificationService', notificationService);
app.set('threatIntelService', threatIntelService);
app.set('io', io);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: process.env.APP_VERSION || '2.4.0',
    services: {
      ingestion: ingestionService.getStatus(),
      detection: detectionEngine.getStatus(),
      notifications: notificationService.getStatus(),
      threatIntel: threatIntelService.getStatus()
    }
  });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/events', authMiddleware, tenantMiddleware, auditMiddleware, eventsRoutes);
app.use('/api/incidents', authMiddleware, tenantMiddleware, auditMiddleware, incidentsRoutes);
app.use('/api/alerts', authMiddleware, tenantMiddleware, auditMiddleware, alertsRoutes);
app.use('/api/rules', authMiddleware, tenantMiddleware, auditMiddleware, rulesRoutes);
app.use('/api/intel', authMiddleware, tenantMiddleware, auditMiddleware, intelRoutes);
app.use('/api/forensics', authMiddleware, tenantMiddleware, auditMiddleware, forensicsRoutes);
app.use('/api/users', authMiddleware, tenantMiddleware, auditMiddleware, usersRoutes);
app.use('/api/dashboard', authMiddleware, tenantMiddleware, dashboardRoutes);

// WebSocket connection handling
io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);
  
  // Join tenant-specific room
  socket.on('join-tenant', (tenantId: string) => {
    socket.join(`tenant-${tenantId}`);
    console.log(`Client ${socket.id} joined tenant ${tenantId}`);
  });
  
  // Join role-specific room for targeted notifications
  socket.on('join-role', (role: string) => {
    socket.join(`role-${role}`);
    console.log(`Client ${socket.id} joined role ${role}`);
  });
  
  // Handle real-time subscriptions
  socket.on('subscribe-events', (filters: any) => {
    socket.join(`events-${JSON.stringify(filters)}`);
    console.log(`Client ${socket.id} subscribed to events with filters:`, filters);
  });
  
  socket.on('subscribe-alerts', (severity: string) => {
    socket.join(`alerts-${severity}`);
    console.log(`Client ${socket.id} subscribed to ${severity} alerts`);
  });
  
  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`);
  });
});

// Data ingestion endpoint (for agents and collectors)
app.post('/api/ingest', async (req, res) => {
  try {
    const events = Array.isArray(req.body) ? req.body : [req.body];
    const tenantId = req.headers['x-tenant-id'] as string;
    const apiKey = req.headers['x-api-key'] as string;
    
    if (!tenantId || !apiKey) {
      return res.status(401).json({ error: 'Missing tenant ID or API key' });
    }
    
    // Validate API key (in production, this would be a proper authentication check)
    const isValidKey = await ingestionService.validateApiKey(tenantId, apiKey);
    if (!isValidKey) {
      return res.status(401).json({ error: 'Invalid API key' });
    }
    
    // Process events through the ingestion pipeline
    const results = await ingestionService.processEvents(events, tenantId);
    
    res.json({
      status: 'success',
      processed: results.processed,
      errors: results.errors,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Ingestion error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Threat intelligence ingestion
app.post('/api/intel/ingest', async (req, res) => {
  try {
    const intel = req.body;
    const tenantId = req.headers['x-tenant-id'] as string;
    const apiKey = req.headers['x-api-key'] as string;
    
    if (!tenantId || !apiKey) {
      return res.status(401).json({ error: 'Missing tenant ID or API key' });
    }
    
    const result = await threatIntelService.ingestIntel(intel, tenantId);
    
    res.json({
      status: 'success',
      id: result.id,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Intel ingestion error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Bulk data export endpoint
app.post('/api/export', authMiddleware, tenantMiddleware, async (req, res) => {
  try {
    const { query, format, filters } = req.body;
    const tenantId = req.tenant.id;
    const userId = req.user.id;
    
    // Check export permissions
    if (!req.user.permissions.includes('logs.export')) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    
    // Generate export job
    const jobId = uuidv4();
    
    // In production, this would be a background job
    // For now, return the data directly
    const data = await ingestionService.exportData(tenantId, query, filters);
    
    res.json({
      jobId,
      status: 'completed',
      data,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Export error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Error handling
app.use(errorHandler);

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

const PORT = process.env.PORT || 3001;

server.listen(PORT, () => {
  console.log(`🚀 AURA NEXUS SOC OS Backend Server running on port ${PORT}`);
  console.log(`📡 WebSocket server ready for real-time connections`);
  console.log(`🔐 Security middleware enabled`);
  console.log(`📊 Ingestion pipeline active`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

export default app;
