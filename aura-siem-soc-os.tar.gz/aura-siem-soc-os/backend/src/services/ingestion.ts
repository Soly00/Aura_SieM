import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { SecurityEvent } from '../types/detection';

export interface IngestionResult {
  processed: number;
  errors: number;
  events: string[];
  errorDetails: any[];
}

export interface DataSource {
  id: string;
  name: string;
  type: 'syslog' | 'windows_event' | 'api' | 'file' | 'stream';
  status: 'active' | 'inactive' | 'error';
  configuration: any;
  lastIngestion?: Date;
  eventsIngested: number;
  rateLimit?: number;
}

export interface NormalizedEvent extends SecurityEvent {
  tenantId: string;
  ingestionTime: Date;
  dataSource: string;
  fingerprint: string;
  duplicate: boolean;
}

export class IngestionService extends EventEmitter {
  private dataSources: Map<string, DataSource> = new Map();
  private eventBuffer: Map<string, NormalizedEvent[]> = new Map();
  private processingQueue: NormalizedEvent[] = [];
  private isProcessing: boolean = false;
  private rateLimiters: Map<string, any> = new Map();
  private deduplicationCache: Map<string, Date> = new Map();

  constructor() {
    super();
    this.initializeDefaultSources();
    this.startProcessing();
  }

  // Initialize default data sources
  private initializeDefaultSources() {
    const defaultSources: DataSource[] = [
      {
        id: 'windows-events',
        name: 'Windows Event Log Collector',
        type: 'windows_event',
        status: 'active',
        configuration: {
          channels: ['Security', 'System', 'Application'],
          eventIds: [4624, 4625, 4648, 4720, 4728, 4732],
          maxBatchSize: 1000
        },
        eventsIngested: 0,
        rateLimit: 10000 // events per minute
      },
      {
        id: 'syslog-collector',
        name: 'Linux Syslog Collector',
        type: 'syslog',
        status: 'active',
        configuration: {
          facilities: ['auth', 'authpriv', 'daemon', 'kern'],
          severities: ['err', 'warning', 'notice', 'info'],
          port: 514,
          protocol: 'UDP'
        },
        eventsIngested: 0,
        rateLimit: 5000
      },
      {
        id: 'api-ingest',
        name: 'REST API Ingestion',
        type: 'api',
        status: 'active',
        configuration: {
          endpoints: ['/api/ingest', '/api/events'],
          authentication: 'api_key',
          maxPayloadSize: '10MB'
        },
        eventsIngested: 0,
        rateLimit: 15000
      },
      {
        id: 'file-watcher',
        name: 'File System Watcher',
        type: 'file',
        status: 'active',
        configuration: {
          watchPaths: ['/var/log/', '/logs/'],
          filePatterns: ['*.log', '*.json'],
          recursive: true
        },
        eventsIngested: 0,
        rateLimit: 2000
      },
      {
        id: 'stream-processor',
        name: 'Real-time Stream Processor',
        type: 'stream',
        status: 'active',
        configuration: {
          protocols: ['tcp', 'udp'],
          ports: [9999, 10000],
          bufferSize: 10000,
          batchSize: 100
        },
        eventsIngested: 0,
        rateLimit: 20000
      }
    ];

    defaultSources.forEach(source => {
      this.dataSources.set(source.id, source);
      this.eventBuffer.set(source.id, []);
    });

    console.log(`📡 Initialized ${defaultSources.length} data sources`);
  }

  // Main ingestion endpoint
  async processEvents(events: any[], tenantId: string): Promise<IngestionResult> {
    const result: IngestionResult = {
      processed: 0,
      errors: 0,
      events: [],
      errorDetails: []
    };

    try {
      // Process each event through the pipeline
      for (const rawEvent of events) {
        try {
          const normalizedEvent = await this.normalizeEvent(rawEvent, tenantId);
          
          // Check for duplicates
          if (this.isDuplicate(normalizedEvent)) {
            normalizedEvent.duplicate = true;
            continue;
          }

          // Add to processing queue
          this.processingQueue.push(normalizedEvent);
          result.processed++;
          result.events.push(normalizedEvent.id);

          // Update deduplication cache
          this.deduplicationCache.set(normalizedEvent.fingerprint, new Date());

        } catch (error) {
          result.errors++;
          result.errorDetails.push({
            event: rawEvent,
            error: error.message,
            timestamp: new Date().toISOString()
          });
        }
      }

      // Trigger processing if not already running
      if (!this.isProcessing) {
        this.processQueue();
      }

      // Emit ingestion event
      this.emit('ingestion', {
        tenantId,
        result,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      console.error('Ingestion error:', error);
      throw error;
    }

    return result;
  }

  // Normalize raw event to standard format
  private async normalizeEvent(rawEvent: any, tenantId: string): Promise<NormalizedEvent> {
    const normalizedEvent: NormalizedEvent = {
      id: uuidv4(),
      tenantId,
      ingestionTime: new Date(),
      dataSource: this.detectDataSource(rawEvent),
      fingerprint: this.generateFingerprint(rawEvent),
      duplicate: false,
      timestamp: this.extractTimestamp(rawEvent),
      event_type: this.extractEventType(rawEvent),
      source: this.extractSource(rawEvent),
      source_ip: this.extractSourceIP(rawEvent),
      destination_ip: this.extractDestinationIP(rawEvent),
      user: this.extractUser(rawEvent),
      hostname: this.extractHostname(rawEvent),
      process_name: this.extractProcessName(rawEvent),
      command_line: this.extractCommandLine(rawEvent),
      details: this.extractDetails(rawEvent),
      severity: this.extractSeverity(rawEvent),
      category: this.extractCategory(rawEvent),
      raw_log: JSON.stringify(rawEvent),
      normalized_data: this.extractNormalizedData(rawEvent),
      tags: this.extractTags(rawEvent),
      status: 'new'
    };

    return normalizedEvent;
  }

  // Detect data source type from event
  private detectDataSource(rawEvent: any): string {
    if (rawEvent.EventID || rawEvent.EventData) {
      return 'windows-events';
    }
    if (rawEvent.facility || rawEvent.severity) {
      return 'syslog-collector';
    }
    if (rawEvent.source_type === 'api') {
      return 'api-ingest';
    }
    if (rawEvent.file_path) {
      return 'file-watcher';
    }
    return 'stream-processor';
  }

  // Generate unique fingerprint for deduplication
  private generateFingerprint(rawEvent: any): string {
    const keyFields = [
      this.extractTimestamp(rawEvent),
      this.extractEventType(rawEvent),
      this.extractSource(rawEvent),
      this.extractUser(rawEvent),
      this.extractSourceIP(rawEvent)
    ].filter(Boolean).join('|');

    // Simple hash function (in production, use a proper hash)
    let hash = 0;
    for (let i = 0; i < keyFields.length; i++) {
      const char = keyFields.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(16);
  }

  // Check if event is duplicate
  private isDuplicate(event: NormalizedEvent): boolean {
    const cached = this.deduplicationCache.get(event.fingerprint);
    if (!cached) return false;

    // Consider duplicate if seen within last 5 minutes
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
    return cached > fiveMinutesAgo;
  }

  // Extract timestamp from various formats
  private extractTimestamp(rawEvent: any): string {
    if (rawEvent.timestamp) return rawEvent.timestamp;
    if (rawEvent.TimeGenerated) return rawEvent.TimeGenerated;
    if (rawEvent.@timestamp) return rawEvent.@timestamp;
    if (rawEvent.time) return rawEvent.time;
    if (rawEvent.date) return rawEvent.date;
    
    // Default to current time
    return new Date().toISOString();
  }

  // Extract event type
  private extractEventType(rawEvent: any): string {
    if (rawEvent.event_type) return rawEvent.event_type;
    if (rawEvent.EventID) {
      const eventMap: { [key: number]: string } = {
        4624: 'login',
        4625: 'login',
        4648: 'login',
        4720: 'user_account',
        4728: 'group_account',
        4732: 'group_account',
        4688: 'process',
        4663: 'file',
        5140: 'network',
        5156: 'network'
      };
      return eventMap[rawEvent.EventID] || 'unknown';
    }
    if (rawEvent.syslog_tag) return rawEvent.syslog_tag;
    if (rawEvent.type) return rawEvent.type;
    
    return 'unknown';
  }

  // Extract source
  private extractSource(rawEvent: any): string {
    if (rawEvent.source) return rawEvent.source;
    if (rawEvent.Computer) return rawEvent.Computer;
    if (rawEvent.host) return rawEvent.host;
    if (rawEvent.hostname) return rawEvent.hostname;
    if (rawEvent.source_name) return rawEvent.source_name;
    
    return 'unknown';
  }

  // Extract source IP
  private extractSourceIP(rawEvent: any): string | undefined {
    if (rawEvent.source_ip) return rawEvent.source_ip;
    if (rawEvent.ip_address) return rawEvent.ip_address;
    if (rawEvent.Address) return rawEvent.Address;
    if (rawEvent.client_ip) return rawEvent.client_ip;
    if (rawEvent.remote_addr) return rawEvent.remote_addr;
    
    return undefined;
  }

  // Extract destination IP
  private extractDestinationIP(rawEvent: any): string | undefined {
    if (rawEvent.destination_ip) return rawEvent.destination_ip;
    if (rawEvent.dest_ip) return rawEvent.dest_ip;
    if (rawEvent.DestAddress) return rawEvent.DestAddress;
    if (rawEvent.server_ip) return rawEvent.server_ip;
    
    return undefined;
  }

  // Extract user
  private extractUser(rawEvent: any): string | undefined {
    if (rawEvent.user) return rawEvent.user;
    if (rawEvent.username) return rawEvent.username;
    if (rawEvent.User) return rawEvent.User;
    if (rawEvent.account) return rawEvent.account;
    if (rawEvent.uid) return rawEvent.uid;
    
    return undefined;
  }

  // Extract hostname
  private extractHostname(rawEvent: any): string | undefined {
    if (rawEvent.hostname) return rawEvent.hostname;
    if (rawEvent.host) return rawEvent.host;
    if (rawEvent.Computer) return rawEvent.Computer;
    if (rawEvent.server) return rawEvent.server;
    
    return undefined;
  }

  // Extract process name
  private extractProcessName(rawEvent: any): string | undefined {
    if (rawEvent.process_name) return rawEvent.process_name;
    if (rawEvent.ProcessName) return rawEvent.ProcessName;
    if (rawEvent.process) return rawEvent.process;
    if (rawEvent.executable) return rawEvent.executable;
    
    return undefined;
  }

  // Extract command line
  private extractCommandLine(rawEvent: any): string | undefined {
    if (rawEvent.command_line) return rawEvent.command_line;
    if (rawEvent.CommandLine) return rawEvent.CommandLine;
    if (rawEvent.cmd) return rawEvent.cmd;
    if (rawEvent.command) return rawEvent.command;
    
    return undefined;
  }

  // Extract details
  private extractDetails(rawEvent: any): string {
    if (rawEvent.details) return rawEvent.details;
    if (rawEvent.Message) return rawEvent.Message;
    if (rawEvent.message) return rawEvent.message;
    if (rawEvent.msg) return rawEvent.msg;
    if (rawEvent.description) return rawEvent.description;
    
    // Fallback to stringified event
    return JSON.stringify(rawEvent);
  }

  // Extract severity
  private extractSeverity(rawEvent: any): 'low' | 'medium' | 'high' | 'critical' {
    if (rawEvent.severity) {
      const severity = rawEvent.severity.toLowerCase();
      if (severity.includes('crit')) return 'critical';
      if (severity.includes('high')) return 'high';
      if (severity.includes('med')) return 'medium';
      if (severity.includes('low')) return 'low';
    }
    
    if (rawEvent.Level === 'Error' || rawEvent.Level === 'Critical') return 'high';
    if (rawEvent.Level === 'Warning') return 'medium';
    if (rawEvent.severity === 'err') return 'high';
    if (rawEvent.severity === 'warning') return 'medium';
    
    // Default severity based on event type
    const eventType = this.extractEventType(rawEvent);
    if (eventType === 'login' && rawEvent.status === 'failed') return 'medium';
    if (eventType === 'process') return 'low';
    if (eventType === 'network') return 'medium';
    
    return 'low';
  }

  // Extract category
  private extractCategory(rawEvent: any): string {
    if (rawEvent.category) return rawEvent.category;
    if (rawEvent.Category) return rawEvent.Category;
    if (rawEvent.channel) return rawEvent.channel;
    
    const eventType = this.extractEventType(rawEvent);
    const categoryMap: { [key: string]: string } = {
      login: 'Authentication',
      user_account: 'Identity Management',
      group_account: 'Identity Management',
      process: 'Process',
      file: 'File System',
      network: 'Network',
      registry: 'Registry',
      powershell: 'PowerShell'
    };
    
    return categoryMap[eventType] || 'General';
  }

  // Extract normalized data
  private extractNormalizedData(rawEvent: any): any {
    // Extract key fields for search and analysis
    return {
      event_id: rawEvent.EventID || rawEvent.id,
      log_name: rawEvent.Channel || rawEvent.logname,
      level: rawEvent.Level || rawEvent.level,
      keywords: this.extractKeywords(rawEvent),
      entities: this.extractEntities(rawEvent),
      indicators: this.extractIndicators(rawEvent)
    };
  }

  // Extract keywords for search
  private extractKeywords(rawEvent: any): string[] {
    const text = JSON.stringify(rawEvent).toLowerCase();
    const keywords: string[] = [];
    
    // Security-related keywords
    const securityKeywords = [
      'login', 'failed', 'success', 'password', 'admin', 'root',
      'malware', 'virus', 'trojan', 'backdoor', 'exploit',
      'attack', 'breach', 'intrusion', 'unauthorized'
    ];
    
    securityKeywords.forEach(keyword => {
      if (text.includes(keyword)) {
        keywords.push(keyword);
      }
    });
    
    return keywords;
  }

  // Extract entities (IPs, domains, emails, etc.)
  private extractEntities(rawEvent: any): any {
    const entities: any = {};
    
    // IP addresses
    const ipRegex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/g;
    const ips = JSON.stringify(rawEvent).match(ipRegex) || [];
    entities.ip_addresses = ips;
    
    // Email addresses
    const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
    const emails = JSON.stringify(rawEvent).match(emailRegex) || [];
    entities.emails = emails;
    
    // Domains
    const domainRegex = /\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b/g;
    const domains = JSON.stringify(rawEvent).match(domainRegex) || [];
    entities.domains = domains;
    
    return entities;
  }

  // Extract security indicators
  private extractIndicators(rawEvent: any): any {
    const indicators: any = {};
    
    // File hashes
    const hashRegex = /\b[a-fA-F0-9]{32,64}\b/g;
    const hashes = JSON.stringify(rawEvent).match(hashRegex) || [];
    indicators.hashes = hashes;
    
    // URLs
    const urlRegex = /https?:\/\/[^\s<>"{}|\\^`[\]]+/g;
    const urls = JSON.stringify(rawEvent).match(urlRegex) || [];
    indicators.urls = urls;
    
    return indicators;
  }

  // Extract tags
  private extractTags(rawEvent: any): string[] {
    const tags: string[] = [];
    
    if (rawEvent.tags) {
      tags.push(...rawEvent.tags);
    }
    
    // Auto-generate tags based on content
    const text = JSON.stringify(rawEvent).toLowerCase();
    
    if (text.includes('admin')) tags.push('privileged');
    if (text.includes('failed')) tags.push('failure');
    if (text.includes('error')) tags.push('error');
    if (text.includes('critical')) tags.push('critical');
    if (text.includes('suspicious')) tags.push('suspicious');
    
    return [...new Set(tags)]; // Remove duplicates
  }

  // Process events from queue
  private async processQueue(): Promise<void> {
    if (this.isProcessing) return;
    
    this.isProcessing = true;
    
    try {
      while (this.processingQueue.length > 0) {
        const batch = this.processingQueue.splice(0, 100); // Process in batches
        
        // Emit batch for detection engine
        this.emit('events-batch', batch);
        
        // Update data source statistics
        batch.forEach(event => {
          const source = this.dataSources.get(event.dataSource);
          if (source) {
            source.eventsIngested++;
            source.lastIngestion = new Date();
          }
        });
        
        // Small delay to prevent overwhelming
        await new Promise(resolve => setTimeout(resolve, 10));
      }
    } catch (error) {
      console.error('Error processing queue:', error);
    } finally {
      this.isProcessing = false;
    }
  }

  // Start background processing
  private startProcessing(): void {
    setInterval(() => {
      if (!this.isProcessing && this.processingQueue.length > 0) {
        this.processQueue();
      }
    }, 1000); // Check every second
    
    // Clean up old deduplication cache entries
    setInterval(() => {
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
      for (const [key, value] of this.deduplicationCache.entries()) {
        if (value < oneHourAgo) {
          this.deduplicationCache.delete(key);
        }
      }
    }, 10 * 60 * 1000); // Clean every 10 minutes
  }

  // Validate API key
  async validateApiKey(tenantId: string, apiKey: string): Promise<boolean> {
    // In production, this would validate against a database
    // For demonstration, accept any non-empty API key
    return apiKey && apiKey.length > 10;
  }

  // Export data for analysis
  async exportData(tenantId: string, query: any, filters: any): Promise<any[]> {
    // In production, this would query the database
    // For demonstration, return mock data
    return [];
  }

  // Add new data source
  addDataSource(source: DataSource): void {
    this.dataSources.set(source.id, source);
    this.eventBuffer.set(source.id, []);
    console.log(`➕ Added data source: ${source.name}`);
  }

  // Remove data source
  removeDataSource(sourceId: string): boolean {
    const deleted = this.dataSources.delete(sourceId);
    this.eventBuffer.delete(sourceId);
    if (deleted) {
      console.log(`➖ Removed data source: ${sourceId}`);
    }
    return deleted;
  }

  // Get all data sources
  getDataSources(): DataSource[] {
    return Array.from(this.dataSources.values());
  }

  // Get data source by ID
  getDataSource(sourceId: string): DataSource | undefined {
    return this.dataSources.get(sourceId);
  }

  // Get ingestion statistics
  getStatistics(): any {
    const sources = Array.from(this.dataSources.values());
    const totalEvents = sources.reduce((sum, source) => sum + source.eventsIngested, 0);
    const activeSources = sources.filter(source => source.status === 'active').length;
    
    return {
      totalEvents,
      activeSources,
      totalSources: sources.length,
      queueSize: this.processingQueue.length,
      cacheSize: this.deduplicationCache.size,
      isProcessing: this.isProcessing,
      uptime: process.uptime()
    };
  }

  // Get service status
  getStatus(): any {
    return {
      running: true,
      statistics: this.getStatistics(),
      dataSources: this.getDataSources().map(s => ({
        id: s.id,
        name: s.name,
        status: s.status,
        eventsIngested: s.eventsIngested,
        lastIngestion: s.lastIngestion
      }))
    };
  }
}
