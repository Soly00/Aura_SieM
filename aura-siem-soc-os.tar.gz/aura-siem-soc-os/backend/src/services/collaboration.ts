import { EventEmitter } from 'events';

export interface User {
  id: string;
  username: string;
  fullName: string;
  role: string;
  status: 'online' | 'offline' | 'away' | 'busy';
  lastSeen: Date;
  avatar?: string;
  permissions: string[];
}

export interface Incident {
  id: string;
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'investigating' | 'resolved' | 'closed';
  assignedTo?: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
  tags: string[];
  attachments: string[];
}

export interface Comment {
  id: string;
  incidentId: string;
  userId: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  mentions: string[];
  attachments: string[];
  reactions: Reaction[];
}

export interface Reaction {
  id: string;
  emoji: string;
  userId: string;
  createdAt: Date;
}

export interface Task {
  id: string;
  incidentId: string;
  title: string;
  description: string;
  assignedTo?: string;
  createdBy: string;
  status: 'todo' | 'in_progress' | 'completed' | 'blocked';
  priority: 'low' | 'medium' | 'high' | 'critical';
  dueDate?: Date;
  createdAt: Date;
  updatedAt: Date;
  dependencies: string[];
}

export interface Activity {
  id: string;
  type: 'comment' | 'task' | 'status_change' | 'assignment' | 'file_upload';
  userId: string;
  incidentId: string;
  description: string;
  metadata: any;
  createdAt: Date;
}

export class CollaborationService extends EventEmitter {
  private users: Map<string, User> = new Map();
  private incidents: Map<string, Incident> = new Map();
  private comments: Map<string, Comment[]> = new Map();
  private tasks: Map<string, Task[]> = new Map();
  private activities: Map<string, Activity[]> = new Map();
  private isRunning: boolean = false;

  constructor() {
    super();
    this.initializeMockData();
    this.start();
  }

  // Initialize mock data for demonstration
  private initializeMockData() {
    // Mock users
    const mockUsers: User[] = [
      {
        id: 'user-001',
        username: 'jsmith',
        fullName: 'John Smith',
        role: 'Tier 2 Analyst',
        status: 'online',
        lastSeen: new Date(),
        permissions: ['read', 'write', 'assign']
      },
      {
        id: 'user-002',
        username: 'jdoe',
        fullName: 'Jane Doe',
        role: 'Tier 1 Analyst',
        status: 'online',
        lastSeen: new Date(),
        permissions: ['read', 'write']
      },
      {
        id: 'user-003',
        username: 'mwilson',
        fullName: 'Mike Wilson',
        role: 'SOC Manager',
        status: 'away',
        lastSeen: new Date(Date.now() - 15 * 60 * 1000),
        permissions: ['read', 'write', 'assign', 'manage']
      },
      {
        id: 'user-004',
        username: 'sforensic',
        fullName: 'Sarah Forensic',
        role: 'Forensic Analyst',
        status: 'busy',
        lastSeen: new Date(),
        permissions: ['read', 'write', 'forensics']
      }
    ];

    mockUsers.forEach(user => {
      this.users.set(user.id, user);
    });

    // Mock incidents
    const mockIncidents: Incident[] = [
      {
        id: 'incident-001',
        title: 'Suspicious PowerShell Activity on DC-01',
        description: 'Multiple suspicious PowerShell commands detected on domain controller, potential lateral movement attempt.',
        severity: 'high',
        status: 'investigating',
        assignedTo: 'user-001',
        createdBy: 'user-003',
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
        updatedAt: new Date(Date.now() - 30 * 60 * 1000),
        tags: ['powershell', 'lateral-movement', 'domain-controller'],
        attachments: ['powershell_log_001.json', 'network_capture.pcap']
      },
      {
        id: 'incident-002',
        title: 'Phishing Email Campaign - Finance Department',
        description: 'Multiple users reported phishing emails targeting finance department with credential harvesting payload.',
        severity: 'medium',
        status: 'open',
        createdBy: 'user-002',
        createdAt: new Date(Date.now() - 45 * 60 * 1000),
        updatedAt: new Date(Date.now() - 10 * 60 * 1000),
        tags: ['phishing', 'email', 'finance'],
        attachments: ['phishing_email.eml', 'malicious_attachment.pdf']
      }
    ];

    mockIncidents.forEach(incident => {
      this.incidents.set(incident.id, incident);
      this.comments.set(incident.id, []);
      this.tasks.set(incident.id, []);
      this.activities.set(incident.id, []);
    });

    console.log(`👥 Initialized collaboration service with ${mockUsers.length} users and ${mockIncidents.length} incidents`);
  }

  // User management
  async updateUserStatus(userId: string, status: User['status']): Promise<void> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error(`User ${userId} not found`);
    }

    user.status = status;
    user.lastSeen = new Date();

    this.emit('user-status-changed', { userId, status });
    console.log(`👤 User ${user.username} status changed to ${status}`);
  }

  async getUserById(userId: string): Promise<User | undefined> {
    return this.users.get(userId);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getOnlineUsers(): Promise<User[]> {
    return Array.from(this.users.values()).filter(u => u.status === 'online');
  }

  // Incident management
  async createIncident(incident: Omit<Incident, 'id' | 'createdAt' | 'updatedAt'>): Promise<Incident> {
    const newIncident: Incident = {
      ...incident,
      id: this.generateId(),
      createdAt: new Date(),
      updatedAt: new Date()
    };

    this.incidents.set(newIncident.id, newIncident);
    this.comments.set(newIncident.id, []);
    this.tasks.set(newIncident.id, []);
    this.activities.set(newIncident.id, []);

    // Add activity
    await this.addActivity({
      type: 'status_change',
      userId: incident.createdBy,
      incidentId: newIncident.id,
      description: `Created incident: ${newIncident.title}`,
      metadata: { severity: incident.severity }
    });

    this.emit('incident-created', newIncident);
    console.log(`🚨 Incident created: ${newIncident.title}`);
    return newIncident;
  }

  async updateIncident(incidentId: string, updates: Partial<Incident>): Promise<Incident> {
    const incident = this.incidents.get(incidentId);
    if (!incident) {
      throw new Error(`Incident ${incidentId} not found`);
    }

    const oldStatus = incident.status;
    Object.assign(incident, updates, { updatedAt: new Date() });

    // Add activity if status changed
    if (updates.status && updates.status !== oldStatus) {
      await this.addActivity({
        type: 'status_change',
        userId: updates.assignedTo || incident.assignedTo || incident.createdBy,
        incidentId,
        description: `Status changed from ${oldStatus} to ${updates.status}`,
        metadata: { oldStatus, newStatus: updates.status }
      });
    }

    this.emit('incident-updated', incident);
    console.log(`📝 Incident updated: ${incident.title}`);
    return incident;
  }

  async assignIncident(incidentId: string, userId: string, assignedBy: string): Promise<void> {
    const incident = this.incidents.get(incidentId);
    if (!incident) {
      throw new Error(`Incident ${incidentId} not found`);
    }

    const user = this.users.get(userId);
    if (!user) {
      throw new Error(`User ${userId} not found`);
    }

    incident.assignedTo = userId;
    incident.updatedAt = new Date();

    await this.addActivity({
      type: 'assignment',
      userId: assignedBy,
      incidentId,
      description: `Assigned to ${user.fullName}`,
      metadata: { assignedTo: userId, assignedBy }
    });

    this.emit('incident-assigned', { incidentId, userId, assignedBy });
    console.log(`👤 Incident ${incidentId} assigned to ${user.fullName}`);
  }

  async getIncidents(filters?: { status?: string; assignedTo?: string; severity?: string }): Promise<Incident[]> {
    let incidents = Array.from(this.incidents.values());

    if (filters) {
      if (filters.status) {
        incidents = incidents.filter(i => i.status === filters.status);
      }
      if (filters.assignedTo) {
        incidents = incidents.filter(i => i.assignedTo === filters.assignedTo);
      }
      if (filters.severity) {
        incidents = incidents.filter(i => i.severity === filters.severity);
      }
    }

    return incidents.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async getIncidentById(incidentId: string): Promise<Incident | undefined> {
    return this.incidents.get(incidentId);
  }

  // Comment management
  async addComment(comment: Omit<Comment, 'id' | 'createdAt' | 'updatedAt' | 'reactions'>): Promise<Comment> {
    const newComment: Comment = {
      ...comment,
      id: this.generateId(),
      createdAt: new Date(),
      updatedAt: new Date(),
      reactions: []
    };

    const comments = this.comments.get(comment.incidentId) || [];
    comments.push(newComment);
    this.comments.set(comment.incidentId, comments);

    await this.addActivity({
      type: 'comment',
      userId: comment.userId,
      incidentId: comment.incidentId,
      description: `Added comment: ${comment.content.substring(0, 100)}...`,
      metadata: { commentId: newComment.id }
    });

    this.emit('comment-added', newComment);
    console.log(`💬 Comment added to incident ${comment.incidentId}`);
    return newComment;
  }

  async updateComment(commentId: string, incidentId: string, content: string, userId: string): Promise<Comment> {
    const comments = this.comments.get(incidentId) || [];
    const comment = comments.find(c => c.id === commentId);
    
    if (!comment) {
      throw new Error(`Comment ${commentId} not found`);
    }

    if (comment.userId !== userId) {
      throw new Error('Unauthorized to edit this comment');
    }

    comment.content = content;
    comment.updatedAt = new Date();

    this.emit('comment-updated', comment);
    console.log(`✏️ Comment ${commentId} updated`);
    return comment;
  }

  async deleteComment(commentId: string, incidentId: string, userId: string): Promise<void> {
    const comments = this.comments.get(incidentId) || [];
    const commentIndex = comments.findIndex(c => c.id === commentId);
    
    if (commentIndex === -1) {
      throw new Error(`Comment ${commentId} not found`);
    }

    const comment = comments[commentIndex];
    if (comment.userId !== userId) {
      throw new Error('Unauthorized to delete this comment');
    }

    comments.splice(commentIndex, 1);
    this.comments.set(incidentId, comments);

    this.emit('comment-deleted', { commentId, incidentId });
    console.log(`🗑️ Comment ${commentId} deleted`);
  }

  async getComments(incidentId: string): Promise<Comment[]> {
    const comments = this.comments.get(incidentId) || [];
    return comments.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Reaction management
  async addReaction(commentId: string, incidentId: string, emoji: string, userId: string): Promise<void> {
    const comments = this.comments.get(incidentId) || [];
    const comment = comments.find(c => c.id === commentId);
    
    if (!comment) {
      throw new Error(`Comment ${commentId} not found`);
    }

    // Remove existing reaction by same user
    comment.reactions = comment.reactions.filter(r => r.userId !== userId);
    
    // Add new reaction
    comment.reactions.push({
      id: this.generateId(),
      emoji,
      userId,
      createdAt: new Date()
    });

    this.emit('reaction-added', { commentId, emoji, userId });
    console.log(`👍 Reaction ${emoji} added to comment ${commentId}`);
  }

  // Task management
  async createTask(task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>): Promise<Task> {
    const newTask: Task = {
      ...task,
      id: this.generateId(),
      createdAt: new Date(),
      updatedAt: new Date()
    };

    const tasks = this.tasks.get(task.incidentId) || [];
    tasks.push(newTask);
    this.tasks.set(task.incidentId, tasks);

    await this.addActivity({
      type: 'task',
      userId: task.createdBy,
      incidentId: task.incidentId,
      description: `Created task: ${task.title}`,
      metadata: { taskId: newTask.id, priority: task.priority }
    });

    this.emit('task-created', newTask);
    console.log(`📋 Task created: ${task.title}`);
    return newTask;
  }

  async updateTask(taskId: string, incidentId: string, updates: Partial<Task>, userId: string): Promise<Task> {
    const tasks = this.tasks.get(incidentId) || [];
    const task = tasks.find(t => t.id === taskId);
    
    if (!task) {
      throw new Error(`Task ${taskId} not found`);
    }

    const oldStatus = task.status;
    Object.assign(task, updates, { updatedAt: new Date() });

    // Add activity if status changed
    if (updates.status && updates.status !== oldStatus) {
      await this.addActivity({
        type: 'task',
        userId,
        incidentId,
        description: `Task "${task.title}" status changed to ${updates.status}`,
        metadata: { taskId, oldStatus, newStatus: updates.status }
      });
    }

    this.emit('task-updated', task);
    console.log(`📝 Task ${taskId} updated`);
    return task;
  }

  async getTasks(incidentId: string): Promise<Task[]> {
    const tasks = this.tasks.get(incidentId) || [];
    return tasks.sort((a, b) => {
      // Sort by priority first, then by due date
      const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
      const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
      if (priorityDiff !== 0) return priorityDiff;
      
      // Then by due date (earliest first)
      if (a.dueDate && b.dueDate) {
        return a.dueDate.getTime() - b.dueDate.getTime();
      }
      return b.createdAt.getTime() - a.createdAt.getTime();
    });
  }

  // Activity tracking
  private async addActivity(activity: Omit<Activity, 'id' | 'createdAt'>): Promise<void> {
    const newActivity: Activity = {
      ...activity,
      id: this.generateId(),
      createdAt: new Date()
    };

    const activities = this.activities.get(activity.incidentId) || [];
    activities.push(newActivity);
    this.activities.set(activity.incidentId, activities);

    this.emit('activity-added', newActivity);
  }

  async getActivities(incidentId: string, limit?: number): Promise<Activity[]> {
    const activities = this.activities.get(incidentId) || [];
    const sorted = activities.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return limit ? sorted.slice(0, limit) : sorted;
  }

  // Search functionality
  async searchIncidents(query: string, userId: string): Promise<Incident[]> {
    const user = this.users.get(userId);
    if (!user || !user.permissions.includes('read')) {
      throw new Error('Unauthorized to search incidents');
    }

    const lowerQuery = query.toLowerCase();
    const incidents = Array.from(this.incidents.values());

    return incidents.filter(incident => 
      incident.title.toLowerCase().includes(lowerQuery) ||
      incident.description.toLowerCase().includes(lowerQuery) ||
      incident.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
    );
  }

  // Start the service
  private start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;

    // Update user status based on last seen
    setInterval(() => {
      const now = new Date();
      const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);
      
      this.users.forEach(user => {
        if (user.lastSeen < fiveMinutesAgo && user.status === 'online') {
          user.status = 'offline';
          this.emit('user-status-changed', { userId: user.id, status: 'offline' });
        }
      });
    }, 60000); // Check every minute

    console.log('👥 Collaboration service started');
  }

  // Generate unique ID
  private generateId(): string {
    return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Get service statistics
  getStatistics(): any {
    const incidents = Array.from(this.incidents.values());
    const onlineUsers = Array.from(this.users.values()).filter(u => u.status === 'online');
    
    const statusCounts = incidents.reduce((acc, incident) => {
      acc[incident.status] = (acc[incident.status] || 0) + 1;
      return acc;
    }, {} as { [key: string]: number });

    const severityCounts = incidents.reduce((acc, incident) => {
      acc[incident.severity] = (acc[incident.severity] || 0) + 1;
      return acc;
    }, {} as { [key: string]: number });

    return {
      totalUsers: this.users.size,
      onlineUsers: onlineUsers.length,
      totalIncidents: incidents.length,
      statusCounts,
      severityCounts,
      isRunning: this.isRunning
    };
  }

  // Get service status
  getStatus(): any {
    return {
      running: this.isRunning,
      statistics: this.getStatistics()
    };
  }
}
