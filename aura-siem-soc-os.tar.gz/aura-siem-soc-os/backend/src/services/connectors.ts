import { EventEmitter } from 'events';
import { SecurityEvent } from '../types/detection';

export interface Connector {
  id: string;
  name: string;
  type: 'siem' | 'edr' | 'firewall' | 'cloud' | 'api' | 'syslog';
  version: string;
  status: 'active' | 'inactive' | 'error' | 'configuring';
  configuration: any;
  lastSync?: Date;
  eventsIngested: number;
  errorCount: number;
  capabilities: string[];
}

export interface ConnectorConfig {
  endpoint?: string;
  apiKey?: string;
  username?: string;
  password?: string;
  certificate?: string;
  port?: number;
  protocol?: 'tcp' | 'udp' | 'https' | 'wss';
  filters?: any;
  mapping?: any;
  rateLimit?: number;
}

export class ConnectorsService extends EventEmitter {
  private connectors: Map<string, Connector> = new Map();
  private isRunning: boolean = false;

  constructor() {
    super();
    this.initializeDefaultConnectors();
    this.start();
  }

  // Initialize default connectors
  private initializeDefaultConnectors() {
    const defaultConnectors: Connector[] = [
      {
        id: 'splunk-es',
        name: 'Splunk Enterprise Security',
        type: 'siem',
        version: '8.2.0',
        status: 'active',
        configuration: {
          endpoint: 'https://splunk.company.com:8089',
          apiKey: 'splunk_api_key_placeholder',
          index: 'security_events',
          sourcetype: 'aura_nexus'
        },
        eventsIngested: 0,
        errorCount: 0,
        capabilities: ['search', 'real-time', 'correlation', 'dashboards']
      },
      {
        id: 'crowdstrike-falcon',
        name: 'CrowdStrike Falcon',
        type: 'edr',
        version: '6.45.0',
        status: 'active',
        configuration: {
          endpoint: 'https://api.crowdstrike.com',
          apiKey: 'falcon_api_key_placeholder',
          clientId: 'falcon_client_id',
          clientSecret: 'falcon_client_secret'
        },
        eventsIngested: 0,
        errorCount: 0,
        capabilities: ['detection', 'prevention', 'forensics', 'threat-intel']
      },
      {
        id: 'palo-alto-cortex',
        name: 'Palo Alto Cortex XDR',
        type: 'edr',
        version: '3.0.0',
        status: 'active',
        configuration: {
          endpoint: 'https://api-cortex.xdr.paloaltonetworks.com',
          apiKey: 'cortex_api_key_placeholder',
          instanceId: 'cortex_instance_id'
        },
        eventsIngested: 0,
        errorCount: 0,
        capabilities: ['xdr', 'analytics', 'automation', 'integration']
      },
      {
        id: 'aws-cloudtrail',
        name: 'AWS CloudTrail',
        type: 'cloud',
        version: 'latest',
        status: 'active',
        configuration: {
          region: 'us-east-1',
          accessKeyId: 'aws_access_key_placeholder',
          secretAccessKey: 'aws_secret_key_placeholder',
          s3Bucket: 'cloudtrail-logs-bucket'
        },
        eventsIngested: 0,
        errorCount: 0,
        capabilities: ['cloud-monitoring', 'api-audit', 'compliance']
      },
      {
        id: 'azure-sentinel',
        name: 'Microsoft Azure Sentinel',
        type: 'siem',
        version: 'latest',
        status: 'active',
        configuration: {
          workspaceId: 'azure_workspace_id',
          subscriptionId: 'azure_subscription_id',
          resourceGroup: 'security-rg',
          tenantId: 'azure_tenant_id'
        },
        eventsIngested: 0,
        errorCount: 0,
        capabilities: ['siem', 'soar', 'threat-intel', 'automation']
      },
      {
        id: 'microsoft-defender',
        name: 'Microsoft Defender for Endpoint',
        type: 'edr',
        version: 'latest',
        status: 'active',
        configuration: {
          endpoint: 'https://api.security.microsoft.com',
          apiKey: 'defender_api_key_placeholder',
          tenantId: 'microsoft_tenant_id'
        },
        eventsIngested: 0,
        errorCount: 0,
        capabilities: ['edr', 'threat-protection', 'vulnerability-management']
      },
      {
        id: 'fortinet-fortigate',
        name: 'Fortinet FortiGate',
        type: 'firewall',
        version: '7.0.0',
        status: 'active',
        configuration: {
          endpoint: 'https://firewall.company.com',
          apiKey: 'fortigate_api_key_placeholder',
          port: 443,
          protocol: 'https'
        },
        eventsIngested: 0,
        errorCount: 0,
        capabilities: ['firewall', 'vpn', 'web-filter', 'ips']
      },
      {
        id: 'syslog-ng',
        name: 'Syslog-NG Collector',
        type: 'syslog',
        version: '4.0.0',
        status: 'active',
        configuration: {
          port: 514,
          protocol: 'udp',
          format: 'rfc5424',
          filters: {
            facilities: ['auth', 'authpriv', 'daemon', 'kern'],
            severities: ['err', 'warning', 'notice', 'info', 'crit']
          }
        },
        eventsIngested: 0,
        errorCount: 0,
        capabilities: ['log-collection', 'parsing', 'filtering']
      }
    ];

    defaultConnectors.forEach(connector => {
      this.connectors.set(connector.id, connector);
    });

    console.log(`🔌 Initialized ${defaultConnectors.length} connectors`);
  }

  // Test connector connection
  async testConnection(connectorId: string): Promise<boolean> {
    const connector = this.connectors.get(connectorId);
    if (!connector) {
      throw new Error(`Connector ${connectorId} not found`);
    }

    try {
      // Simulate connection test
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Random success/failure for demonstration
      const success = Math.random() > 0.2;
      
      if (success) {
        connector.status = 'active';
        connector.errorCount = 0;
        console.log(`✅ Connection test successful for ${connector.name}`);
      } else {
        connector.status = 'error';
        connector.errorCount += 1;
        console.log(`❌ Connection test failed for ${connector.name}`);
      }

      this.emit('connection-test', { connectorId, success });
      return success;

    } catch (error) {
      connector.status = 'error';
      connector.errorCount += 1;
      console.error(`❌ Connection test error for ${connector.name}:`, error);
      return false;
    }
  }

  // Configure connector
  async configureConnector(connectorId: string, config: ConnectorConfig): Promise<boolean> {
    const connector = this.connectors.get(connectorId);
    if (!connector) {
      throw new Error(`Connector ${connectorId} not found`);
    }

    try {
      connector.configuration = { ...connector.configuration, ...config };
      connector.status = 'configuring';

      // Validate configuration
      const isValid = await this.validateConfiguration(connector);
      
      if (isValid) {
        connector.status = 'active';
        console.log(`✅ Connector ${connector.name} configured successfully`);
        this.emit('connector-configured', { connectorId, config });
        return true;
      } else {
        connector.status = 'error';
        console.log(`❌ Invalid configuration for ${connector.name}`);
        return false;
      }

    } catch (error) {
      connector.status = 'error';
      console.error(`❌ Configuration error for ${connector.name}:`, error);
      return false;
    }
  }

  // Validate connector configuration
  private async validateConfiguration(connector: Connector): Promise<boolean> {
    const { configuration } = connector;

    // Basic validation based on connector type
    switch (connector.type) {
      case 'siem':
      case 'edr':
      case 'firewall':
        return !!(configuration.endpoint && configuration.apiKey);
      
      case 'cloud':
        return !!(configuration.accessKeyId && configuration.secretAccessKey);
      
      case 'syslog':
        return !!(configuration.port && configuration.protocol);
      
      case 'api':
        return !!(configuration.endpoint);
      
      default:
        return true;
    }
  }

  // Ingest events from connector
  async ingestFromConnector(connectorId: string, events: any[]): Promise<number> {
    const connector = this.connectors.get(connectorId);
    if (!connector) {
      throw new Error(`Connector ${connectorId} not found`);
    }

    if (connector.status !== 'active') {
      throw new Error(`Connector ${connector.name} is not active`);
    }

    try {
      // Transform events based on connector mapping
      const transformedEvents = await this.transformEvents(events, connector);
      
      // Update statistics
      connector.eventsIngested += transformedEvents.length;
      connector.lastSync = new Date();

      // Emit events for processing
      this.emit('events-ingested', { connectorId, events: transformedEvents });

      console.log(`📥 Ingested ${transformedEvents.length} events from ${connector.name}`);
      return transformedEvents.length;

    } catch (error) {
      connector.errorCount += 1;
      console.error(`❌ Ingestion error for ${connector.name}:`, error);
      throw error;
    }
  }

  // Transform events based on connector mapping
  private async transformEvents(events: any[], connector: Connector): Promise<SecurityEvent[]> {
    const transformedEvents: SecurityEvent[] = [];

    for (const rawEvent of events) {
      try {
        const transformed = await this.applyMapping(rawEvent, connector);
        transformedEvents.push(transformed);
      } catch (error) {
        console.warn(`⚠️ Failed to transform event from ${connector.name}:`, error);
      }
    }

    return transformedEvents;
  }

  // Apply field mapping for event transformation
  private async applyMapping(rawEvent: any, connector: Connector): Promise<SecurityEvent> {
    const mapping = connector.configuration.mapping || this.getDefaultMapping(connector.type);
    
    return {
      id: rawEvent[mapping.id] || this.generateEventId(),
      timestamp: rawEvent[mapping.timestamp] || new Date().toISOString(),
      event_type: rawEvent[mapping.event_type] || 'unknown',
      source: rawEvent[mapping.source] || connector.name,
      source_ip: rawEvent[mapping.source_ip],
      destination_ip: rawEvent[mapping.destination_ip],
      user: rawEvent[mapping.user],
      hostname: rawEvent[mapping.hostname],
      process_name: rawEvent[mapping.process_name],
      command_line: rawEvent[mapping.command_line],
      details: rawEvent[mapping.details] || JSON.stringify(rawEvent),
      severity: this.mapSeverity(rawEvent[mapping.severity]),
      category: rawEvent[mapping.category],
      raw_log: JSON.stringify(rawEvent),
      normalized_data: rawEvent,
      tags: this.extractTags(rawEvent, connector.type),
      status: 'new'
    };
  }

  // Get default field mapping for connector type
  private getDefaultMapping(connectorType: string): any {
    const mappings: { [key: string]: any } = {
      siem: {
        id: '_id',
        timestamp: '@timestamp',
        event_type: 'event_type',
        source: 'source',
        source_ip: 'src_ip',
        destination_ip: 'dest_ip',
        user: 'user',
        hostname: 'hostname',
        process_name: 'process_name',
        command_line: 'command_line',
        details: 'message',
        severity: 'severity',
        category: 'category'
      },
      edr: {
        id: 'event_id',
        timestamp: 'timestamp',
        event_type: 'event_type',
        source: 'agent_hostname',
        source_ip: 'local_ip',
        destination_ip: 'remote_ip',
        user: 'user_name',
        hostname: 'agent_hostname',
        process_name: 'process_name',
        command_line: 'cmdline',
        details: 'description',
        severity: 'severity',
        category: 'tactic_name'
      },
      firewall: {
        id: 'log_id',
        timestamp: 'time_generated',
        event_type: 'log_type',
        source: 'src_host',
        source_ip: 'src_ip',
        destination_ip: 'dst_ip',
        user: 'user',
        hostname: 'src_host',
        process_name: 'application',
        details: 'message',
        severity: 'severity',
        category: 'action'
      },
      cloud: {
        id: 'event_id',
        timestamp: 'eventTime',
        event_type: 'eventType',
        source: 'source',
        source_ip: 'sourceIPAddress',
        destination_ip: 'destinationIPAddress',
        user: 'userName',
        hostname: 'source',
        process_name: 'eventName',
        details: 'eventDescription',
        severity: 'severity',
        category: 'eventCategory'
      },
      syslog: {
        id: 'msgid',
        timestamp: 'timestamp',
        event_type: 'programname',
        source: 'hostname',
        source_ip: 'fromhost',
        destination_ip: 'fromhost',
        user: 'syslogtag',
        hostname: 'hostname',
        process_name: 'programname',
        details: 'msg',
        severity: 'severity',
        category: 'facility'
      }
    };

    return mappings[connectorType] || mappings.syslog;
  }

  // Map severity values
  private mapSeverity(severity: any): 'low' | 'medium' | 'high' | 'critical' {
    if (!severity) return 'medium';
    
    const sev = severity.toString().toLowerCase();
    if (sev.includes('crit') || sev.includes('high')) return 'critical';
    if (sev.includes('high') || sev.includes('error')) return 'high';
    if (sev.includes('med') || sev.includes('warn')) return 'medium';
    if (sev.includes('low') || sev.includes('info')) return 'low';
    
    return 'medium';
  }

  // Extract tags from raw event
  private extractTags(rawEvent: any, connectorType: string): string[] {
    const tags: string[] = [connectorType];
    
    // Extract common security tags
    const text = JSON.stringify(rawEvent).toLowerCase();
    
    if (text.includes('malware')) tags.push('malware');
    if (text.includes('phishing')) tags.push('phishing');
    if (text.includes('brute')) tags.push('brute-force');
    if (text.includes('suspicious')) tags.push('suspicious');
    if (text.includes('blocked')) tags.push('blocked');
    if (text.includes('allowed')) tags.push('allowed');
    
    return [...new Set(tags)];
  }

  // Start connector service
  private start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;

    // Start periodic sync for active connectors
    setInterval(async () => {
      for (const connector of this.connectors.values()) {
        if (connector.status === 'active') {
          try {
            // Simulate periodic data sync
            await this.simulateDataSync(connector);
          } catch (error) {
            console.error(`Sync error for ${connector.name}:`, error);
          }
        }
      }
    }, 30000); // Sync every 30 seconds

    console.log('🔌 Connectors service started');
  }

  // Simulate data sync for demonstration
  private async simulateDataSync(connector: Connector): Promise<void> {
    // Generate mock events for demonstration
    const mockEvents = Array.from({ length: Math.floor(Math.random() * 10) + 1 }, () => ({
      id: this.generateEventId(),
      timestamp: new Date().toISOString(),
      event_type: 'security_event',
      source: connector.name,
      severity: ['low', 'medium', 'high', 'critical'][Math.floor(Math.random() * 4)],
      details: `Mock event from ${connector.name}`,
      category: 'security'
    }));

    await this.ingestFromConnector(connector.id, mockEvents);
  }

  // Add new connector
  addConnector(connector: Omit<Connector, 'eventsIngested' | 'errorCount'>): void {
    const fullConnector: Connector = {
      ...connector,
      eventsIngested: 0,
      errorCount: 0
    };
    
    this.connectors.set(connector.id, fullConnector);
    console.log(`➕ Added connector: ${connector.name}`);
  }

  // Remove connector
  removeConnector(connectorId: string): boolean {
    const deleted = this.connectors.delete(connectorId);
    if (deleted) {
      console.log(`➖ Removed connector: ${connectorId}`);
    }
    return deleted;
  }

  // Get all connectors
  getConnectors(): Connector[] {
    return Array.from(this.connectors.values());
  }

  // Get connector by ID
  getConnector(connectorId: string): Connector | undefined {
    return this.connectors.get(connectorId);
  }

  // Get connectors by type
  getConnectorsByType(type: string): Connector[] {
    return Array.from(this.connectors.values()).filter(c => c.type === type);
  }

  // Get statistics
  getStatistics(): any {
    const connectors = Array.from(this.connectors.values());
    const activeConnectors = connectors.filter(c => c.status === 'active').length;
    const totalEvents = connectors.reduce((sum, c) => sum + c.eventsIngested, 0);
    const totalErrors = connectors.reduce((sum, c) => sum + c.errorCount, 0);

    const typeStats: { [key: string]: number } = {};
    connectors.forEach(c => {
      typeStats[c.type] = (typeStats[c.type] || 0) + 1;
    });

    return {
      totalConnectors: connectors.length,
      activeConnectors,
      totalEvents,
      totalErrors,
      typeStats,
      isRunning: this.isRunning
    };
  }

  // Get service status
  getStatus(): any {
    return {
      running: this.isRunning,
      statistics: this.getStatistics(),
      connectors: this.getConnectors().map(c => ({
        id: c.id,
        name: c.name,
        type: c.type,
        status: c.status,
        eventsIngested: c.eventsIngested,
        errorCount: c.errorCount,
        lastSync: c.lastSync
      }))
    };
  }

  // Generate unique event ID
  private generateEventId(): string {
    return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}
