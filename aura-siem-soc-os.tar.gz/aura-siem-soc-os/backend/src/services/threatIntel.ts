import { EventEmitter } from 'events';
import { ThreatIntel } from '../types/detection';

export interface ThreatIntelSource {
  id: string;
  name: string;
  type: 'feed' | 'api' | 'file' | 'database';
  url?: string;
  apiKey?: string;
  enabled: boolean;
  lastUpdate?: Date;
  updateInterval: number; // minutes
  indicatorsCount: number;
}

export interface IntelMatch {
  indicator: string;
  type: string;
  threatIntel: ThreatIntel;
  confidence: number;
  severity: string;
}

export class ThreatIntelService extends EventEmitter {
  private sources: Map<string, ThreatIntelSource> = new Map();
  private indicators: Map<string, ThreatIntel[]> = new Map(); // Indexed by indicator
  private isRunning: boolean = false;

  constructor() {
    super();
    this.initializeDefaultSources();
    this.start();
  }

  // Initialize default threat intelligence sources
  private initializeDefaultSources() {
    const defaultSources: ThreatIntelSource[] = [
      {
        id: 'malware-ips',
        name: 'Malicious IP Feed',
        type: 'feed',
        url: 'https://feeds.malware-ips.com/feed.txt',
        enabled: true,
        updateInterval: 60,
        indicatorsCount: 0
      },
      {
        id: 'phishing-domains',
        name: 'Phishing Domains Feed',
        type: 'feed',
        url: 'https://feeds.phishtank.com/feeds/online/',
        enabled: true,
        updateInterval: 30,
        indicatorsCount: 0
      },
      {
        id: 'tor-exit-nodes',
        name: 'TOR Exit Nodes',
        type: 'feed',
        url: 'https://check.torproject.org/exit-addresses',
        enabled: true,
        updateInterval: 120,
        indicatorsCount: 0
      },
      {
        id: 'cve-database',
        name: 'CVE Vulnerability Database',
        type: 'api',
        url: 'https://cve.circl.lu/api/',
        enabled: true,
        updateInterval: 240,
        indicatorsCount: 0
      },
      {
        id: 'ransomware-register',
        name: 'Ransomware Indicators',
        type: 'api',
        url: 'https://ransomwaretracker.abuse.ch/api/',
        enabled: true,
        updateInterval: 60,
        indicatorsCount: 0
      }
    ];

    defaultSources.forEach(source => {
      this.sources.set(source.id, source);
    });

    console.log(`🌍 Initialized ${defaultSources.length} threat intelligence sources`);
  }

  // Check indicators against threat intelligence
  async checkIndicators(indicators: { ip?: string; domain?: string; hash?: string; url?: string }): Promise<IntelMatch[]> {
    const matches: IntelMatch[] = [];

    try {
      // Check IP address
      if (indicators.ip) {
        const ipMatches = this.indicators.get(indicators.ip) || [];
        ipMatches.forEach(intel => {
          matches.push({
            indicator: indicators.ip!,
            type: 'ip',
            threatIntel: intel,
            confidence: intel.confidence,
            severity: intel.severity
          });
        });
      }

      // Check domain
      if (indicators.domain) {
        const domainMatches = this.indicators.get(indicators.domain) || [];
        domainMatches.forEach(intel => {
          matches.push({
            indicator: indicators.domain!,
            type: 'domain',
            threatIntel: intel,
            confidence: intel.confidence,
            severity: intel.severity
          });
        });
      }

      // Check hash
      if (indicators.hash) {
        const hashMatches = this.indicators.get(indicators.hash) || [];
        hashMatches.forEach(intel => {
          matches.push({
            indicator: indicators.hash!,
            type: 'hash',
            threatIntel: intel,
            confidence: intel.confidence,
            severity: intel.severity
          });
        });
      }

      // Check URL
      if (indicators.url) {
        const urlMatches = this.indicators.get(indicators.url) || [];
        urlMatches.forEach(intel => {
          matches.push({
            indicator: indicators.url!,
            type: 'url',
            threatIntel: intel,
            confidence: intel.confidence,
            severity: intel.severity
          });
        });
      }

    } catch (error) {
      console.error('Error checking indicators:', error);
    }

    return matches;
  }

  // Ingest new threat intelligence
  async ingestIntel(intelData: any, tenantId: string): Promise<ThreatIntel> {
    const intel: ThreatIntel = {
      id: this.generateId(),
      indicator: intelData.indicator,
      indicatorType: intelData.type || 'ip',
      threatActor: intelData.threat_actor,
      malwareFamily: intelData.malware_family,
      confidence: intelData.confidence || 0.5,
      severity: intelData.severity || 'medium',
      firstSeen: intelData.first_seen || new Date().toISOString(),
      lastSeen: intelData.last_seen || new Date().toISOString(),
      source: intelData.source || 'manual',
      description: intelData.description,
      tags: intelData.tags || [],
      context: intelData.context || {},
      active: intelData.active !== false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Add to indicators index
    const existing = this.indicators.get(intel.indicator) || [];
    existing.push(intel);
    this.indicators.set(intel.indicator, existing);

    // Emit intel event
    this.emit('intel-ingested', intel);

    console.log(`🌍 Ingested threat intel: ${intel.indicator} (${intel.indicatorType})`);
    return intel;
  }

  // Update threat intelligence from sources
  private async updateFromSource(source: ThreatIntelService): Promise<void> {
    try {
      console.log(`🔄 Updating threat intel from ${source.name}`);
      
      // In production, this would fetch real data from the source
      const mockIndicators = this.generateMockIndicators(source.type);
      
      for (const indicatorData of mockIndicators) {
        await this.ingestIntel(indicatorData, 'system');
      }

      source.lastUpdate = new Date();
      source.indicatorsCount = mockIndicators.length;

      console.log(`✅ Updated ${source.name}: ${mockIndicators.length} indicators`);

    } catch (error) {
      console.error(`❌ Error updating ${source.name}:`, error);
    }
  }

  // Generate mock indicators for demonstration
  private generateMockIndicators(type: string): any[] {
    const indicators: any[] = [];

    switch (type) {
      case 'feed':
        // Generate mock IP addresses
        for (let i = 0; i < 50; i++) {
          indicators.push({
            indicator: `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
            type: 'ip',
            confidence: Math.random() * 0.5 + 0.5,
            severity: ['low', 'medium', 'high'][Math.floor(Math.random() * 3)],
            threat_actor: ['APT28', 'APT29', 'Lazarus', 'FIN7'][Math.floor(Math.random() * 4)],
            source: 'malware-ips'
          });
        }
        break;

      case 'api':
        // Generate mock domains
        const domains = ['malicious-site.com', 'phishing-domain.net', 'bad-actor.org'];
        for (const domain of domains) {
          indicators.push({
            indicator: domain,
            type: 'domain',
            confidence: Math.random() * 0.5 + 0.5,
            severity: 'high',
            threat_actor: 'Unknown',
            source: 'phishing-domains'
          });
        }
        break;
    }

    return indicators;
  }

  // Start background updates
  private start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;

    // Update each source on its interval
    this.sources.forEach(source => {
      if (source.enabled) {
        setInterval(() => {
          this.updateFromSource(source);
        }, source.updateInterval * 60 * 1000);
      }
    });

    console.log('🚀 Threat intelligence service started');
  }

  // Stop the service
  stop(): void {
    this.isRunning = false;
    console.log('⏹️ Threat intelligence service stopped');
  }

  // Add new source
  addSource(source: ThreatIntelSource): void {
    this.sources.set(source.id, source);
    console.log(`➕ Added threat intel source: ${source.name}`);
  }

  // Remove source
  removeSource(sourceId: string): boolean {
    const deleted = this.sources.delete(sourceId);
    if (deleted) {
      console.log(`➖ Removed threat intel source: ${sourceId}`);
    }
    return deleted;
  }

  // Get all sources
  getSources(): ThreatIntelSource[] {
    return Array.from(this.sources.values());
  }

  // Get indicators by type
  getIndicatorsByType(type: string): ThreatIntel[] {
    const allIndicators: ThreatIntel[] = [];
    
    for (const indicators of this.indicators.values()) {
      allIndicators.push(...indicators.filter(i => i.indicatorType === type));
    }
    
    return allIndicators;
  }

  // Get statistics
  getStatistics(): any {
    const totalIndicators = Array.from(this.indicators.values())
      .reduce((sum, indicators) => sum + indicators.length, 0);
    
    const activeSources = Array.from(this.sources.values())
      .filter(source => source.enabled).length;

    const indicatorCounts: { [key: string]: number } = {};
    for (const [indicator, indicators] of this.indicators.entries()) {
      const type = indicators[0]?.indicatorType || 'unknown';
      indicatorCounts[type] = (indicatorCounts[type] || 0) + 1;
    }

    return {
      totalIndicators,
      activeSources,
      totalSources: this.sources.size,
      indicatorCounts,
      isRunning: this.isRunning
    };
  }

  // Get service status
  getStatus(): any {
    return {
      running: this.isRunning,
      statistics: this.getStatistics(),
      sources: this.getSources().map(s => ({
        id: s.id,
        name: s.name,
        type: s.type,
        enabled: s.enabled,
        lastUpdate: s.lastUpdate,
        indicatorsCount: s.indicatorsCount
      }))
    };
  }

  // Generate unique ID
  private generateId(): string {
    return `intel_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}
