import { EventEmitter } from 'events';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { SecurityEvent, Alert, Incident } from '../types/detection';

export interface AIAnalysis {
  id: string;
  type: 'event' | 'alert' | 'incident' | 'query';
  input: any;
  analysis: {
    summary: string;
    severity: string;
    confidence: number;
    riskScore: number;
    recommendations: string[];
    relatedEvents: string[];
    mitreTechniques: string[];
    iocs: string[];
    timeline: any[];
    nextSteps: string[];
  };
  reasoning: string;
  timestamp: string;
  processingTime: number;
}

export interface MITREMapping {
  technique: string;
  tactic: string;
  description: string;
  detection: string;
  mitigation: string;
}

export class AIAnalystService extends EventEmitter {
  private genAI: GoogleGenerativeAI;
  private model: any;
  private isInitialized: boolean = false;
  private analysisCache: Map<string, AIAnalysis> = new Map();
  private mitreDatabase: Map<string, MITREMapping> = new Map();

  constructor(apiKey: string) {
    super();
    this.genAI = new GoogleGenerativeAI(apiKey);
    this.initializeModel();
    this.loadMITREDatabase();
  }

  // Initialize the AI model
  private async initializeModel() {
    try {
      this.model = this.genAI.getGenerativeModel({ 
        model: 'gemini-1.5-flash',
        generationConfig: {
          temperature: 0.1,
          topP: 0.8,
          topK: 40,
          maxOutputTokens: 8192,
        }
      });
      this.isInitialized = true;
      console.log('🧠 AI Analyst model initialized');
    } catch (error) {
      console.error('❌ Failed to initialize AI model:', error);
      this.isInitialized = false;
    }
  }

  // Load MITRE ATT&CK database
  private loadMITREDatabase() {
    const techniques: MITREMapping[] = [
      {
        technique: 'T1110',
        tactic: 'Credential Access',
        description: 'Brute Force: Password guessing and password cracking',
        detection: 'Monitor for multiple failed login attempts, unusual login patterns',
        mitigation: 'Account lockout policies, multi-factor authentication'
      },
      {
        technique: 'T1086',
        tactic: 'Execution',
        description: 'PowerShell: Command-line interface and scripting',
        detection: 'Monitor PowerShell execution, especially with obfuscated commands',
        mitigation: 'PowerShell constrained language mode, audit logging'
      },
      {
        technique: 'T1068',
        tactic: 'Privilege Escalation',
        description: 'Exploitation for Privilege Escalation',
        detection: 'Monitor for suspicious process execution with elevated privileges',
        mitigation: 'Regular patching, principle of least privilege'
      },
      {
        technique: 'T1027',
        tactic: 'Defense Evasion',
        description: 'Obfuscated Files or Information',
        detection: 'Monitor for file encryption, encoding, and obfuscation',
        mitigation: 'File scanning, behavior analysis'
      },
      {
        technique: 'T1041',
        tactic: 'Exfiltration',
        description: 'Exfiltration Over C2 Channel',
        detection: 'Monitor for unusual network traffic patterns',
        mitigation: 'Network segmentation, egress filtering'
      },
      {
        technique: 'T1486',
        tactic: 'Impact',
        description: 'Data Encrypted for Impact',
        detection: 'Monitor for file encryption activities',
        mitigation: 'Backup systems, file integrity monitoring'
      },
      {
        technique: 'T1078',
        tactic: 'Defense Evasion',
        description: 'Valid Accounts',
        detection: 'Monitor for account usage patterns',
        mitigation: 'Account management, privileged access management'
      },
      {
        technique: 'T1059.001',
        tactic: 'Execution',
        description: 'Command and Scripting Interpreter: PowerShell',
        detection: 'PowerShell command logging and monitoring',
        mitigation: 'PowerShell security features, AMSI'
      }
    ];

    techniques.forEach(technique => {
      this.mitreDatabase.set(technique.technique, technique);
    });

    console.log(`📚 Loaded ${techniques.length} MITRE ATT&CK techniques`);
  }

  // Analyze security event
  async analyzeEvent(event: SecurityEvent): Promise<AIAnalysis> {
    const startTime = Date.now();
    const cacheKey = `event_${event.id}`;

    // Check cache first
    const cached = this.analysisCache.get(cacheKey);
    if (cached) {
      return cached;
    }

    try {
      const prompt = this.buildEventAnalysisPrompt(event);
      const response = await this.generateAnalysis(prompt);
      
      const analysis: AIAnalysis = {
        id: this.generateId(),
        type: 'event',
        input: event,
        analysis: response,
        reasoning: 'Event analysis based on security patterns and threat intelligence',
        timestamp: new Date().toISOString(),
        processingTime: Date.now() - startTime
      };

      // Cache the result
      this.analysisCache.set(cacheKey, analysis);

      // Emit analysis event
      this.emit('analysis-completed', analysis);

      return analysis;

    } catch (error) {
      console.error('Error analyzing event:', error);
      throw new Error('AI analysis failed');
    }
  }

  // Analyze alert
  async analyzeAlert(alert: Alert, relatedEvents?: SecurityEvent[]): Promise<AIAnalysis> {
    const startTime = Date.now();
    const cacheKey = `alert_${alert.id}`;

    // Check cache first
    const cached = this.analysisCache.get(cacheKey);
    if (cached) {
      return cached;
    }

    try {
      const prompt = this.buildAlertAnalysisPrompt(alert, relatedEvents);
      const response = await this.generateAnalysis(prompt);
      
      const analysis: AIAnalysis = {
        id: this.generateId(),
        type: 'alert',
        input: alert,
        analysis: response,
        reasoning: 'Alert analysis with context from related events',
        timestamp: new Date().toISOString(),
        processingTime: Date.now() - startTime
      };

      // Cache the result
      this.analysisCache.set(cacheKey, analysis);

      // Emit analysis event
      this.emit('analysis-completed', analysis);

      return analysis;

    } catch (error) {
      console.error('Error analyzing alert:', error);
      throw new Error('AI analysis failed');
    }
  }

  // Analyze incident
  async analyzeIncident(incident: Incident, events: SecurityEvent[], alerts: Alert[]): Promise<AIAnalysis> {
    const startTime = Date.now();
    const cacheKey = `incident_${incident.id}`;

    // Check cache first
    const cached = this.analysisCache.get(cacheKey);
    if (cached) {
      return cached;
    }

    try {
      const prompt = this.buildIncidentAnalysisPrompt(incident, events, alerts);
      const response = await this.generateAnalysis(prompt);
      
      const analysis: AIAnalysis = {
        id: this.generateId(),
        type: 'incident',
        input: incident,
        analysis: response,
        reasoning: 'Comprehensive incident analysis with attack chain reconstruction',
        timestamp: new Date().toISOString(),
        processingTime: Date.now() - startTime
      };

      // Cache the result
      this.analysisCache.set(cacheKey, analysis);

      // Emit analysis event
      this.emit('analysis-completed', analysis);

      return analysis;

    } catch (error) {
      console.error('Error analyzing incident:', error);
      throw new Error('AI analysis failed');
    }
  }

  // Natural language query
  async processQuery(query: string, context?: any): Promise<AIAnalysis> {
    const startTime = Date.now();
    const cacheKey = `query_${this.hashString(query)}`;

    // Check cache first
    const cached = this.analysisCache.get(cacheKey);
    if (cached) {
      return cached;
    }

    try {
      const prompt = this.buildQueryPrompt(query, context);
      const response = await this.generateAnalysis(prompt);
      
      const analysis: AIAnalysis = {
        id: this.generateId(),
        type: 'query',
        input: { query, context },
        analysis: response,
        reasoning: 'Natural language query processing with security context',
        timestamp: new Date().toISOString(),
        processingTime: Date.now() - startTime
      };

      // Cache the result
      this.analysisCache.set(cacheKey, analysis);

      // Emit analysis event
      this.emit('analysis-completed', analysis);

      return analysis;

    } catch (error) {
      console.error('Error processing query:', error);
      throw new Error('AI query processing failed');
    }
  }

  // Build analysis prompt for events
  private buildEventAnalysisPrompt(event: SecurityEvent): string {
    return `
You are an expert cybersecurity analyst. Analyze the following security event and provide comprehensive insights.

EVENT DETAILS:
- ID: ${event.id}
- Timestamp: ${event.timestamp}
- Event Type: ${event.event_type}
- Source: ${event.source}
- Source IP: ${event.source_ip || 'N/A'}
- User: ${event.user || 'N/A'}
- Hostname: ${event.hostname || 'N/A'}
- Process: ${event.process_name || 'N/A'}
- Command Line: ${event.command_line || 'N/A'}
- Severity: ${event.severity}
- Category: ${event.category || 'N/A'}
- Details: ${event.details}

ANALYSIS REQUIREMENTS:
1. Summary: Brief explanation of what happened
2. Threat Assessment: Potential risks and impact
3. MITRE ATT&CK Mapping: Relevant techniques and tactics
4. Indicators of Compromise (IOCs): Extract any suspicious indicators
5. Recommendations: Immediate actions and long-term improvements
6. Related Events: What other events might be related
7. Risk Score: 0-100 based on severity and context
8. Confidence: How confident are you in this analysis

Provide your response in JSON format with the following structure:
{
  "summary": "Brief explanation",
  "severity": "low|medium|high|critical",
  "confidence": 0.0-1.0,
  "riskScore": 0-100,
  "recommendations": ["action1", "action2"],
  "relatedEvents": ["event_type1", "event_type2"],
  "mitreTechniques": ["T1110", "T1086"],
  "iocs": ["ip1", "domain1", "hash1"],
  "timeline": [{"time": "timestamp", "action": "description"}],
  "nextSteps": ["step1", "step2"]
}
`;
  }

  // Build analysis prompt for alerts
  private buildAlertAnalysisPrompt(alert: Alert, relatedEvents?: SecurityEvent[]): string {
    const eventsContext = relatedEvents ? 
      relatedEvents.map(e => `- ${e.event_type}: ${e.details}`).join('\n') : 'No related events';

    return `
You are an expert cybersecurity analyst. Analyze the following security alert and provide comprehensive insights.

ALERT DETAILS:
- ID: ${alert.id}
- Title: ${alert.title}
- Description: ${alert.description}
- Severity: ${alert.severity}
- Risk Score: ${alert.riskScore}
- Confidence: ${alert.confidence}
- Status: ${alert.status}

RELATED EVENTS:
${eventsContext}

ANALYSIS REQUIREMENTS:
1. Threat Assessment: Analyze the potential impact and scope
2. Attack Chain: Reconstruct the potential attack sequence
3. MITRE ATT&CK Mapping: Identify relevant techniques
4. Investigation Steps: What should analysts investigate next
5. Containment Actions: Immediate steps to contain the threat
6. Threat Actor Attribution: Potential threat actors or malware families
7. Business Impact: Potential impact on business operations
8. Escalation Criteria: When should this be escalated

Provide your response in JSON format with the same structure as event analysis.
`;
  }

  // Build analysis prompt for incidents
  private buildIncidentAnalysisPrompt(incident: Incident, events: SecurityEvent[], alerts: Alert[]): string {
    const eventsSummary = events.map(e => `- ${e.timestamp}: ${e.event_type} - ${e.details}`).join('\n');
    const alertsSummary = alerts.map(a => `- ${a.title} (${a.severity})`).join('\n');

    return `
You are an expert cybersecurity incident responder. Analyze the following security incident and provide comprehensive analysis.

INCIDENT DETAILS:
- ID: ${incident.incidentId}
- Title: ${incident.title}
- Description: ${incident.description}
- Severity: ${incident.severity}
- Status: ${incident.status}
- Category: ${incident.category || 'N/A'}

RELATED EVENTS (${events.length}):
${eventsSummary}

RELATED ALERTS (${alerts.length}):
${alertsSummary}

ANALYSIS REQUIREMENTS:
1. Incident Summary: Comprehensive overview of what happened
2. Attack Timeline: Chronological sequence of events
3. Attack Chain: Full attack lifecycle from initial access to impact
4. MITRE ATT&CK Framework: Map all observed techniques
5. Root Cause Analysis: Identify the root cause of the incident
6. Impact Assessment: Business and technical impact
7. Containment Strategy: How to contain and eradicate the threat
8. Recovery Actions: Steps to restore normal operations
9. Lessons Learned: Key takeaways and improvements needed
10. Threat Intelligence: Relevant threat actor or malware information

Provide your response in JSON format with the same structure as event analysis.
`;
  }

  // Build query prompt
  private buildQueryPrompt(query: string, context?: any): string {
    const contextStr = context ? JSON.stringify(context, null, 2) : 'No additional context';

    return `
You are an expert cybersecurity analyst and SOC assistant. Answer the following user query about security operations.

USER QUERY: ${query}

CONTEXT:
${contextStr}

ANALYSIS REQUIREMENTS:
1. Direct Answer: Provide a clear and concise answer to the query
2. Security Context: Explain the security relevance
3. Practical Advice: Actionable recommendations
4. Best Practices: Industry standards and best practices
5. Examples: Concrete examples if applicable
6. References: Relevant frameworks or standards

Provide your response in JSON format with the same structure as event analysis, adapting the fields as needed for the query type.
`;
  }

  // Generate analysis using AI model
  private async generateAnalysis(prompt: string): Promise<any> {
    if (!this.isInitialized) {
      throw new Error('AI model not initialized');
    }

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();

      // Parse JSON response
      const analysis = JSON.parse(text);
      
      // Validate and enhance response
      return this.validateAndEnhanceResponse(analysis);

    } catch (error) {
      console.error('AI generation error:', error);
      
      // Fallback to basic analysis
      return this.generateFallbackAnalysis();
    }
  }

  // Validate and enhance AI response
  private validateAndEnhanceResponse(response: any): any {
    // Ensure required fields exist
    const enhanced = {
      summary: response.summary || 'Analysis completed',
      severity: response.severity || 'medium',
      confidence: response.confidence || 0.5,
      riskScore: response.riskScore || 50,
      recommendations: response.recommendations || [],
      relatedEvents: response.relatedEvents || [],
      mitreTechniques: response.mitreTechniques || [],
      iocs: response.iocs || [],
      timeline: response.timeline || [],
      nextSteps: response.nextSteps || []
    };

    // Add MITRE technique details
    enhanced.mitreTechniques = enhanced.mitreTechniques.map((tech: string) => {
      const mitreInfo = this.mitreDatabase.get(tech);
      return mitreInfo ? {
        technique: tech,
        tactic: mitreInfo.tactic,
        description: mitreInfo.description
      } : { technique: tech, tactic: 'Unknown', description: 'No description available' };
    });

    return enhanced;
  }

  // Generate fallback analysis
  private generateFallbackAnalysis(): any {
    return {
      summary: 'AI analysis temporarily unavailable. Basic pattern matching applied.',
      severity: 'medium',
      confidence: 0.3,
      riskScore: 50,
      recommendations: [
        'Review event details manually',
        'Check for related events in the timeline',
        'Consult with senior analyst if needed'
      ],
      relatedEvents: [],
      mitreTechniques: [],
      iocs: [],
      timeline: [],
      nextSteps: ['Manual investigation required']
    };
  }

  // Get MITRE technique details
  getMITREDetails(techniqueId: string): MITREMapping | undefined {
    return this.mitreDatabase.get(techniqueId);
  }

  // Get all MITRE techniques
  getAllMITRETechniques(): MITREMapping[] {
    return Array.from(this.mitreDatabase.values());
  }

  // Clear cache
  clearCache(): void {
    this.analysisCache.clear();
    console.log('🧹 AI analysis cache cleared');
  }

  // Get service statistics
  getStatistics(): any {
    return {
      initialized: this.isInitialized,
      cacheSize: this.analysisCache.size,
      mitreTechniquesLoaded: this.mitreDatabase.size,
      modelInfo: this.isInitialized ? 'gemini-1.5-flash' : 'Not initialized'
    };
  }

  // Get service status
  getStatus(): any {
    return {
      running: this.isInitialized,
      statistics: this.getStatistics()
    };
  }

  // Generate unique ID
  private generateId(): string {
    return `ai_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Hash string for cache key
  private hashString(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16);
  }
}
