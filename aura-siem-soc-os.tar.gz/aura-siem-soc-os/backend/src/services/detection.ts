import { EventEmitter } from 'events';
import { v4 as uuidv4 } from 'uuid';
import { SecurityEvent, Alert, DetectionRule } from '../types/detection';
import { ThreatIntelService } from './threatIntel';
import { NotificationService } from './notifications';

export interface DetectionResult {
  matched: boolean;
  rule: DetectionRule;
  score: number;
  confidence: number;
  details: any;
}

export interface EnrichedEvent extends SecurityEvent {
  enrichment: {
    geoip?: any;
    threatIntel?: any;
    userContext?: any;
    riskScore: number;
    anomalies: string[];
  };
}

export class DetectionEngine extends EventEmitter {
  private rules: Map<string, DetectionRule> = new Map();
  private threatIntel: ThreatIntelService;
  private notifications: NotificationService;
  private isRunning: boolean = false;

  constructor(threatIntel: ThreatIntelService, notifications: NotificationService) {
    super();
    this.threatIntel = threatIntel;
    this.notifications = notifications;
    this.loadDefaultRules();
  }

  // Load default Sigma-like detection rules
  private loadDefaultRules() {
    const defaultRules: DetectionRule[] = [
      {
        id: 'brute-force-login',
        name: 'Failed Login Brute Force Attack',
        description: 'Detects multiple failed login attempts from the same source IP within a short time window',
        category: 'Authentication',
        severity: 'high',
        enabled: true,
        query: {
          condition: 'event_type = "login" AND status = "failed"',
          aggregation: {
            field: 'source_ip',
            function: 'count',
            operator: '>',
            value: 10,
            window: '5m'
          }
        },
        mitreTechniques: ['T1110', 'T1110.001', 'T1110.003'],
        riskScore: 75,
        falsePositivePatterns: [
          'source_ip in internal_networks',
          'user in service_accounts'
        ]
      },
      {
        id: 'impossible-travel',
        name: 'Impossible Travel Login',
        description: 'Detects logins from geographically impossible locations within a short time period',
        category: 'Authentication',
        severity: 'critical',
        enabled: true,
        query: {
          condition: 'event_type = "login" AND status = "success"',
          correlation: {
            field: 'user',
            timeWindow: '1h',
            geoDistance: 1000
          }
        },
        mitreTechniques: ['T1078'],
        riskScore: 90,
        falsePositivePatterns: [
          'user in vpn_users',
          'source_ip in known_proxies'
        ]
      },
      {
        id: 'suspicious-powershell',
        name: 'Suspicious PowerShell Execution',
        description: 'Detects potentially malicious PowerShell commands and obfuscation techniques',
        category: 'Execution',
        severity: 'high',
        enabled: true,
        query: {
          condition: 'process_name = "powershell.exe"',
          patterns: [
            '-enc',
            '-nop',
            '-w hidden',
            'bypass',
            'base64',
            'invoke-expression',
            'iex'
          ]
        },
        mitreTechniques: ['T1086', 'T1027', 'T1059.001'],
        riskScore: 80,
        falsePositivePatterns: [
          'command_line contains legitimate_scripts',
          'parent_process in approved_applications'
        ]
      },
      {
        id: 'privilege-escalation',
        name: 'Privilege Escalation Attempt',
        description: 'Detects attempts to escalate privileges through various techniques',
        category: 'Privilege Escalation',
        severity: 'critical',
        enabled: true,
        query: {
          condition: 'event_type IN ("process", "command")',
          patterns: [
            'net user',
            'whoami /priv',
            'runas',
            'sudo',
            'su -',
            'chmod +s',
            'setuid'
          ]
        },
        mitreTechniques: ['T1068', 'T1548.003', 'T1548.002'],
        riskScore: 85,
        falsePositivePatterns: [
          'user in administrators_group',
          'process in system_processes'
        ]
      },
      {
        id: 'lateral-movement',
        name: 'Lateral Movement Detection',
        description: 'Detects potential lateral movement activities across the network',
        category: 'Lateral Movement',
        severity: 'high',
        enabled: true,
        query: {
          condition: 'event_type IN ("network", "process", "login")',
          patterns: [
            'psexec',
            'wmic',
            'smb',
            'rpc',
            'winrm',
            'ssh',
            'rdp'
          ],
          correlation: {
            field: 'source_ip',
            timeWindow: '15m',
            uniqueDestinations: 3
          }
        },
        mitreTechniques: ['T1021', 'T1570', 'T1028'],
        riskScore: 75,
        falsePositivePatterns: [
          'source_ip in management_servers',
          'destination_ip in approved_servers'
        ]
      },
      {
        id: 'c2-beaconing',
        name: 'Command and Control Beaconing',
        description: 'Detects potential C2 beaconing patterns through periodic connections',
        category: 'Command and Control',
        severity: 'critical',
        enabled: true,
        query: {
          condition: 'event_type = "network"',
          correlation: {
            field: 'destination_ip',
            timeWindow: '1h',
            periodicity: 'regular',
            minConnections: 5
          }
        },
        mitreTechniques: ['T1071', 'T1105', 'T1041'],
        riskScore: 90,
        falsePositivePatterns: [
          'destination_ip in cdn_networks',
          'destination_ip in update_servers'
        ]
      },
      {
        id: 'ransomware-behavior',
        name: 'Ransomware Behavior Pattern',
        description: 'Detects typical ransomware activity patterns',
        category: 'Impact',
        severity: 'critical',
        enabled: true,
        query: {
          condition: 'event_type = "file"',
          patterns: [
            '.encrypted',
            '.locked',
            '.crypted',
            'decrypt',
            'bitcoin',
            'monero'
          ],
          aggregation: {
            field: 'process_name',
            function: 'count',
            operator: '>',
            value: 50,
            window: '2m'
          }
        },
        mitreTechniques: ['T1486'],
        riskScore: 95,
        falsePositivePatterns: [
          'process_name in backup_software',
          'path in system_directories'
        ]
      },
      {
        id: 'data-exfiltration',
        name: 'Data Exfiltration Detection',
        description: 'Detects potential data exfiltration through unusual data transfers',
        category: 'Exfiltration',
        severity: 'high',
        enabled: true,
        query: {
          condition: 'event_type = "network"',
          aggregation: {
            field: 'destination_ip',
            function: 'sum(bytes)',
            operator: '>',
            value: 100000000, // 100MB
            window: '10m'
          }
        },
        mitreTechniques: ['T1041', 'T1567', 'T1020'],
        riskScore: 80,
        falsePositivePatterns: [
          'destination_ip in backup_destinations',
          'destination_ip in cloud_storage'
        ]
      },
      {
        id: 'registry-modification',
        name: 'Suspicious Registry Modification',
        description: 'Detects suspicious Windows registry modifications',
        category: 'Defense Evasion',
        severity: 'high',
        enabled: true,
        query: {
          condition: 'event_type = "registry"',
          patterns: [
            'Run\\',
            'RunOnce\\',
            'Policies\\',
            'Image File Execution Options',
            'Winlogon\\Notify',
            'Boot\\Execute'
          ]
        },
        mitreTechniques: ['T1112', 'T1547.001', 'T1547.004'],
        riskScore: 75,
        falsePositivePatterns: [
            'path in software_installation_paths',
            'process in legitimate_installer'
        ]
      },
      {
        id: 'unusual-user-agent',
        name: 'Unusual User Agent String',
        description: 'Detects suspicious or uncommon user agent strings in web requests',
        category: 'Initial Access',
        severity: 'medium',
        enabled: true,
        query: {
          condition: 'event_type = "web"',
          patterns: [
            'sqlmap',
            'nikto',
            'nmap',
            'masscan',
            'python-requests',
            'curl',
            'wget'
          ]
        },
        mitreTechniques: ['T1190', 'T1071.001'],
        riskScore: 60,
        falsePositivePatterns: [
          'user_agent in monitoring_tools',
          'source_ip in internal_networks'
        ]
      }
    ];

    defaultRules.forEach(rule => {
      this.rules.set(rule.id, rule);
    });

    console.log(`📋 Loaded ${defaultRules.length} detection rules`);
  }

  // Main detection method - processes events through all rules
  async processEvent(event: SecurityEvent): Promise<DetectionResult[]> {
    const results: DetectionResult[] = [];
    
    try {
      // Enrich event with additional context
      const enrichedEvent = await this.enrichEvent(event);
      
      // Process through each enabled rule
      for (const rule of this.rules.values()) {
        if (!rule.enabled) continue;
        
        const result = await this.evaluateRule(rule, enrichedEvent);
        if (result.matched) {
          results.push(result);
          
          // Create alert if rule is configured to auto-alert
          if (rule.autoAlert !== false) {
            await this.createAlert(enrichedEvent, rule, result);
          }
          
          // Emit detection event for real-time notifications
          this.emit('detection', {
            event: enrichedEvent,
            rule,
            result
          });
        }
      }
      
      return results;
    } catch (error) {
      console.error('Error processing event:', error);
      return [];
    }
  }

  // Enrich event with additional context
  private async enrichEvent(event: SecurityEvent): Promise<EnrichedEvent> {
    const enrichment: any = {
      riskScore: 50, // Base risk score
      anomalies: []
    };

    try {
      // GeoIP enrichment for IP addresses
      if (event.source_ip) {
        enrichment.geoip = await this.getGeoIP(event.source_ip);
      }

      // Threat intelligence enrichment
      if (event.source_ip || event.domain) {
        enrichment.threatIntel = await this.threatIntel.checkIndicators({
          ip: event.source_ip,
          domain: event.domain
        });
      }

      // User context enrichment
      if (event.user) {
        enrichment.userContext = await this.getUserContext(event.user);
      }

      // Calculate risk score based on enrichment
      enrichment.riskScore = this.calculateRiskScore(event, enrichment);

      // Detect anomalies
      enrichment.anomalies = this.detectAnomalies(event, enrichment);

    } catch (error) {
      console.error('Error enriching event:', error);
    }

    return {
      ...event,
      enrichment
    };
  }

  // Evaluate a single rule against an event
  private async evaluateRule(rule: DetectionRule, event: EnrichedEvent): Promise<DetectionResult> {
    const result: DetectionResult = {
      matched: false,
      rule,
      score: 0,
      confidence: 0,
      details: {}
    };

    try {
      // Check basic condition
      if (!this.matchesCondition(rule.query.condition, event)) {
        return result;
      }

      // Check patterns if specified
      if (rule.query.patterns) {
        const patternMatch = rule.query.patterns.some(pattern => 
          this.matchesPattern(pattern, event)
        );
        if (!patternMatch) {
          return result;
        }
      }

      // Check aggregation if specified
      if (rule.query.aggregation) {
        const aggregationResult = await this.checkAggregation(rule.query.aggregation, event);
        if (!aggregationResult.matched) {
          return result;
        }
        result.details.aggregation = aggregationResult.details;
      }

      // Check correlation if specified
      if (rule.query.correlation) {
        const correlationResult = await this.checkCorrelation(rule.query.correlation, event);
        if (!correlationResult.matched) {
          return result;
        }
        result.details.correlation = correlationResult.details;
      }

      // Check false positive patterns
      if (rule.falsePositivePatterns && this.isFalsePositive(rule.falsePositivePatterns, event)) {
        return result;
      }

      // Calculate score and confidence
      result.matched = true;
      result.score = this.calculateRuleScore(rule, event);
      result.confidence = this.calculateConfidence(rule, event);

    } catch (error) {
      console.error(`Error evaluating rule ${rule.id}:`, error);
    }

    return result;
  }

  // Condition matching logic
  private matchesCondition(condition: string, event: EnrichedEvent): boolean {
    // Simple condition parser for demonstration
    // In production, this would use a more sophisticated query engine
    
    if (condition.includes('event_type')) {
      const match = condition.match(/event_type\s*=\s*["']([^"']+)["']/);
      if (match && event.event_type !== match[1]) return false;
    }

    if (condition.includes('status')) {
      const match = condition.match(/status\s*=\s*["']([^"']+)["']/);
      if (match && event.details !== match[1]) return false;
    }

    if (condition.includes('process_name')) {
      const match = condition.match(/process_name\s*=\s*["']([^"']+)["']/);
      if (match && event.source !== match[1]) return false;
    }

    if (condition.includes('IN')) {
      const match = condition.match(/event_type\s+IN\s*\(([^)]+)\)/);
      if (match) {
        const values = match[1].split(',').map(v => v.trim().replace(/["']/g, ''));
        if (!values.includes(event.event_type)) return false;
      }
    }

    return true;
  }

  // Pattern matching logic
  private matchesPattern(pattern: string, event: EnrichedEvent): boolean {
    const searchText = [
      event.details,
      event.source,
      event.event_type,
      event.user
    ].join(' ').toLowerCase();

    return searchText.includes(pattern.toLowerCase());
  }

  // Aggregation check (e.g., count > threshold in time window)
  private async checkAggregation(aggregation: any, event: EnrichedEvent): Promise<any> {
    // In production, this would query the database for similar events
    // For demonstration, return a mock result
    return {
      matched: true,
      details: {
        count: Math.floor(Math.random() * 20) + 1,
        threshold: aggregation.value
      }
    };
  }

  // Correlation check (e.g., same user from different locations)
  private async checkCorrelation(correlation: any, event: EnrichedEvent): Promise<any> {
    // In production, this would query for correlated events
    // For demonstration, return a mock result
    return {
      matched: Math.random() > 0.7, // 30% chance of correlation
      details: {
        correlatedEvents: Math.floor(Math.random() * 5) + 1,
        timeWindow: correlation.timeWindow
      }
    };
  }

  // False positive detection
  private isFalsePositive(patterns: string[], event: EnrichedEvent): boolean {
    // Simple pattern matching for false positives
    // In production, this would be more sophisticated
    return patterns.some(pattern => {
      if (pattern.includes('internal_networks')) {
        return event.source_ip?.startsWith('192.168.') || 
               event.source_ip?.startsWith('10.') ||
               event.source_ip?.startsWith('172.');
      }
      return false;
    });
  }

  // Calculate rule score
  private calculateRuleScore(rule: DetectionRule, event: EnrichedEvent): number {
    let score = rule.riskScore || 50;

    // Adjust based on event severity
    if (event.severity === 'critical') score += 20;
    else if (event.severity === 'high') score += 10;
    else if (event.severity === 'low') score -= 10;

    // Adjust based on threat intelligence
    if (event.enrichment.threatIntel?.malicious) score += 25;
    if (event.enrichment.threatIntel?.suspicious) score += 10;

    // Adjust based on user context
    if (event.enrichment.userContext?.privileged) score += 15;
    if (event.enrichment.userContext?.newAccount) score += 10;

    return Math.min(100, Math.max(0, score));
  }

  // Calculate confidence
  private calculateConfidence(rule: DetectionRule, event: EnrichedEvent): number {
    let confidence = 0.5; // Base confidence

    // Increase confidence based on multiple factors
    if (event.enrichment.threatIntel?.confidence) {
      confidence += event.enrichment.threatIntel.confidence * 0.3;
    }

    if (event.enrichment.anomalies.length > 0) {
      confidence += 0.2;
    }

    if (rule.query.correlation) {
      confidence += 0.1;
    }

    return Math.min(1.0, Math.max(0.1, confidence));
  }

  // Calculate overall risk score
  private calculateRiskScore(event: SecurityEvent, enrichment: any): number {
    let score = 50; // Base score

    // Event severity
    const severityScores = { low: 20, medium: 50, high: 75, critical: 90 };
    score = severityScores[event.severity] || 50;

    // Threat intelligence
    if (enrichment.threatIntel?.malicious) score += 30;
    if (enrichment.threatIntel?.suspicious) score += 15;

    // Geographic anomalies
    if (enrichment.geoip?.isAnonymous) score += 20;
    if (enrichment.geoip?.isProxy) score += 15;

    // Time-based anomalies
    const hour = new Date(event.timestamp).getHours();
    if (hour < 6 || hour > 22) score += 10; // Off-hours

    return Math.min(100, Math.max(0, score));
  }

  // Detect anomalies
  private detectAnomalies(event: SecurityEvent, enrichment: any): string[] {
    const anomalies: string[] = [];

    // Time-based anomaly
    const hour = new Date(event.timestamp).getHours();
    if (hour < 6 || hour > 22) {
      anomalies.push('off_hours_activity');
    }

    // Geographic anomaly
    if (enrichment.geoip?.country === 'Unknown') {
      anomalies.push('unknown_location');
    }

    // User anomaly
    if (enrichment.userContext?.firstTimeLogin) {
      anomalies.push('first_time_user');
    }

    // Threat intelligence anomaly
    if (enrichment.threatIntel?.malicious) {
      anomalies.push('malicious_indicator');
    }

    return anomalies;
  }

  // Create alert from detection
  private async createAlert(event: EnrichedEvent, rule: DetectionRule, result: DetectionResult) {
    const alert: Partial<Alert> = {
      id: uuidv4(),
      ruleId: rule.id,
      eventId: event.id,
      severity: this.mapSeverity(result.score),
      status: 'open',
      title: rule.name,
      description: rule.description,
      confidence: result.confidence,
      riskScore: result.score,
      details: result.details,
      createdAt: new Date().toISOString()
    };

    // Send real-time notification
    await this.notifications.sendAlert(alert as Alert);

    console.log(`🚨 Alert created: ${rule.name} (Score: ${result.score})`);
  }

  // Map numeric score to severity
  private mapSeverity(score: number): 'low' | 'medium' | 'high' | 'critical' {
    if (score >= 90) return 'critical';
    if (score >= 70) return 'high';
    if (score >= 50) return 'medium';
    return 'low';
  }

  // GeoIP lookup (mock implementation)
  private async getGeoIP(ip: string): Promise<any> {
    // In production, this would use a real GeoIP service
    return {
      country: 'United States',
      city: 'Unknown',
      isAnonymous: false,
      isProxy: false
    };
  }

  // User context lookup (mock implementation)
  private async getUserContext(username: string): Promise<any> {
    // In production, this would query the user directory
    return {
      privileged: Math.random() > 0.8,
      newAccount: Math.random() > 0.9,
      firstTimeLogin: Math.random() > 0.95
    };
  }

  // Add custom rule
  addRule(rule: DetectionRule): void {
    this.rules.set(rule.id, rule);
    console.log(`➕ Added custom rule: ${rule.name}`);
  }

  // Remove rule
  removeRule(ruleId: string): boolean {
    const deleted = this.rules.delete(ruleId);
    if (deleted) {
      console.log(`➖ Removed rule: ${ruleId}`);
    }
    return deleted;
  }

  // Enable/disable rule
  toggleRule(ruleId: string, enabled: boolean): boolean {
    const rule = this.rules.get(ruleId);
    if (rule) {
      rule.enabled = enabled;
      console.log(`${enabled ? '✅' : '❌'} Rule ${ruleId} ${enabled ? 'enabled' : 'disabled'}`);
      return true;
    }
    return false;
  }

  // Get all rules
  getRules(): DetectionRule[] {
    return Array.from(this.rules.values());
  }

  // Get rule by ID
  getRule(ruleId: string): DetectionRule | undefined {
    return this.rules.get(ruleId);
  }

  // Start detection engine
  start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('🚀 Detection engine started');
  }

  // Stop detection engine
  stop(): void {
    if (!this.isRunning) return;
    
    this.isRunning = false;
    console.log('⏹️ Detection engine stopped');
  }

  // Get engine status
  getStatus(): any {
    return {
      running: this.isRunning,
      rulesCount: this.rules.size,
      enabledRules: Array.from(this.rules.values()).filter(r => r.enabled).length,
      uptime: process.uptime()
    };
  }
}
