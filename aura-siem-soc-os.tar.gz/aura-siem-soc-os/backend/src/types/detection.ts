export interface SecurityEvent {
  id: string;
  timestamp: string;
  event_type: string;
  source: string;
  source_ip?: string;
  destination_ip?: string;
  user?: string;
  domain?: string;
  process_name?: string;
  command_line?: string;
  details: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category?: string;
  hostname?: string;
  process_id?: number;
  raw_log?: string;
  normalized_data?: any;
  enrichment?: any;
  tags?: string[];
  status?: string;
}

export interface DetectionRule {
  id: string;
  name: string;
  description: string;
  category: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  enabled: boolean;
  query: {
    condition: string;
    patterns?: string[];
    aggregation?: {
      field: string;
      function: string;
      operator: string;
      value: number;
      window: string;
    };
    correlation?: {
      field: string;
      timeWindow: string;
      geoDistance?: number;
      uniqueDestinations?: number;
      periodicity?: string;
      minConnections?: number;
    };
  };
  mitreTechniques: string[];
  riskScore: number;
  falsePositivePatterns?: string[];
  autoAlert?: boolean;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
  lastTriggered?: string;
  triggerCount?: number;
}

export interface Alert {
  id: string;
  ruleId: string;
  eventId: string;
  incidentId?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'acknowledged' | 'investigating' | 'resolved' | 'false_positive';
  title: string;
  description: string;
  confidence: number;
  riskScore: number;
  assignedTo?: string;
  createdAt: string;
  updatedAt?: string;
  acknowledgedAt?: string;
  acknowledgedBy?: string;
  details?: any;
}

export interface ThreatIntel {
  id: string;
  indicator: string;
  indicatorType: 'ip' | 'domain' | 'url' | 'hash' | 'email' | 'filename' | 'registry_key';
  threatActor?: string;
  malwareFamily?: string;
  confidence: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  firstSeen: string;
  lastSeen: string;
  source: string;
  description?: string;
  tags: string[];
  context: any;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Incident {
  id: string;
  incidentId: string;
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'investigating' | 'resolved' | 'closed' | 'escalated';
  category?: string;
  sourceEventId?: string;
  assignedTo?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
  resolutionDetails?: string;
  impactAssessment: any;
  mitreTactics: string[];
  mitreTechniques: string[];
}

export interface ForensicArtifact {
  id: string;
  caseId: string;
  artifactType: 'file' | 'registry' | 'process' | 'network' | 'memory' | 'prefetch' | 'amcache';
  name: string;
  path?: string;
  hashMd5?: string;
  hashSha256?: string;
  size?: number;
  createdAt: string;
  modifiedAt?: string;
  accessedAt?: string;
  suspicious: boolean;
  threatScore: number;
  description?: string;
  metadata: any;
  collectedBy: string;
  collectedAt: string;
}
