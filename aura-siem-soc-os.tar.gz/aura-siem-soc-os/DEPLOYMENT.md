# AURA NEXUS SOC OS - Deployment Guide

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 18+
- PostgreSQL 15+
- Redis 7+
- Elasticsearch 8+
- Apache Kafka

### Environment Variables
Create a `.env` file in the root directory:

```bash
# Database
DATABASE_URL=postgresql://aura_nexus:secure_password@localhost:5432/aura_nexus

# Redis
REDIS_URL=redis://localhost:6379

# Elasticsearch
ELASTICSEARCH_URL=http://localhost:9200

# Kafka
KAFKA_BROKERS=localhost:9092

# AI Services
GEMINI_API_KEY=your_gemini_api_key_here

# Security
JWT_SECRET=your_jwt_secret_here

# Frontend
REACT_APP_API_URL=http://localhost:3001
REACT_APP_WS_URL=ws://localhost:3001

# Backend
NODE_ENV=production
PORT=3001
FRONTEND_URL=http://localhost:3000
```

## 🐳 Docker Deployment

### Development
```bash
# Build and start all services
docker-compose up --build

# Start in background
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Production
```bash
# Use production configuration
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# Scale services
docker-compose up -d --scale backend=3 --scale frontend=2
```

## ☸️ Kubernetes Deployment

### Prerequisites
- Kubernetes cluster (v1.24+)
- kubectl configured
- Storage class configured (fast-ssd)

### Deploy to Cluster
```bash
# Create namespace
kubectl apply -f k8s/namespace.yaml

# Deploy secrets and configmaps
kubectl apply -f k8s/secrets.yaml

# Deploy persistent volumes
kubectl apply -f k8s/pvc.yaml

# Deploy applications
kubectl apply -f k8s/deployment.yaml

# Deploy services
kubectl apply -f k8s/services.yaml

# Check deployment status
kubectl get pods -n aura-nexus
kubectl get services -n aura-nexus
```

### Access the Application
```bash
# Get external IP
kubectl get service aura-nexus-ingress -n aura-nexus

# Port forward for local testing
kubectl port-forward service/aura-nexus-frontend-service 3000:3000 -n aura-nexus
kubectl port-forward service/aura-nexus-backend-service 3001:3001 -n aura-nexus
```

## 📊 Monitoring & Observability

### Prometheus & Grafana
Access metrics dashboards:
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3002 (admin/admin)

### Kibana
Access log analysis:
- Kibana: http://localhost:5601

### Health Checks
```bash
# Backend health
curl http://localhost:3001/health

# Frontend health
curl http://localhost:3000

# Database connection
docker-compose exec postgres pg_isready

# Redis connection
docker-compose exec redis redis-cli ping
```

## 🔧 Configuration

### Database Setup
```bash
# Create database
docker-compose exec postgres createdb aura_nexus

# Run migrations
docker-compose exec backend npm run db:migrate

# Seed data
docker-compose exec backend npm run db:seed
```

### Elasticsearch Setup
```bash
# Create index templates
curl -X PUT "localhost:9200/_index_template/security_events" \
  -H 'Content-Type: application/json' \
  -d @elasticsearch/templates/security_events.json

# Create index patterns
curl -X PUT "localhost:9200/security_events-*"
```

### Kafka Setup
```bash
# Create topics
docker-compose exec kafka kafka-topics --create \
  --topic security-events \
  --bootstrap-server localhost:9092 \
  --partitions 3 \
  --replication-factor 1

docker-compose exec kafka kafka-topics --create \
  --topic alerts \
  --bootstrap-server localhost:9092 \
  --partitions 3 \
  --replication-factor 1
```

## 🔒 Security Configuration

### SSL/TLS Setup
```bash
# Generate SSL certificates
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout nginx/ssl/private.key \
  -out nginx/ssl/certificate.crt

# Update nginx configuration
vim nginx/nginx.conf
```

### Authentication
```bash
# Create admin user
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@company.com","username":"admin","password":"secure_password","fullName":"Administrator","role":"super_admin"}'

# Generate API keys
curl -X POST http://localhost:3001/api/auth/api-key \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

## 📈 Scaling & Performance

### Horizontal Scaling
```bash
# Scale backend services
kubectl scale deployment aura-nexus-backend --replicas=5 -n aura-nexus

# Scale frontend services
kubectl scale deployment aura-nexus-frontend --replicas=3 -n aura-nexus
```

### Resource Limits
Adjust resource requests and limits in `k8s/deployment.yaml` based on your cluster capacity.

### Auto-scaling
```bash
# Enable HPA (Horizontal Pod Autoscaler)
kubectl autoscale deployment aura-nexus-backend \
  --cpu-percent=70 \
  --min=3 \
  --max=10 \
  -n aura-nexus
```

## 🔍 Troubleshooting

### Common Issues
1. **Database Connection Failed**
   - Check DATABASE_URL environment variable
   - Verify PostgreSQL is running
   - Check network policies

2. **High Memory Usage**
   - Increase memory limits in deployment
   - Check for memory leaks in application
   - Monitor with Prometheus

3. **Slow Performance**
   - Check Elasticsearch cluster health
   - Verify Kafka broker performance
   - Monitor database query performance

### Logs
```bash
# Application logs
kubectl logs -f deployment/aura-nexus-backend -n aura-nexus

# Database logs
kubectl logs -f deployment/aura-nexus-postgres -n aura-nexus

# System events
kubectl get events -n aura-nexus --sort-by='.lastTimestamp'
```

### Debug Mode
```bash
# Enable debug logging
kubectl set env deployment/aura-nexus-backend DEBUG=true -n aura-nexus

# Access container shell
kubectl exec -it deployment/aura-nexus-backend -n aura-nexus -- /bin/bash
```

## 🔄 Backup & Recovery

### Database Backup
```bash
# Create backup
docker-compose exec postgres pg_dump -U aura_nexus aura_nexus > backup.sql

# Restore backup
docker-compose exec -T postgres psql -U aura_nexus aura_nexus < backup.sql
```

### Volume Backup
```bash
# Backup persistent volumes
kubectl get pvc -n aura-nexus
kubectl cp namespace/pvc-name:/path/to/data ./backup/
```

## 📚 Additional Resources

### Documentation
- [API Documentation](./docs/api.md)
- [Architecture Guide](./ARCHITECTURE.md)
- [Security Best Practices](./docs/security.md)

### Support
- GitHub Issues: [Report bugs](https://github.com/aura-nexus/soc-os/issues)
- Community: [Discussions](https://github.com/aura-nexus/soc-os/discussions)

---

**Note**: This is a production-grade cybersecurity platform. Ensure proper security configurations before deploying to production environments.
