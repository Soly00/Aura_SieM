export interface Tenant {
  id: string;
  name: string;
  logo?: string;
  region: string;
  status: 'active' | 'suspended';
}

export type Severity = 'low' | 'medium' | 'high' | 'critical';

export interface Threat {
  id: string;
  type: string;
  source: string;
  target: string;
  timestamp: string;
  severity: Severity;
  lat: number;
  lng: number;
  targetLat: number;
  targetLng: number;
  description: string;
  status: 'active' | 'contained' | 'investigating';
}

export interface SecurityEvent {
  id: string;
  timestamp: string;
  source: string;
  event_type: string;
  user?: string;
  destination_ip?: string;
  category: string;
  details: string;
  severity: Severity;
}

export interface ForensicArtifact {
  id: string;
  name: string;
  type: 'file' | 'registry' | 'process' | 'network' | 'memory';
  hash?: string;
  path?: string;
  timestamp: string;
  suspicious: boolean;
  score: number;
}

export interface ThreatIntel {
  id: string;
  indicator: string;
  type: 'ip' | 'domain' | 'hash' | 'email';
  threat_actor?: string;
  confidence: number;
  first_seen: string;
  last_seen: string;
  tags: string[];
}

export interface AnalystRole {
  id: 'analyst' | 'manager' | 'ciso' | 'mssp';
  name: string;
  permissions: string[];
}

export interface SOCMetric {
  label: string;
  value: number | string;
  change: number;
  trend: 'up' | 'down' | 'neutral';
}
