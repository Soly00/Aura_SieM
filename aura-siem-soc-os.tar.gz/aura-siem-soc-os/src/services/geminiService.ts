import { GoogleGenAI } from "@google/genai";
import { SecurityEvent } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function analyzeSecurityEvent(event: SecurityEvent) {
  try {
    const prompt = `
      You are an expert SOC Level 3 Analyst. Analyze the following security event and provide:
      1. Summary of the threat
      2. MITRE ATT&CK Mapping
      3. Recommended Remediation Steps
      4. Risk Score (0-100)

      Event Details:
      - Type: ${event.event_type}
      - Source: ${event.source}
      - Target: ${event.target}
      - Severity: ${event.severity}
      - Timestamp: ${event.timestamp}
      - Description: ${event.description}

      Format your response in professional markdown with clear headings. Use a tactical, enterprise tone.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{ parts: [{ text: prompt }] }],
    });

    return response.text;
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return "Failed to initialize cognitive analysis chain. Please check system logs.";
  }
}

export async function generateSocReport(events: SecurityEvent[]) {
  try {
    const prompt = `
      Generate an executive SOC summary report for the CISO based on the following recent events:
      ${JSON.stringify(events.slice(0, 5))}

      Provide a high-level overview of the threat landscape and recommended strategic actions.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{ parts: [{ text: prompt }] }],
    });

    return response.text;
  } catch (error) {
    return "Error generating executive summary.";
  }
}
