import { GoogleGenAI } from "@google/genai";
import { SecurityEvent } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function investigateEvent(event: SecurityEvent) {
  const prompt = `
    You are an expert Tier-3 SOC Analyst. 
    Analyze the following security event and provide:
    1. A concise executive summary of the risk.
    2. Recommended immediate containment actions.
    3. Potential root causes to investigate.
    4. Likelihood of this being a false positive (0-100%).

    EVENT DETAILS:
    - ID: ${event.id}
    - Type: ${event.event_type}
    - Severity: ${event.severity}
    - Source: ${event.source}
    - User: ${event.user || 'Unknown'}
    - Category: ${event.category}
    - Details: ${event.details}

    Format your response in a structured markdown style suitable for a tactical dashboard.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("AI Investigation failed:", error);
    return "Error: AI Analyst is currently offline or unable to process the request.";
  }
}

export async function summarizeThreatFeed(threats: any[]) {
  const prompt = `
    Summarize the current global threat landscape based on these active alerts:
    ${JSON.stringify(threats.slice(0, 5))}
    
    Identify patterns (e.g., specific countries being targeted, common attack types).
    Be extremely brief and technical.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    return "Summary unavailable.";
  }
}
