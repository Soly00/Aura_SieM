import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AnalystRole, Tenant } from '../types';

// Enhanced permission types
export type Permission = 
  | 'dashboard.view'
  | 'dashboard.edit'
  | 'logs.view'
  | 'logs.search'
  | 'logs.export'
  | 'incidents.view'
  | 'incidents.create'
  | 'incidents.assign'
  | 'incidents.resolve'
  | 'incidents.escalate'
  | 'forensics.view'
  | 'forensics.collect'
  | 'forensics.analyze'
  | 'threat_intel.view'
  | 'threat_intel.import'
  | 'threat_intel.manage'
  | 'rules.view'
  | 'rules.create'
  | 'rules.edit'
  | 'rules.deploy'
  | 'users.view'
  | 'users.create'
  | 'users.edit'
  | 'users.manage'
  | 'admin.system'
  | 'admin.tenant'
  | 'reports.view'
  | 'reports.create'
  | 'api.access'
  | 'simulation.run'
  | 'simulation.view';

export interface User {
  id: string;
  email: string;
  username: string;
  fullName: string;
  role: AnalystRole;
  department?: string;
  status: 'active' | 'suspended' | 'pending' | 'inactive';
  lastLogin?: string;
  mfaEnabled: boolean;
  permissions: Permission[];
  preferences: UserPreferences;
}

export interface UserPreferences {
  theme: 'dark' | 'light';
  language: string;
  timezone: string;
  notifications: {
    email: boolean;
    push: boolean;
    critical: boolean;
    assigned: boolean;
  };
  dashboard: {
    defaultView: string;
    refreshInterval: number;
    compactMode: boolean;
  };
}

interface AuthContextType {
  user: User | null;
  tenant: Tenant | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  hasPermission: (permission: Permission) => boolean;
  hasAnyPermission: (permissions: Permission[]) => boolean;
  hasAllPermissions: (permissions: Permission[]) => boolean;
  switchTenant: (tenantId: string) => Promise<boolean>;
  updateUserPreferences: (preferences: Partial<UserPreferences>) => void;
  isLoading: boolean;
  error: string | null;
}

// Role-based permission mappings
const ROLE_PERMISSIONS: Record<AnalystRole['id'], Permission[]> = {
  super_admin: [
    'dashboard.view', 'dashboard.edit',
    'logs.view', 'logs.search', 'logs.export',
    'incidents.view', 'incidents.create', 'incidents.assign', 'incidents.resolve', 'incidents.escalate',
    'forensics.view', 'forensics.collect', 'forensics.analyze',
    'threat_intel.view', 'threat_intel.import', 'threat_intel.manage',
    'rules.view', 'rules.create', 'rules.edit', 'rules.deploy',
    'users.view', 'users.create', 'users.edit', 'users.manage',
    'admin.system', 'admin.tenant',
    'reports.view', 'reports.create',
    'api.access',
    'simulation.run', 'simulation.view'
  ],
  soc_manager: [
    'dashboard.view', 'dashboard.edit',
    'logs.view', 'logs.search', 'logs.export',
    'incidents.view', 'incidents.create', 'incidents.assign', 'incidents.resolve', 'incidents.escalate',
    'forensics.view', 'forensics.collect', 'forensics.analyze',
    'threat_intel.view', 'threat_intel.import',
    'rules.view', 'rules.create', 'rules.edit',
    'users.view', 'users.create', 'users.edit',
    'reports.view', 'reports.create',
    'api.access',
    'simulation.view'
  ],
  tier2_analyst: [
    'dashboard.view',
    'logs.view', 'logs.search', 'logs.export',
    'incidents.view', 'incidents.create', 'incidents.assign', 'incidents.resolve',
    'forensics.view', 'forensics.collect', 'forensics.analyze',
    'threat_intel.view', 'threat_intel.import',
    'rules.view', 'rules.create', 'rules.edit',
    'reports.view',
    'api.access'
  ],
  tier1_analyst: [
    'dashboard.view',
    'logs.view', 'logs.search',
    'incidents.view', 'incidents.create',
    'reports.view'
  ],
  forensic_analyst: [
    'dashboard.view',
    'logs.view', 'logs.search', 'logs.export',
    'incidents.view', 'incidents.assign',
    'forensics.view', 'forensics.collect', 'forensics.analyze',
    'threat_intel.view', 'threat_intel.import',
    'reports.view',
    'api.access'
  ],
  ciso: [
    'dashboard.view',
    'incidents.view',
    'threat_intel.view',
    'reports.view', 'reports.create',
    'users.view'
  ],
  mssp: [
    'dashboard.view',
    'logs.view', 'logs.search',
    'incidents.view',
    'forensics.view',
    'threat_intel.view',
    'reports.view',
    'api.access'
  ]
};

// Sample users for demonstration
const SAMPLE_USERS: User[] = [
  {
    id: 'user-001',
    email: 'admin@cyberdyne.com',
    username: 'admin',
    fullName: 'SOC Administrator',
    role: { id: 'soc_manager', name: 'SOC Manager', permissions: [] },
    department: 'Security Operations',
    status: 'active',
    lastLogin: new Date().toISOString(),
    mfaEnabled: true,
    permissions: ROLE_PERMISSIONS.soc_manager,
    preferences: {
      theme: 'dark',
      language: 'en',
      timezone: 'UTC',
      notifications: {
        email: true,
        push: true,
        critical: true,
        assigned: true
      },
      dashboard: {
        defaultView: 'dashboard',
        refreshInterval: 30,
        compactMode: false
      }
    }
  },
  {
    id: 'user-002',
    email: 'analyst1@cyberdyne.com',
    username: 'analyst1',
    fullName: 'John Smith',
    role: { id: 'tier2_analyst', name: 'Tier 2 Analyst', permissions: [] },
    department: 'Security Operations',
    status: 'active',
    lastLogin: new Date().toISOString(),
    mfaEnabled: false,
    permissions: ROLE_PERMISSIONS.tier2_analyst,
    preferences: {
      theme: 'dark',
      language: 'en',
      timezone: 'UTC',
      notifications: {
        email: true,
        push: false,
        critical: true,
        assigned: true
      },
      dashboard: {
        defaultView: 'dashboard',
        refreshInterval: 15,
        compactMode: true
      }
    }
  },
  {
    id: 'user-003',
    email: 'analyst2@cyberdyne.com',
    username: 'analyst2',
    fullName: 'Jane Doe',
    role: { id: 'tier1_analyst', name: 'Tier 1 Analyst', permissions: [] },
    department: 'Security Operations',
    status: 'active',
    lastLogin: new Date(Date.now() - 86400000).toISOString(),
    mfaEnabled: false,
    permissions: ROLE_PERMISSIONS.tier1_analyst,
    preferences: {
      theme: 'dark',
      language: 'en',
      timezone: 'UTC',
      notifications: {
        email: false,
        push: true,
        critical: true,
        assigned: false
      },
      dashboard: {
        defaultView: 'dashboard',
        refreshInterval: 10,
        compactMode: true
      }
    }
  },
  {
    id: 'user-004',
    email: 'forensic@cyberdyne.com',
    username: 'forensic',
    fullName: 'Mike Wilson',
    role: { id: 'forensic_analyst', name: 'Forensic Analyst', permissions: [] },
    department: 'Digital Forensics',
    status: 'active',
    lastLogin: new Date(Date.now() - 3600000).toISOString(),
    mfaEnabled: true,
    permissions: ROLE_PERMISSIONS.forensic_analyst,
    preferences: {
      theme: 'dark',
      language: 'en',
      timezone: 'UTC',
      notifications: {
        email: true,
        push: true,
        critical: true,
        assigned: true
      },
      dashboard: {
        defaultView: 'forensics',
        refreshInterval: 60,
        compactMode: false
      }
    }
  }
];

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [tenant, setTenant] = useState<Tenant | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Initialize with first user for demo
  useEffect(() => {
    const storedUser = localStorage.getItem('aura_nexus_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    } else {
      // Auto-login with admin user for demo
      setUser(SAMPLE_USERS[0]);
      localStorage.setItem('aura_nexus_user', JSON.stringify(SAMPLE_USERS[0]));
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Find user by email (in real app, this would be an API call)
      const foundUser = SAMPLE_USERS.find(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (!foundUser) {
        setError('Invalid credentials');
        return false;
      }
      
      // In real app, verify password hash
      if (password !== 'demo123') {
        setError('Invalid credentials');
        return false;
      }
      
      // Update last login
      const updatedUser = {
        ...foundUser,
        lastLogin: new Date().toISOString()
      };
      
      setUser(updatedUser);
      localStorage.setItem('aura_nexus_user', JSON.stringify(updatedUser));
      return true;
      
    } catch (err) {
      setError('Login failed. Please try again.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setTenant(null);
    localStorage.removeItem('aura_nexus_user');
    localStorage.removeItem('aura_nexus_tenant');
  };

  const hasPermission = (permission: Permission): boolean => {
    if (!user) return false;
    return user.permissions.includes(permission);
  };

  const hasAnyPermission = (permissions: Permission[]): boolean => {
    if (!user) return false;
    return permissions.some(permission => user.permissions.includes(permission));
  };

  const hasAllPermissions = (permissions: Permission[]): boolean => {
    if (!user) return false;
    return permissions.every(permission => user.permissions.includes(permission));
  };

  const switchTenant = async (tenantId: string): Promise<boolean> => {
    setIsLoading(true);
    
    try {
      // Simulate API call to switch tenant
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // In real app, validate user has access to tenant
      const newTenant = {
        id: tenantId,
        name: `Tenant ${tenantId}`,
        region: 'US-EAST-1',
        status: 'active' as const
      };
      
      setTenant(newTenant);
      localStorage.setItem('aura_nexus_tenant', JSON.stringify(newTenant));
      return true;
      
    } catch (err) {
      setError('Failed to switch tenant');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const updateUserPreferences = (preferences: Partial<UserPreferences>) => {
    if (!user) return;
    
    const updatedUser = {
      ...user,
      preferences: {
        ...user.preferences,
        ...preferences
      }
    };
    
    setUser(updatedUser);
    localStorage.setItem('aura_nexus_user', JSON.stringify(updatedUser));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        tenant,
        login,
        logout,
        hasPermission,
        hasAnyPermission,
        hasAllPermissions,
        switchTenant,
        updateUserPreferences,
        isLoading,
        error
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Permission guard component
export const PermissionGuard: React.FC<{
  children: ReactNode;
  permissions: Permission | Permission[];
  requireAll?: boolean;
  fallback?: ReactNode;
}> = ({ children, permissions, requireAll = false, fallback = null }) => {
  const { hasPermission, hasAnyPermission, hasAllPermissions } = useAuth();
  
  const permissionArray = Array.isArray(permissions) ? permissions : [permissions];
  const hasAccess = requireAll 
    ? hasAllPermissions(permissionArray)
    : hasAnyPermission(permissionArray);
  
  return <>{hasAccess ? children : fallback}</>;
};

// Hook for role-based UI rendering
export const useRoleBasedUI = () => {
  const { user } = useAuth();
  
  const canViewDashboard = user?.permissions.includes('dashboard.view') ?? false;
  const canViewLogs = user?.permissions.includes('logs.view') ?? false;
  const canViewIncidents = user?.permissions.includes('incidents.view') ?? false;
  const canViewForensics = user?.permissions.includes('forensics.view') ?? false;
  const canViewThreatIntel = user?.permissions.includes('threat_intel.view') ?? false;
  const canManageUsers = user?.permissions.includes('users.manage') ?? false;
  const canRunSimulation = user?.permissions.includes('simulation.run') ?? false;
  const canAccessAdmin = user?.permissions.includes('admin.system') ?? false;
  
  return {
    canViewDashboard,
    canViewLogs,
    canViewIncidents,
    canViewForensics,
    canViewThreatIntel,
    canManageUsers,
    canRunSimulation,
    canAccessAdmin,
    isTier1: user?.role.id === 'tier1_analyst',
    isTier2: user?.role.id === 'tier2_analyst',
    isManager: user?.role.id === 'soc_manager',
    isForensic: user?.role.id === 'forensic_analyst',
    isCISO: user?.role.id === 'ciso',
    isAdmin: user?.role.id === 'super_admin'
  };
};
