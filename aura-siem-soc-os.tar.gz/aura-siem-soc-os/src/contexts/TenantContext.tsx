import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Tenant } from '../types';

interface TenantContextType {
  currentTenant: Tenant;
  tenants: Tenant[];
  setTenant: (tenantId: string) => void;
}

const DEFAULT_TENANTS: Tenant[] = [
  { id: 'T-001', name: 'Cyberdyne Systems', region: 'US-EAST-1', status: 'active' },
  { id: 'T-002', name: 'Stark Industries', region: 'EU-WEST-2', status: 'active' },
  { id: 'T-003', name: 'Weyland-Yutani Corp', region: 'AP-SOUTH-1', status: 'active' },
];

const TenantContext = createContext<TenantContextType | undefined>(undefined);

export const TenantProvider = ({ children }: { children: ReactNode }) => {
  const [currentTenant, setCurrentTenant] = useState<Tenant>(DEFAULT_TENANTS[0]);

  const setTenant = (tenantId: string) => {
    const tenant = DEFAULT_TENANTS.find(t => t.id === tenantId);
    if (tenant) setCurrentTenant(tenant);
  };

  return (
    <TenantContext.Provider value={{ currentTenant, tenants: DEFAULT_TENANTS, setTenant }}>
      {children}
    </TenantContext.Provider>
  );
};

export const useTenant = () => {
  const context = useContext(TenantContext);
  if (!context) throw new Error('useTenant must be used within a TenantProvider');
  return context;
};
