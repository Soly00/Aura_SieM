/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import { 
  Shield, 
  Activity, 
  Globe, 
  FileSearch, 
  Zap, 
  LayoutDashboard, 
  Settings, 
  Menu, 
  X, 
  Bell, 
  Cpu, 
  Hash,
  Database,
  Lock,
  UserCheck,
  AlertTriangle,
  Monitor
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import { Threat, SecurityEvent, AnalystRole } from './types';
import { generateRandomThreat, generateRandomEvent } from './mockData';

// Sub-components
import MainDashboard from './components/MainDashboard';
import LiveSocMode from './components/LiveSocMode';
import ForensicsModule from './components/ForensicsModule';
import ThreatFeed from './components/ThreatFeed';
import AIAnalystOverlay from './components/AIAnalystOverlay';
import RoleSwitcher, { ROLES } from './components/RoleSwitcher';
import TenantSwitcher from './components/TenantSwitcher';
import SimulationEngine from './components/SimulationEngine';
import { useTenant } from './contexts/TenantContext';

type ViewMode = 'dashboard' | 'live-soc' | 'forensics' | 'threat-intel' | 'identity' | 'logs' | 'red-vs-blue';

export default function App() {
  const { currentTenant } = useTenant();
  const [activeView, setActiveView] = useState<ViewMode>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [threats, setThreats] = useState<Threat[]>([]);
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [criticalAlerts, setCriticalAlerts] = useState<number>(0);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [investigatingEvent, setInvestigatingEvent] = useState<SecurityEvent | null>(null);
  const [currentRole, setCurrentRole] = useState<AnalystRole>(ROLES[0]);

  // Real-time telemetry simulation (Kafka-style ingestion)
  useEffect(() => {
    const threatInterval = setInterval(() => {
      const newThreat = generateRandomThreat();
      setThreats(prev => [newThreat, ...prev].slice(0, 50));
      if (newThreat.severity === 'critical') {
        setCriticalAlerts(c => c + 1);
      }
    }, 4000);

    const eventInterval = setInterval(() => {
      const newEvent = generateRandomEvent();
      setEvents(prev => [newEvent, ...prev].slice(0, 100));
    }, 1500);

    return () => {
      clearInterval(threatInterval);
      clearInterval(eventInterval);
    };
  }, []);

  const handleInvestigate = (event: SecurityEvent) => {
    setInvestigatingEvent(event);
    setIsAiOpen(true);
  };

  const navItems = [
    { id: 'dashboard', label: 'Command Center', icon: LayoutDashboard },
    { id: 'live-soc', label: 'Live SOC Ops', icon: Globe },
    { id: 'forensics', label: 'DFIR Lab', icon: FileSearch },
    { id: 'threat-intel', label: 'Threat Intel', icon: Zap },
    { id: 'identity', label: 'IAM Analytics', icon: UserCheck },
    { id: 'red-vs-blue', label: 'Attack Simulation', icon: Monitor },
  ];

  return (
    <div className="os-container flex h-screen w-screen overflow-hidden bg-aura-bg relative">
      <div className="vignette" />
      <div className="scanner-line" />
      <div className="grid-overlay absolute inset-0 pointer-events-none opacity-20" />

      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: sidebarOpen ? 260 : 80 }}
        className="flex flex-col border-r border-aura-border bg-aura-card/80 backdrop-blur-md z-30 h-full overflow-hidden shrink-0"
      >
        <div className="p-6 flex items-center gap-3 border-b border-aura-border">
          <div className="w-8 h-8 rounded bg-aura-cyan/10 flex items-center justify-center border border-aura-cyan/50 glow-cyan">
            <Shield className="w-5 h-5 text-aura-cyan" />
          </div>
          {sidebarOpen && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col">
              <span className="font-bold text-white tracking-wider text-sm uppercase">Aura_Nexus</span>
              <span className="text-[10px] text-aura-cyan font-mono font-medium">SOC_OS_v2.4</span>
            </motion.div>
          )}
        </div>

        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {sidebarOpen && <div className="mb-6"><TenantSwitcher /></div>}
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id as ViewMode)}
              className={cn(
                "w-full flex items-center gap-4 px-3 py-3 rounded-lg transition-all border border-transparent",
                activeView === item.id 
                  ? "bg-aura-cyan/10 text-aura-cyan border-aura-cyan/20" 
                  : "text-gray-500 hover:text-gray-300 hover:bg-white/5"
              )}
            >
              <item.icon className="w-5 h-5 shrink-0" />
              {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-aura-border space-y-4">
          {sidebarOpen && <RoleSwitcher currentRole={currentRole} onRoleChange={setCurrentRole} />}
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full flex items-center gap-4 px-3 py-3 text-gray-500 hover:text-gray-300 transition-colors"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            {sidebarOpen && <span className="text-sm">Collapse UI</span>}
          </button>
        </div>
      </motion.aside>

      {/* Main Area */}
      <main className="flex-1 flex flex-col min-w-0 relative h-full">
        {/* Header */}
        <header className="h-14 border-b border-aura-border bg-aura-card/50 backdrop-blur-sm flex items-center justify-between px-6 z-20 shrink-0">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1 bg-aura-cyan/10 border border-aura-cyan/30 rounded text-aura-cyan text-[10px] font-mono">
               <span className="opacity-50">TENANT_ID:</span>
               <span>{currentTenant.id}</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 bg-aura-red/10 border border-aura-red/30 rounded text-aura-red text-[10px] font-mono animate-pulse">
              <AlertTriangle className="w-3 h-3" />
              <span>{criticalAlerts} CRITICAL THREATS</span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex flex-col items-end mr-4">
              <span className="text-[10px] text-gray-500 font-mono italic">ACCESS_ROLE: {currentRole.name.toUpperCase()}</span>
              <span className="text-xs text-aura-cyan font-mono tracking-widest">{new Date().toLocaleTimeString()}</span>
            </div>
            
            <button className="relative p-2 text-gray-400 hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-aura-red rounded-full border-2 border-aura-bg" />
            </button>

            <button 
               onClick={() => setIsAiOpen(!isAiOpen)}
               className={cn(
                 "flex items-center gap-2 px-4 py-1.5 rounded border transition-all text-xs font-mono",
                 isAiOpen 
                  ? "bg-aura-cyan/20 border-aura-cyan text-aura-cyan shadow-[0_0_10px_rgba(15,240,252,0.3)]" 
                  : "border-aura-border text-gray-400 hover:text-aura-cyan hover:border-aura-cyan/50"
               )}
            >
              <Cpu className="w-4 h-4" />
              AI_ANALYST
            </button>
          </div>
        </header>

        {/* Content View */}
        <div className="flex-1 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full w-full"
            >
              {activeView === 'dashboard' && (
                <MainDashboard 
                  threats={threats} 
                  events={events} 
                  onInvestigate={handleInvestigate} 
                />
              )}
              {activeView === 'live-soc' && <LiveSocMode threats={threats} />}
              {activeView === 'forensics' && <ForensicsModule />}
              {activeView === 'threat-intel' && <ThreatFeed />}
              {activeView === 'red-vs-blue' && <SimulationEngine />}
              {activeView === 'identity' && (
                <div className="p-8 text-center text-gray-500 font-mono italic flex flex-col items-center justify-center h-full gap-4">
                  <UserCheck className="w-16 h-16 opacity-10" />
                  <span className="text-lg font-bold text-aura-green uppercase tracking-widest">IAM_Identity_Analytics</span>
                  <p className="max-w-md text-xs">Awaiting ingestion of cloud identity logs (AWS, Azure, GCP). Scanning for privilege escalation patterns and impossible travel anomalies.</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Real-time Ticker */}
        <footer className="h-8 border-t border-aura-border bg-aura-card flex items-center px-4 z-20 shrink-0 overflow-hidden">
          <div className="flex items-center gap-4 text-[10px] font-mono whitespace-nowrap">
            <span className="text-aura-cyan uppercase italic">Pipeline Status:</span>
            <span className="text-aura-green font-bold">ONLINE</span>
            <div className="w-[1px] h-3 bg-aura-border mx-2" />
            <span className="text-gray-500">INGESTION_RATE: 1.4k events/sec</span>
            <div className="w-[1px] h-3 bg-aura-border mx-2" />
            <motion.div 
              animate={{ x: [-2000, 1000] }}
              transition={{ repeat: Infinity, duration: 60, ease: 'linear' }}
              className="text-gray-400"
            >
              {events.slice(0, 10).map(e => `[${e.severity.toUpperCase()}] ${e.source} -> ${e.event_type} (${e.category}) | `).join('')}
            </motion.div>
          </div>
        </footer>
      </main>

      {/* AI Analyst Overlay */}
      <AIAnalystOverlay 
        isOpen={isAiOpen} 
        onClose={() => setIsAiOpen(false)} 
        event={investigatingEvent}
      />
    </div>
  );
}
