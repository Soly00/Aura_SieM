import { useState, useEffect } from 'react';
import { Threat } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Globe, 
  Activity, 
  ShieldAlert, 
  Zap, 
  Maximize2, 
  Clock,
  TrendingUp,
  Target,
  Wifi,
  ChevronRight,
  AlertInnerShadow
} from 'lucide-react';
import { cn, getSeverityColor } from '../lib/utils';

interface Props {
  threats: Threat[];
}

export default function LiveSocMode({ threats }: Props) {
  const [activePanel, setActivePanel] = useState(0);
  const [currentThreat, setCurrentThreat] = useState<Threat | null>(null);

  // Auto-rotate dashboards every 15 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setActivePanel((prev) => (prev + 1) % 4);
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  // Cycle current alert highlight
  useEffect(() => {
    if (threats.length > 0) {
      const interval = setInterval(() => {
         setCurrentThreat(threats[Math.floor(Math.random() * Math.min(threats.length, 10))]);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [threats]);

  const panels = [
    { title: 'GLOBAL_THREAT_TRAJECTORY', icon: Globe },
    { title: 'ENTITY_BEHAVIOR_ANALYTICS', icon: TrendingUp },
    { title: 'INFRASTRUCTURE_VITAL_SIGNS', icon: Activity },
    { title: 'ZERO_DAY_VULNERABILITY_FEED', icon: Zap },
  ];

  return (
    <div className="h-full w-full bg-black relative flex flex-col p-4 gap-4">
      {/* Fullscreen Overlay Header */}
      <div className="flex items-center justify-between px-6 py-4 bg-aura-card border border-aura-cyan/20 rounded-lg shadow-[0_0_30px_rgba(15,240,252,0.1)]">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-aura-cyan/5 border border-aura-cyan/30 flex items-center justify-center rounded">
            <Globe className="w-8 h-8 text-aura-cyan animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-[0.3em] text-white font-mono">LIVE_SOC_OPERATIONS</h1>
            <div className="flex items-center gap-4 text-[10px] text-aura-cyan font-mono">
              <span className="flex items-center gap-1"><Wifi className="w-3 h-3" /> CONNECTED_NODES: 4,122</span>
              <span className="flex items-center gap-1 text-aura-red animate-pulse"><ShieldAlert className="w-3 h-3" /> ACTIVE_ATTACK_CAMPAIGNS: 12</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-8">
           <div className="flex flex-col items-end">
             <span className="text-[10px] text-gray-500 font-mono">PANEL_ROTATION_ID</span>
             <span className="text-lg text-aura-cyan font-mono tracking-widest uppercase">{panels[activePanel].title}</span>
           </div>
           <div className="h-10 w-[1px] bg-aura-border" />
           <div className="flex flex-col items-end">
             <span className="text-[10px] text-gray-500 font-mono">UTC_SYSTEM_CLOCK</span>
             <span className="text-lg text-white font-mono tracking-tighter">
               {new Date().toISOString().substring(11, 19)}
             </span>
           </div>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="flex-1 grid grid-cols-12 gap-4 min-h-0">
        {/* Left Column: Metrics & Ticker */}
        <div className="col-span-3 flex flex-col gap-4">
          <div className="tactical-card p-4 flex-1">
             <div className="panel-header mb-4">
               <span className="panel-title">THREAT_INTENSITY_INDEX</span>
             </div>
             <div className="space-y-6">
                {[
                  { label: 'Ingestion Delta', value: '+14%', color: 'text-aura-cyan' },
                  { label: 'Exfiltration Risk', value: 'High', color: 'text-aura-red' },
                  { label: 'Identity Clusters', value: '822', color: 'text-aura-green' },
                  { label: 'Avg Latency', value: '24ms', color: 'text-aura-cyan' },
                ].map(metric => (
                  <div key={metric.label}>
                    <div className="flex justify-between text-[10px] font-mono text-gray-500 mb-1">
                      <span>{metric.label.toUpperCase()}</span>
                      <span className={metric.color}>{metric.value}</span>
                    </div>
                    <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.random() * 60 + 20}%` }}
                        className={cn("h-full", metric.color.replace('text', 'bg'))}
                      />
                    </div>
                  </div>
                ))}
             </div>
          </div>

          <div className="tactical-card p-4 h-1/3">
            <div className="panel-header mb-4">
               <span className="panel-title">SYSTEM_HEALTH_STREAM</span>
             </div>
             <div className="text-[8px] font-mono text-gray-500 space-y-1">
                {Array.from({length: 12}).map((_, i) => (
                  <div key={i} className="flex gap-2">
                    <span className="text-aura-cyan">[{Math.random().toString(36).substring(7).toUpperCase()}]</span>
                    <span className="text-aura-green">SUCESS</span>
                    <span className="truncate">Service worker node refreshed cluster ${i}...</span>
                  </div>
                ))}
             </div>
          </div>
        </div>

        {/* Center Canvas: Attack Map */}
        <div className="col-span-6 tactical-card bg-black/60 relative p-0 overflow-hidden group">
           <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000')] bg-cover bg-center brightness-[0.2]" />
           <div className="absolute inset-0 grid-overlay opacity-30" />
           
           {/* Animated Legend Overlay */}
           <div className="absolute top-4 left-4 p-3 bg-aura-card/80 border border-aura-border rounded text-[10px] font-mono z-20">
             <div className="flex items-center gap-2 mb-2">
               <div className="w-2 h-2 rounded-full bg-aura-red animate-pulse" />
               <span className="text-white">CRITICAL_VECTOR</span>
             </div>
             <div className="flex items-center gap-2 mb-2">
               <div className="w-2 h-2 rounded-full bg-aura-cyan animate-pulse" />
               <span className="text-white">ESTABLISHED_COMMS</span>
             </div>
             <div className="flex items-center gap-2">
               <div className="w-2 h-2 rounded-full bg-aura-green" />
               <span className="text-white">NODE_STABLE</span>
             </div>
           </div>

           {/* Central Map HUD */}
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center p-0 w-full h-full pointer-events-none">
              <div className="w-[600px] h-[600px] border border-aura-cyan/10 rounded-full animate-pulse-slow absolute" />
              <div className="w-[450px] h-[450px] border border-aura-cyan/5 rounded-full absolute" />
              <div className="w-[300px] h-[300px] border border-aura-cyan/20 rounded-full animate-spin-slow absolute border-dashed" />
              
              <div className="text- aura-cyan opacity-20 font-mono text-[100px] font-bold">AURA</div>
           </div>

           {/* Attack Highlight */}
           <AnimatePresence>
             {currentThreat && (
               <motion.div 
                 initial={{ opacity: 0, scale: 0.8 }}
                 animate={{ opacity: 1, scale: 1 }}
                 exit={{ opacity: 0, scale: 1.1 }}
                 className="absolute inset-0 flex items-center justify-center z-10"
               >
                 <div className="w-full h-full relative">
                   <motion.div 
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    className="absolute"
                    style={{ 
                      top: '50%', 
                      left: '50%',
                      width: '4px',
                      height: '4px',
                      transform: 'translate(-50%, -50%)'
                    }}
                   >
                     {/* Dynamic Visual Attack Arc Simulation */}
                     <svg className="absolute w-[800px] h-[800px] -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                       <motion.path
                        d={`M 400,400 Q ${400 + (Math.random() - 0.5) * 400} ${400 + (Math.random() - 0.5) * 400} ${400 + (Math.random() - 0.5) * 600} ${400 + (Math.random() - 0.5) * 600}`}
                        stroke={currentThreat.severity === 'critical' ? '#ff3e3e' : '#0ff0fc'}
                        strokeWidth="2"
                        fill="transparent"
                        initial={{ pathLength: 0, opacity: 0 }}
                        animate={{ pathLength: 1, opacity: [0, 1, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                       />
                     </svg>
                   </motion.div>
                 </div>
               </motion.div>
             )}
           </AnimatePresence>

           {/* Event Log Ticker at Bottom of Map */}
           <div className="absolute bottom-4 right-4 flex flex-col gap-2 items-end">
              <AnimatePresence mode="popLayout">
                {threats.slice(0, 5).map((t, i) => (
                  <motion.div
                    key={t.id}
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className={cn(
                      "flex items-center gap-3 px-4 py-2 border border-white/10 backdrop-blur-md rounded-lg",
                      t.severity === 'critical' ? 'bg-aura-red/10 border-aura-red/30' : 'bg-aura-cyan/10 border-aura-cyan/30'
                    )}
                  >
                    <Target className={cn("w-4 h-4", t.severity === 'critical' ? 'text-aura-red' : 'text-aura-cyan')} />
                    <div className="flex flex-col">
                      <span className="text-[10px] font-bold text-white uppercase">{t.type}</span>
                      <span className="text-[8px] text-gray-500 font-mono tracking-widest">{t.source} {'>'} {t.target}</span>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
           </div>
        </div>

        {/* Right Column: Dynamic Displays */}
        <div className="col-span-3 flex flex-col gap-4 min-h-0">
          <div className="tactical-card p-4 flex-1">
            <div className="panel-header mb-4">
               <span className="panel-title">TOP_THREAT_ACTOR_GROUPS</span>
             </div>
             <div className="space-y-4">
                {[
                  { name: 'APT28 (Fancy Bear)', risk: 94, status: 'Active' },
                  { name: 'Lazarus Group', risk: 88, status: 'Monitoring' },
                  { name: 'Conti Group', risk: 82, status: 'Active' },
                  { name: 'DarkSide', risk: 78, status: 'Contained' },
                  { name: 'UNC2452', risk: 91, status: 'Hunting' },
                ].map(group => (
                  <div key={group.name} className="flex items-center justify-between p-2 bg-white/5 border border-white/5 rounded">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded bg-aura-cyan/5 border border-aura-cyan/20 flex items-center justify-center text-aura-cyan font-mono text-[8px]">
                        ACTOR
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-bold text-white uppercase">{group.name}</span>
                        <span className="text-[8px] text-gray-500 font-mono">STATUS: {group.status}</span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-[10px] text-aura-red font-mono">{group.risk}%</span>
                      <div className="w-12 h-1 bg-aura-red/20 rounded-full">
                        <div className="h-full bg-aura-red rounded-full" style={{ width: `${group.risk}%` }} />
                      </div>
                    </div>
                  </div>
                ))}
             </div>
          </div>

          <div className="tactical-card p-4 h-1/2">
            <div className="panel-header mb-4">
               <span className="panel-title">SLA_PERFORMANCE_METRICS</span>
             </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col items-center justify-center p-3 border border-white/5 bg-white/5 rounded">
                  <span className="text-xl font-bold text-aura-green font-mono">99.8%</span>
                  <span className="text-[8px] text-gray-500 uppercase tracking-widest font-mono">SLA_UPTIME</span>
                </div>
                <div className="flex flex-col items-center justify-center p-3 border border-white/5 bg-white/5 rounded">
                  <span className="text-xl font-bold text-aura-cyan font-mono">14s</span>
                  <span className="text-[8px] text-gray-500 uppercase tracking-widest font-mono">MTTD</span>
                </div>
                <div className="flex flex-col items-center justify-center p-3 border border-white/5 bg-white/5 rounded">
                  <span className="text-xl font-bold text-aura-yellow font-mono">1.2m</span>
                  <span className="text-[8px] text-gray-500 uppercase tracking-widest font-mono">MTTR</span>
                </div>
                <div className="flex flex-col items-center justify-center p-3 border border-white/5 bg-white/5 rounded">
                  <span className="text-xl font-bold text-white font-mono">12k</span>
                  <span className="text-[8px] text-gray-500 uppercase tracking-widest font-mono">EPS_FLOW</span>
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* Critical Alert Banner (Footer Overlay) */}
      <div className="h-12 bg-aura-red flex items-center justify-between px-8 relative overflow-hidden group">
         <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(0,0,0,0.1)_25%,transparent_25%,transparent_50%,rgba(0,0,0,0.1)_50%,rgba(0,0,0,0.1)_75%,transparent_75%,transparent)] bg-[length:40px_40px] animate-[slide_1s_linear_infinite]" />
         <div className="flex items-center gap-4 z-10">
           <ShieldAlert className="w-6 h-6 text-white animate-bounce" />
           <span className="text-sm font-bold text-white tracking-[0.2em] font-mono leading-none">CRITICAL_SYSTEM_ALERT: MULTIPLE_RANSOMWARE_CALLBACKS_DETECTED_IN_DMZ_SEGMENT_04</span>
         </div>
         <div className="flex items-center gap-4 z-10">
            <span className="text-xs text-white/80 font-mono">TIME_ELAPSED: 04:22:12</span>
            <button className="px-4 py-1 bg-white text-aura-red font-bold text-[10px] rounded hover:bg-gray-100 transition-colors font-mono">TRIGGER_CONTAINMENT_PROTOCOL</button>
         </div>
      </div>
      
      <style>{`
        @keyframes slide {
          from { background-position: 0 0; }
          to { background-position: 40px 0; }
        }
        .animate-spin-slow {
          animation: spin 20s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
