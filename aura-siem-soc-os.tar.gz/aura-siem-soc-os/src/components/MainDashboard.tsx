import { Threat, SecurityEvent } from '../types';
import { cn, getSeverityColor, getSeverityBg } from '../lib/utils';
import { 
  Activity, 
  ShieldAlert, 
  Server, 
  History, 
  ChevronRight, 
  Search, 
  Filter, 
  Maximize2,
  Globe
} from 'lucide-react';
import { motion } from 'motion/react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

import MitreAttackGrid from './MitreAttackGrid';

interface Props {
  threats: Threat[];
  events: SecurityEvent[];
  onInvestigate: (event: SecurityEvent) => void;
}

const chartData = [
  { time: '12:00', events: 450, threats: 12 },
  { time: '13:00', events: 520, threats: 15 },
  { time: '14:00', events: 480, threats: 10 },
  { time: '15:00', events: 610, threats: 28 },
  { time: '16:00', events: 590, threats: 22 },
  { time: '17:00', events: 720, threats: 35 },
];

export default function MainDashboard({ threats, events, onInvestigate }: Props) {
  return (
    <div className="h-full w-full p-6 flex flex-col gap-6 overflow-y-auto">
      {/* Top Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Active Threats', value: threats.length, icon: ShieldAlert, color: 'text-aura-red' },
          { label: 'Events/sec', value: '1,422', icon: Activity, color: 'text-aura-cyan' },
          { label: 'Endpoints', value: '12,840', icon: Server, color: 'text-aura-green' },
          { label: 'Mean Time to Resolve', value: '14m', icon: History, color: 'text-aura-yellow' },
        ].map((stat, i) => (
          <motion.div 
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="tactical-card p-4 flex items-center justify-between group"
          >
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">{stat.label}</p>
              <h3 className={cn("text-2xl font-mono font-bold", stat.color)}>{stat.value}</h3>
            </div>
            <div className={cn("p-3 rounded-lg bg-white/5 group-hover:scale-110 transition-transform", stat.color)}>
              <stat.icon className="w-6 h-6" />
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0">
        {/* Left Column: Attack Flow & Chart */}
        <div className="lg:col-span-2 flex flex-col gap-6 min-h-0">
          {/* Attack Visualization (Placeholder for Map) */}
          <div className="tactical-card flex-1 min-h-[400px] flex flex-col">
            <div className="panel-header">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-aura-cyan" />
                <span className="panel-title">GLOBAL_ATTACK_SURFACE_RADAR</span>
              </div>
              <div className="flex gap-2">
                <button className="p-1 hover:bg-white/10 rounded"><Maximize2 className="w-3 h-3" /></button>
              </div>
            </div>
            <div className="flex-1 relative bg-black/40 overflow-hidden group">
               {/* Simplified Tactical Map Background */}
               <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=2000')] bg-cover bg-center grayscale" />
               
               {/* Simulated Pulsing Threat Nodes */}
               {threats.slice(0, 8).map((threat) => (
                 <motion.div
                    key={threat.id}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: [1, 2, 1], opacity: [0.5, 1, 0.5] }}
                    transition={{ repeat: Infinity, duration: 3 }}
                    style={{ 
                      top: `${Math.abs(threat.lat) % 100}%`, 
                      left: `${Math.abs(threat.lng) % 100}%` 
                    }}
                    className={cn(
                      "absolute w-3 h-3 rounded-full blur-[2px]",
                      threat.severity === 'critical' ? 'bg-aura-red' : 'bg-aura-cyan'
                    )}
                 />
               ))}

               <div className="absolute bottom-4 left-4 flex flex-col gap-1">
                 <div className="text-[10px] text-aura-cyan font-mono animate-pulse">SYSTEM_SCANNING_IN_PROGRESS...</div>
                 <div className="text-xs text-gray-500 font-mono">LAT: 34.0522° N | LNG: 118.2437° W</div>
               </div>
            </div>
          </div>

          {/* System Performance Chart */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 min-h-0">
            <div className="tactical-card h-48">
              <div className="panel-header">
                <span className="panel-title">TELEMETRY_PIPELINE_THROUGHPUT</span>
              </div>
              <div className="p-4 h-[calc(100%-40px)]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorEv" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0ff0fc" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#0ff0fc" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Area type="monotone" dataKey="events" stroke="#0ff0fc" fillOpacity={1} fill="url(#colorEv)" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#080c10', border: '1px solid rgba(15,240,252,0.1)', fontSize: '10px' }}
                      itemStyle={{ color: '#0ff0fc' }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="tactical-card h-48">
               <MitreAttackGrid />
            </div>
          </div>
        </div>

        {/* Right Column: Live Event Stream */}
        <div className="tactical-card flex flex-col min-h-0">
          <div className="panel-header">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-aura-cyan" />
              <span className="panel-title">REAL_TIME_EVENT_LOGS</span>
            </div>
            <div className="flex gap-2">
              <Filter className="w-3 h-3 text-gray-500" />
              <Search className="w-3 h-3 text-gray-500" />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto font-mono text-[11px]">
            {events.map((event, idx) => (
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                key={event.id}
                className={cn(
                  "p-3 border-b border-aura-border hover:bg-white/5 transition-colors group cursor-pointer relative",
                  event.severity === 'critical' ? 'border-l-2 border-l-aura-red' : ''
                )}
                onClick={() => onInvestigate(event)}
              >
                <div className="flex justify-between mb-1">
                  <span className={cn("font-bold", getSeverityColor(event.severity))}>
                    {event.severity.toUpperCase()}
                  </span>
                  <span className="text-gray-600">{event.timestamp.split(' ')[1]}</span>
                </div>
                <div className="text-gray-300 mb-1 truncate">
                  <span className="text-aura-cyan">[{event.source}]</span> {event.event_type}
                </div>
                <div className="text-gray-500 text-[10px] break-all">{event.details}</div>
                
                <div className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex items-center gap-1 text-aura-cyan bg-aura-cyan/10 px-2 py-0.5 rounded border border-aura-cyan/30">
                    <span className="text-[9px]">INVESTIGATE</span>
                    <ChevronRight className="w-3 h-3" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
