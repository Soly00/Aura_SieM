import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Send, 
  Brain, 
  Loader2, 
  AlertTriangle, 
  CheckCircle, 
  Info,
  TrendingUp,
  Shield,
  Target,
  Clock,
  User,
  FileText,
  Zap,
  Globe,
  Search,
  Lightbulb,
  Activity
} from 'lucide-react';
import { SecurityEvent } from '../types';
import { analyzeSecurityEvent } from '../services/geminiService';
import Markdown from 'react-markdown';
import { cn } from '../lib/utils';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  event: SecurityEvent | null;
}

export default function AIAnalystOverlay({ isOpen, onClose, event }: Props) {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && event) {
      performInvestigation(event);
    } else if (!isOpen) {
      setAnalysis(null);
    }
  }, [isOpen, event]);

  const performInvestigation = async (e: SecurityEvent) => {
    setLoading(true);
    const result = await analyzeSecurityEvent(e);
    setAnalysis(result || "Investigation failed to return results.");
    setLoading(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 20, stiffness: 100 }}
          className="fixed top-0 right-0 w-full md:w-[500px] lg:w-[600px] h-screen bg-aura-card border-l border-aura-border z-50 shadow-[-20px_0_40px_rgba(0,0,0,0.8)] flex flex-col"
        >
          {/* Header */}
          <div className="p-6 border-b border-aura-border bg-aura-bg/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-aura-cyan/10 flex items-center justify-center border border-aura-cyan/30">
                <Cpu className="w-6 h-6 text-aura-cyan" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white tracking-tight">AUTONOMOUS_AI_ANALYST</h2>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-aura-green rounded-full animate-pulse" />
                  <span className="text-[10px] text-aura-green font-mono uppercase tracking-widest">Cognitive Engine Active</span>
                </div>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors text-gray-500"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Analysis View */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
            {event && (
              <div className="p-4 bg-white/5 border border-aura-border rounded-lg">
                <div className="text-[10px] text-gray-500 mb-2 font-mono uppercase">Analyzing Target:</div>
                <div className="flex justify-between items-start">
                  <div>
                    <div className="text-aura-cyan font-mono text-sm font-bold">{event.event_type}</div>
                    <div className="text-xs text-gray-400">{event.source} | {event.user || 'Unknown User'}</div>
                  </div>
                  <div className={cn(
                    "px-2 py-0.5 rounded text-[10px] font-mono",
                    event.severity === 'critical' ? 'bg-aura-red/20 text-aura-red' : 'bg-aura-cyan/20 text-aura-cyan'
                  )}>
                    {event.severity.toUpperCase()}
                  </div>
                </div>
              </div>
            )}

            {loading ? (
              <div className="flex flex-col items-center justify-center h-64 gap-4 text-aura-cyan">
                <Loader2 className="w-10 h-10 animate-spin" />
                <div className="text-xs font-mono animate-pulse uppercase tracking-[0.2em]">Correlating Evidence...</div>
                <div className="text-[10px] text-gray-600 max-w-[250px] text-center italic">
                  Running heuristic analysis against known threat patterns and behavioral anomalies.
                </div>
              </div>
            ) : analysis ? (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }}
                className="prose prose-invert prose-aura max-w-none font-sans"
              >
                <div className="markdown-body">
                   <Markdown>{analysis}</Markdown>
                </div>
                
                <div className="mt-8 pt-8 border-t border-aura-border space-y-4">
                  <h3 className="text-[10px] text-gray-500 font-mono uppercase tracking-[0.2em] mb-4">Tactical Recommendations</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <button className="flex items-center gap-2 p-3 bg-aura-red/10 border border-aura-red/30 rounded text-aura-red text-xs hover:bg-aura-red/20 transition-all font-mono font-bold">
                      <ShieldCheck className="w-4 h-4" />
                      ISOLATE_SOURCE
                    </button>
                    <button className="flex items-center gap-2 p-3 bg-aura-cyan/10 border border-aura-cyan/30 rounded text-aura-cyan text-xs hover:bg-aura-cyan/20 transition-all font-mono font-bold">
                      <Terminal className="w-4 h-4" />
                      MEM_DUMP_FULL
                    </button>
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 gap-4 text-gray-600 border-2 border-dashed border-aura-border rounded-xl">
                <Zap className="w-12 h-12 opacity-20" />
                <div className="text-xs font-mono text-center">SELECT_AN_EVENT_TO_BEGIN_ANALYSIS</div>
              </div>
            )}
          </div>

          {/* Footer Metrics */}
          <div className="p-4 border-t border-aura-border bg-aura-bg/30 flex items-center justify-between text-[10px] text-gray-600 font-mono">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1"><BarChart4 className="w-3 h-3 text-aura-cyan" /> Confidence: 94%</span>
              <span className="flex items-center gap-1"><Zap className="w-3 h-3 text-aura-yellow" /> Pattern: Lateral_MV</span>
            </div>
            <button className="flex items-center gap-1 hover:text-aura-cyan transition-colors">
              REPORT_ISSUE <ExternalLink className="w-3 h-3" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
