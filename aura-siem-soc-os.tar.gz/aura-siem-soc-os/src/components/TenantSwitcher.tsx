import { useTenant } from '../contexts/TenantContext';
import { Building2, ChevronDown, Check } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export default function TenantSwitcher() {
  const { currentTenant, tenants, setTenant } = useTenant();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center gap-3 px-3 py-2 bg-aura-cyan/5 border border-aura-cyan/20 rounded hover:bg-aura-cyan/10 transition-all group"
      >
        <div className="flex-1 text-left">
          <div className="text-[8px] text-aura-cyan font-mono uppercase tracking-[0.2em] mb-0.5">Active_Tenant</div>
          <div className="text-xs font-bold text-white font-mono flex items-center gap-2">
            <Building2 className="w-3 h-3 text-aura-cyan" />
            {currentTenant.name}
          </div>
        </div>
        <ChevronDown className={cn("w-3 h-3 text-gray-500 transition-transform", isOpen && "rotate-180")} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute top-full left-0 right-0 mt-2 bg-aura-card border border-aura-border rounded-lg shadow-2xl z-50 overflow-hidden"
          >
            {tenants.map((tenant) => (
              <button
                key={tenant.id}
                onClick={() => {
                  setTenant(tenant.id);
                  setIsOpen(false);
                }}
                className={cn(
                  "w-full flex items-center justify-between px-4 py-3 text-xs font-mono transition-all hover:bg-white/5",
                  currentTenant.id === tenant.id ? "text-aura-cyan bg-aura-cyan/5" : "text-gray-400"
                )}
              >
                <span>{tenant.name}</span>
                {currentTenant.id === tenant.id && <Check className="w-3 h-3" />}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
