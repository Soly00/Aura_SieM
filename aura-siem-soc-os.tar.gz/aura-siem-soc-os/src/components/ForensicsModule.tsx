import { useState } from 'react';
import { MOCK_FORENSICS } from '../mockData';
import { ForensicArtifact } from '../types';
import { 
  FileSearch, 
  History, 
  Search, 
  FileText, 
  Terminal, 
  Cpu, 
  Network, 
  Fingerprint,
  ChevronRight,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

export default function ForensicsModule() {
  const [artifacts, setArtifacts] = useState<ForensicArtifact[]>(MOCK_FORENSICS);
  const [selectedArtifact, setSelectedArtifact] = useState<ForensicArtifact | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const attackChain = [
    { step: 1, action: 'Initial Access', details: 'Phishing email with malicious attachment opened by user "jsmith".', time: '14:02:11' },
    { step: 2, action: 'Execution', details: 'PowerShell script executed via Word macro, bypassing AMSI.', time: '14:05:44' },
    { step: 3, action: 'Persistence', details: 'Registry key created in HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce.', time: '14:18:45' },
    { step: 4, action: 'Lateral Movement', details: 'SMB connection established to SRV-DC-01 using stolen credentials.', time: '14:28:30' },
    { step: 5, action: 'Exfiltration', details: '1.2GB of encrypted data sent to remote IP 185[.]234[.]x[.]x.', time: '14:45:00' },
  ];

  return (
    <div className="h-full w-full p-6 flex flex-col gap-6 overflow-hidden">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FileSearch className="w-6 h-6 text-aura-cyan" />
          <h1 className="text-xl font-bold tracking-tight text-white">DIGITAL_FORENSICS_CASE_MANAGEMENT</h1>
        </div>
        <div className="flex items-center gap-2">
          <div className="px-3 py-1 bg-white/5 border border-aura-border rounded flex items-center gap-2">
            <span className="text-[10px] text-gray-500 font-mono">CASE_ID:</span>
            <span className="text-xs text-aura-cyan font-mono font-bold">AURA-2024-0508-A</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6 flex-1 min-h-0">
        {/* Left Column: Artifact Explorer */}
        <div className="col-span-12 lg:col-span-8 flex flex-col gap-6 min-h-0">
          <div className="tactical-card flex-1 flex flex-col min-h-0">
             <div className="panel-header">
               <div className="flex items-center gap-4 flex-1">
                 <span className="panel-title">EVIDENCE_ARTIFACT_EXPLORER</span>
                 <div className="relative flex-1 max-w-xs">
                   <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-500" />
                   <input 
                    type="text" 
                    placeholder="Search artifacts, hashes, paths..."
                    className="w-full bg-black/50 border border-aura-border rounded px-8 py-1.5 text-xs font-mono outline-none focus:border-aura-cyan/50"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                   />
                 </div>
               </div>
             </div>

             <div className="flex-1 overflow-y-auto">
               <table className="w-full text-left font-mono text-[11px] border-collapse">
                 <thead className="sticky top-0 bg-aura-card z-10 border-b border-aura-border">
                   <tr>
                     <th className="p-4 text-gray-500 font-medium">TYPE</th>
                     <th className="p-4 text-gray-500 font-medium">NAME</th>
                     <th className="p-4 text-gray-500 font-medium">PATH / LOCATION</th>
                     <th className="p-4 text-gray-500 font-medium">TIMESTAMP</th>
                     <th className="p-4 text-gray-500 font-medium">RISC_SCORE</th>
                     <th className="p-4 text-gray-500 font-medium">VERDICT</th>
                   </tr>
                 </thead>
                 <tbody>
                    {artifacts.map((artifact) => (
                      <tr 
                        key={artifact.id}
                        className={cn(
                          "border-b border-aura-border hover:bg-white/5 cursor-pointer transition-colors",
                          selectedArtifact?.id === artifact.id ? "bg-aura-cyan/5" : ""
                        )}
                        onClick={() => setSelectedArtifact(artifact)}
                      >
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            {artifact.type === 'process' && <Cpu className="w-3 h-3 text-aura-cyan" />}
                            {artifact.type === 'file' && <FileText className="w-3 h-3 text-aura-yellow" />}
                            {artifact.type === 'registry' && <Terminal className="w-3 h-3 text-aura-green" />}
                            {artifact.type === 'network' && <Network className="w-3 h-3 text-blue-500" />}
                            {artifact.type === 'memory' && <Fingerprint className="w-3 h-3 text-purple-500" />}
                            <span className="text-[9px] uppercase">{artifact.type}</span>
                          </div>
                        </td>
                        <td className="p-4 font-bold text-white tracking-tight">{artifact.name}</td>
                        <td className="p-4 text-gray-500 truncate max-w-[200px]">{artifact.path || 'N/A'}</td>
                        <td className="p-4 text-gray-400">{artifact.timestamp}</td>
                        <td className="p-4">
                           <div className="flex items-center gap-2">
                             <div className="w-12 h-1.5 bg-white/5 rounded-full overflow-hidden">
                               <div 
                                className={cn("h-full", artifact.score > 70 ? "bg-aura-red" : "bg-aura-green")}
                                style={{ width: `${artifact.score}%` }}
                               />
                             </div>
                             <span className={artifact.score > 70 ? "text-aura-red" : "text-aura-green"}>{artifact.score}</span>
                           </div>
                        </td>
                        <td className="p-4">
                          {artifact.suspicious ? (
                            <span className="flex items-center gap-1 text-aura-red uppercase font-bold">
                              <AlertCircle className="w-3 h-3" /> MALICIOUS
                            </span>
                          ) : (
                             <span className="flex items-center gap-1 text-aura-green uppercase font-bold">
                              <ShieldCheck className="w-3 h-3" /> CLEAN
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                 </tbody>
               </table>
             </div>
          </div>

          <div className="tactical-card p-4 h-64 overflow-hidden flex flex-col">
            <div className="panel-header mb-4">
               <span className="panel-title">TIMELINE_RECONSTRUCTION</span>
             </div>
             <div className="flex-1 flex gap-2 overflow-x-auto pb-4 custom-scrollbar">
                {attackChain.map((event, i) => (
                  <div key={event.step} className="flex gap-2">
                    <div className="flex flex-col items-center">
                       <div className="w-6 h-6 rounded-full bg-aura-cyan/10 border border-aura-cyan/50 flex items-center justify-center text-aura-cyan text-[10px] font-bold">
                         {event.step}
                       </div>
                       {i < attackChain.length - 1 && <div className="flex-1 w-[1px] border-l border-aura-cyan/20 border-dashed" />}
                    </div>
                    <div className="w-56 p-3 bg-white/5 border border-aura-border rounded h-fit shrink-0">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-[10px] font-bold text-white uppercase">{event.action}</span>
                        <span className="text-[8px] text-gray-500 font-mono">{event.time}</span>
                      </div>
                      <p className="text-[9px] text-gray-400 font-mono leading-relaxed line-clamp-3">
                        {event.details}
                      </p>
                    </div>
                    {i < attackChain.length - 1 && (
                      <div className="flex items-center px-2">
                        <ChevronRight className="w-4 h-4 text-aura-border" />
                      </div>
                    )}
                  </div>
                ))}
             </div>
          </div>
        </div>

        {/* Right Column: Detailed Analysis Panel */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-6 min-h-0">
          <div className="tactical-card flex-1 flex flex-col min-h-0">
            <div className="panel-header">
               <span className="panel-title">ARTIFACT_DETAIL_ANALYSIS</span>
            </div>
            
            <div className="flex-1 p-6 space-y-6 overflow-y-auto">
              {selectedArtifact ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-lg bg-aura-cyan/10 border border-aura-cyan/30 flex items-center justify-center">
                       {selectedArtifact.type === 'process' && <Cpu className="w-8 h-8 text-aura-cyan" />}
                       {selectedArtifact.type === 'file' && <FileText className="w-8 h-8 text-aura-yellow" />}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white tracking-tight">{selectedArtifact.name}</h3>
                      <p className="text-xs text-gray-500 font-mono uppercase tracking-widest">{selectedArtifact.type}_ARTIFACT</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3 bg-white/5 border border-aura-border rounded">
                      <span className="text-[10px] text-gray-600 font-mono uppercase block mb-1">Threat Score</span>
                      <span className={cn("text-lg font-bold font-mono", selectedArtifact.score > 70 ? "text-aura-red" : "text-aura-green")}>
                        {selectedArtifact.score}/100
                      </span>
                    </div>
                     <div className="p-3 bg-white/5 border border-aura-border rounded">
                      <span className="text-[10px] text-gray-600 font-mono uppercase block mb-1">Investigation State</span>
                      <span className="text-lg font-bold text-aura-yellow font-mono tracking-tight uppercase">In Review</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-600 font-mono uppercase">Full System Path:</span>
                      <div className="p-3 bg-black/40 border border-aura-border rounded font-mono text-[10px] text-aura-cyan break-all">
                        {selectedArtifact.path || 'Memory Resident Only'}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[10px] text-gray-600 font-mono uppercase">Identifier Hashes:</span>
                      <div className="p-3 bg-black/40 border border-aura-border rounded font-mono text-[10px] text-gray-400 space-y-1">
                        <div className="flex justify-between">
                          <span>SHA256:</span>
                          <span className="text-aura-cyan">4F8E92B1C2D3A4F5E6B7C8D9E0F1A2B3C4D5E6F7A8B9C0D1E2F3A4B5C6D7E8F9</span>
                        </div>
                        <div className="flex justify-between">
                          <span>MD5:</span>
                          <span className="text-aura-cyan">E99A18C428CB38D5F260853678922E03</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 space-y-4">
                    <h4 className="text-[10px] text-white font-mono uppercase tracking-[0.2em] border-b border-aura-border pb-2">Behavioral Observations</h4>
                    <ul className="space-y-3">
                      {[
                        'Attempts to communicate with known malicious C2 IP addresses.',
                        'Self-replication detected in secondary memory segments.',
                        'Modifies system boot sequences to maintain persistence.',
                        'Encrypted payload detected in process memory space.',
                      ].map((obs, i) => (
                        <li key={i} className="flex gap-3 text-[10px] text-gray-400 group">
                          <ChevronRight className="w-3 h-3 text-aura-cyan mt-0.5 group-hover:translate-x-1 transition-transform" />
                          <span>{obs}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-40">
                  <FileSearch className="w-16 h-16 text-gray-600" />
                  <div className="max-w-[200px]">
                    <h3 className="text-sm font-bold text-gray-500 uppercase">No Artifact Selected</h3>
                    <p className="text-[10px] text-gray-600 font-mono mt-1 italic">Select an artifact from the explorer to view detailed forensic intelligence and behavior mappings.</p>
                  </div>
                </div>
              )}
            </div>

            {selectedArtifact && (
              <div className="p-4 bg-aura-card border-t border-aura-border grid grid-cols-2 gap-2">
                <button className="flex items-center justify-center gap-2 p-2 bg-aura-cyan/10 border border-aura-cyan/30 rounded text-aura-cyan text-[10px] font-bold hover:bg-aura-cyan/20 transition-all font-mono">
                   DOWNLOAD_DUMP
                </button>
                <button className="flex items-center justify-center gap-2 p-2 bg-aura-red/10 border border-aura-red/30 rounded text-aura-red text-[10px] font-bold hover:bg-aura-red/20 transition-all font-mono">
                   EXEC_REMEDIATION
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
