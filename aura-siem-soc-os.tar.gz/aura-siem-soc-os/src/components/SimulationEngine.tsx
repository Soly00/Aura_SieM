import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Crosshair, 
  Shield, 
  Terminal, 
  Activity, 
  Zap, 
  Lock, 
  Unlock, 
  AlertTriangle,
  Play,
  RotateCcw,
  BarChart2
} from 'lucide-react';
import { cn } from '../lib/utils';

interface AttackStep {
  id: string;
  name: string;
  technique: string;
  status: 'pending' | 'success' | 'blocked' | 'detected';
  blueResponse?: string;
}

export default function SimulationEngine() {
  const [isRunning, setIsRunning] = useState(false);
  const [activeTab, setActiveTab] = useState<'red' | 'blue'>('red');
  const [steps, setSteps] = useState<AttackStep[]>([
    { id: '1', name: 'Reconnaissance', technique: 'T1595', status: 'pending' },
    { id: '2', name: 'Initial Access', technique: 'T1566', status: 'pending' },
    { id: '3', name: 'Execution', technique: 'T1059', status: 'pending' },
    { id: '4', name: 'Persistence', technique: 'T1547', status: 'pending' },
    { id: '5', name: 'Lateral Movement', technique: 'T1021', status: 'pending' },
    { id: '6', name: 'Exfiltration', technique: 'T1041', status: 'pending' },
  ]);

  const [redScore, setRedScore] = useState(0);
  const [blueScore, setBlueScore] = useState(0);

  const startSimulation = () => {
    setIsRunning(true);
    setRedScore(0);
    setBlueScore(0);
    setSteps(prev => prev.map(s => ({ ...s, status: 'pending', blueResponse: undefined })));
  };

  useEffect(() => {
    if (!isRunning) return;

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep >= steps.length) {
        setIsRunning(false);
        clearInterval(interval);
        return;
      }

      setSteps(prev => {
        const newSteps = [...prev];
        const success = Math.random() > 0.3;
        const detected = Math.random() > 0.4;

        if (success) {
          newSteps[currentStep].status = 'success';
          setRedScore(s => s + 15);
        } else {
          newSteps[currentStep].status = 'blocked';
          newSteps[currentStep].blueResponse = 'XDR_HEURISTIC_BLOCK';
          setBlueScore(s => s + 20);
        }

        if (detected) {
          setBlueScore(s => s + 10);
        }

        return newSteps;
      });

      currentStep++;
    }, 2500);

    return () => clearInterval(interval);
  }, [isRunning, steps.length]);

  return (
    <div className="h-full w-full p-6 flex flex-col gap-6 overflow-hidden">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Zap className="w-6 h-6 text-aura-cyan" />
          <h1 className="text-xl font-bold tracking-tight text-white uppercase">Red vs Blue Engagement_Sim</h1>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex bg-aura-card border border-aura-border rounded p-1">
            <button 
              onClick={() => setActiveTab('red')}
              className={cn(
                "px-4 py-1.5 rounded text-[10px] font-mono uppercase transition-all",
                activeTab === 'red' ? "bg-aura-red/20 text-aura-red" : "text-gray-500"
              )}
            >
              Red Team (Attacker)
            </button>
            <button 
               onClick={() => setActiveTab('blue')}
              className={cn(
                "px-4 py-1.5 rounded text-[10px] font-mono uppercase transition-all",
                activeTab === 'blue' ? "bg-aura-cyan/20 text-aura-cyan" : "text-gray-500"
              )}
            >
              Blue Team (Defender)
            </button>
          </div>
          
          <button 
            onClick={isRunning ? () => setIsRunning(false) : startSimulation}
            className={cn(
              "flex items-center gap-2 px-4 py-1.5 rounded border font-mono text-xs font-bold transition-all",
              isRunning 
                ? "bg-aura-red/10 border-aura-red/30 text-aura-red hover:bg-aura-red/20" 
                : "bg-aura-cyan/10 border-aura-cyan/30 text-aura-cyan hover:bg-aura-cyan/20"
            )}
          >
            {isRunning ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {isRunning ? 'RESET_SIM' : 'START_ENGAGEMENT'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6 flex-1 min-h-0">
        <div className="col-span-8 flex flex-col gap-6 min-h-0">
          <div className="tactical-card flex-1 p-6 relative overflow-hidden backdrop-blur-md">
            <div className="panel-header mb-6">
              <span className="panel-title">Real_Time_Engagement_Flow</span>
              <div className="flex items-center gap-4">
                 <div className="flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full bg-aura-red" />
                   <span className="text-[10px] text-gray-400 font-mono">Red: {redScore}</span>
                 </div>
                 <div className="flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full bg-aura-cyan" />
                   <span className="text-[10px] text-gray-400 font-mono">Blue: {blueScore}</span>
                 </div>
              </div>
            </div>

            <div className="space-y-8 relative">
               {/* Connecting Line */}
               <div className="absolute left-6 top-8 bottom-8 w-[1px] bg-aura-border pointer-events-none" />

               {steps.map((step, i) => (
                 <motion.div 
                   key={step.id}
                   initial={{ opacity: 0, x: -20 }}
                   animate={{ opacity: 1, x: 0 }}
                   transition={{ delay: i * 0.1 }}
                   className="flex items-center gap-6 relative group"
                 >
                   <div className={cn(
                     "w-12 h-12 rounded-full border-2 flex items-center justify-center bg-aura-bg z-10 transition-all",
                     step.status === 'success' ? "border-aura-red glow-red shadow-[0_0_15px_rgba(255,62,62,0.4)]" :
                     step.status === 'blocked' ? "border-aura-cyan shadow-[0_0_15px_rgba(15,240,252,0.4)]" :
                     "border-aura-border"
                   )}>
                     {step.status === 'success' ? <Crosshair className="w-5 h-5 text-aura-red" /> :
                      step.status === 'blocked' ? <Shield className="w-5 h-5 text-aura-cyan" /> :
                      <Activity className="w-5 h-5 text-gray-700" />}
                   </div>

                   <div className="flex-1 p-4 rounded-lg bg-white/5 border border-aura-border group-hover:border-white/10 transition-colors">
                     <div className="flex items-center justify-between mb-1">
                       <h3 className="text-sm font-bold text-white tracking-tight uppercase">{step.name}</h3>
                       <span className="text-[10px] text-gray-500 font-mono uppercase">{step.technique}</span>
                     </div>
                     <p className="text-xs text-gray-400 italic">
                       {step.status === 'pending' ? 'Operational stage in standby...' : 
                        step.status === 'success' ? 'Initial entry successful. Moving to next phase.' :
                        'Attack vector identified and neutralized by platform heuristics.'}
                     </p>
                   </div>

                   <AnimatePresence>
                     {step.blueResponse && (
                       <motion.div 
                         initial={{ opacity: 0, scale: 0.8, x: 20 }}
                         animate={{ opacity: 1, scale: 1, x: 0 }}
                         className="px-3 py-1.5 rounded bg-aura-cyan text-black font-bold text-[10px] font-mono uppercase tracking-widest absolute -right-4 top-1/2 -translate-y-1/2 rotate-3"
                       >
                         {step.blueResponse}
                       </motion.div>
                     )}
                   </AnimatePresence>
                 </motion.div>
               ))}
            </div>
          </div>
        </div>

        <div className="col-span-4 flex flex-col gap-6">
          <div className="tactical-card p-6 flex flex-col gap-6">
             <div className="panel-header mb-2">
               <span className="panel-title">Tactical_Intelligence</span>
             </div>
             
             <div className="space-y-4">
                <div className="p-4 bg-white/5 border border-aura-border rounded space-y-2">
                   <div className="flex items-center gap-2 text-aura-red">
                     <AlertTriangle className="w-4 h-4" />
                     <span className="text-xs font-bold uppercase font-mono">MITRE_ADVISORY</span>
                   </div>
                   <p className="text-[11px] text-gray-400 leading-relaxed">
                     Engagement emulating APT-29 behavioral patterns. Focus on DLL side-loading and memory-only execution vectors.
                   </p>
                </div>

                <div className="space-y-2">
                   <span className="text-[10px] text-gray-600 font-mono uppercase">Defense Effectiveness</span>
                   <div className="flex items-center gap-4">
                      <div className="flex-1 h-2 bg-white/5 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${(blueScore / (redScore + blueScore + 1)) * 100}%` }}
                          className="h-full bg-aura-cyan"
                        />
                      </div>
                      <span className="text-xs font-mono text-aura-cyan">{Math.round((blueScore / (redScore + blueScore + 1)) * 100)}%</span>
                   </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4">
                   <div className="p-3 bg-aura-red/5 border border-aura-red/20 rounded">
                      <span className="text-[10px] text-gray-500 block mb-1">Red Success</span>
                      <span className="text-xl font-bold text-aura-red font-mono">{redScore}</span>
                   </div>
                   <div className="p-3 bg-aura-cyan/5 border border-aura-cyan/20 rounded">
                      <span className="text-[10px] text-gray-500 block mb-1">Blue Defend</span>
                      <span className="text-xl font-bold text-aura-cyan font-mono">{blueScore}</span>
                   </div>
                </div>
             </div>
          </div>

          <div className="tactical-card flex-1 p-6 relative overflow-hidden">
            <div className="panel-header mb-4">
               <span className="panel-title border-aura-red/50">Sim_Telemetry_Logs</span>
            </div>
            <div className="space-y-2 font-mono text-[10px] text-gray-500 italic">
               {steps.filter(s => s.status !== 'pending').map((s) => (
                 <div key={s.id} className="p-2 border-b border-aura-border/50 flex flex-col gap-1">
                   <div className="flex justify-between">
                     <span className={s.status === 'success' ? 'text-aura-red' : 'text-aura-cyan'}>
                       {s.status.toUpperCase()}
                     </span>
                     <span>T12:04:11Z</span>
                   </div>
                   <div className="text-gray-400 truncate">
                     {s.technique}: Executing heuristic payload on endpoint 04...
                   </div>
                 </div>
               ))}
               {!isRunning && steps.every(s => s.status === 'pending') && (
                 <div className="h-full flex items-center justify-center opacity-30 uppercase tracking-[0.2em] py-20">
                   Waiting for initialization...
                 </div>
               )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
