import { useState } from 'react';
import { MOCK_THREAT_INTEL } from '../mockData';
import { 
  Zap, 
  ShieldAlert, 
  Activity, 
  ExternalLink, 
  RefreshCw,
  Search,
  Filter,
  ShieldCheck,
  AlertTriangle,
  Radio,
  FileText
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

export default function ThreatFeed() {
  const [intel, setIntel] = useState(MOCK_THREAT_INTEL);
  const [activeTab, setActiveTab] = useState<'indicators' | 'actors' | 'cves'>('indicators');

  const cves = [
    { id: 'CVE-2024-3400', risk: 'Critical', score: 10.0, description: 'Palo Alto Networks PAN-OS command injection vulnerability.', status: 'Active Exploit' },
    { id: 'CVE-2024-21887', risk: 'Critical', score: 9.1, description: 'Ivanti Connect Secure command injection.', status: 'Mass Exploitation' },
    { id: 'CVE-2023-46604', risk: 'High', score: 8.8, description: 'Apache ActiveMQ RCE exploit used by HelloKitty ransomware.', status: 'Monitoring' },
    { id: 'CVE-2024-38077', risk: 'Critical', score: 9.8, description: 'Windows Remote Desktop Licensing Service RCE.', status: 'Patch Now' },
  ];

  return (
    <div className="h-full w-full p-6 flex flex-col gap-6 overflow-hidden">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Zap className="w-6 h-6 text-aura-yellow" />
          <h1 className="text-xl font-bold tracking-tight text-white">INTELLIGENT_THREAT_FEEDS</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex bg-aura-card border border-aura-border rounded p-1">
            {['indicators', 'actors', 'cves'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={cn(
                  "px-4 py-1.5 rounded text-[10px] font-mono uppercase tracking-widest transition-all",
                  activeTab === tab ? "bg-aura-cyan/10 text-aura-cyan" : "text-gray-500 hover:text-gray-300"
                )}
              >
                {tab}
              </button>
            ))}
          </div>
          <button className="p-2 bg-white/5 border border-aura-border rounded hover:bg-white/10 transition-all text-aura-cyan">
             <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6 flex-1 min-h-0">
        {/* Left Column: Feed Content */}
        <div className="col-span-12 lg:col-span-8 flex flex-col gap-6 min-h-0">
          <div className="tactical-card flex-1 flex flex-col min-h-0">
            <div className="panel-header">
               <div className="flex items-center gap-4 flex-1">
                 <Radio className="w-3 h-3 text-aura-red animate-pulse" />
                 <span className="panel-title">LIVE_IO_INDICATOR_STREAM</span>
                 <div className="relative flex-1 max-w-xs">
                   <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-500" />
                   <input 
                    type="text" 
                    placeholder="Search IOCs, Hashes, IP Ranges..."
                    className="w-full bg-black/50 border border-aura-border rounded px-8 py-1.5 text-xs font-mono outline-none"
                   />
                 </div>
               </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              <AnimatePresence mode="wait">
                {activeTab === 'indicators' && (
                  <motion.div 
                    key="indicators"
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }} 
                    className="p-4 space-y-4"
                  >
                    {intel.map((item) => (
                      <div key={item.id} className="p-4 bg-white/5 border border-aura-border rounded-lg group hover:border-aura-cyan/30 transition-all">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex items-center gap-3">
                             <div className="px-2 py-0.5 bg-aura-cyan/10 border border-aura-cyan/30 text-aura-cyan text-[8px] font-mono rounded">
                               {item.type.toUpperCase()}
                             </div>
                             <span className="text-sm font-bold text-white font-mono tracking-tight">{item.indicator}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-gray-500 font-mono">CONFIDENCE:</span>
                            <span className={cn(
                              "text-[10px] font-bold font-mono",
                              item.confidence > 90 ? "text-aura-red" : "text-aura-green"
                            )}>{item.confidence}%</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-[10px] text-gray-500 font-mono">
                          {item.threat_actor && (
                             <span className="flex items-center gap-1"><ShieldAlert className="w-3 h-3 text-aura-red" /> {item.threat_actor}</span>
                          )}
                          <span className="flex items-center gap-1"><Activity className="w-3 h-3 text-aura-cyan" /> Last Seen: {item.last_seen}</span>
                          <div className="flex-1" />
                          <div className="flex gap-2">
                            {item.tags.map(tag => (
                              <span key={tag} className="px-2 py-0.5 bg-white/5 border border-white/10 rounded text-gray-400 text-[8px]">{tag}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </motion.div>
                )}

                {activeTab === 'cves' && (
                  <motion.div 
                    key="cves"
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }}
                    className="p-4 space-y-4"
                  >
                    {cves.map((cve) => (
                      <div key={cve.id} className="p-4 bg-white/5 border border-aura-border rounded-lg flex gap-4">
                         <div className="flex flex-col items-center justify-center p-3 bg-aura-red/10 border border-aura-red/30 rounded w-20">
                            <span className="text-[8px] text-gray-500 font-mono uppercase mb-1">CVSS</span>
                            <span className="text-lg font-bold text-aura-red font-mono leading-none">{cve.score}</span>
                         </div>
                         <div className="flex-1 space-y-2">
                            <div className="flex justify-between items-center">
                               <h3 className="text-sm font-bold text-white font-mono">{cve.id}</h3>
                               <span className="px-2 py-0.5 bg-aura-yellow/20 border border-aura-yellow/30 text-aura-yellow text-[8px] font-mono rounded uppercase">{cve.status}</span>
                            </div>
                            <p className="text-[11px] text-gray-400 font-sans leading-relaxed">{cve.description}</p>
                            <div className="flex gap-4 pt-1">
                               <button className="text-[10px] text-aura-cyan hover:underline flex items-center gap-1 font-mono uppercase tracking-widest transition-all">VIEW_ADVISORY <ExternalLink className="w-3 h-3" /></button>
                               <button className="text-[10px] text-aura-cyan hover:underline flex items-center gap-1 font-mono uppercase tracking-widest transition-all">POC_ANALYSIS <FileText className="w-3 h-3" /></button>
                            </div>
                         </div>
                      </div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Right Column: Summaries & Stats */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-6 min-h-0">
          <div className="tactical-card p-6 space-y-6">
            <div className="panel-header mb-4">
               <span className="panel-title">THREAT_FEED_HEALTH</span>
            </div>
            
            <div className="space-y-6">
              {[
                { label: 'AlienVault OTX', status: 'Healthy', icon: ShieldCheck, color: 'text-aura-green' },
                { label: 'ThreatConnect', status: 'Syncing', icon: RefreshCw, color: 'text-aura-cyan' },
                { label: 'MISP Core', status: 'Healthy', icon: ShieldCheck, color: 'text-aura-green' },
                { label: 'CrowdStrike Intel', status: 'Auth Error', icon: AlertTriangle, color: 'text-aura-red' },
              ].map(feed => (
                <div key={feed.label} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <feed.icon className={cn("w-4 h-4", feed.color)} />
                    <span className="text-xs text-white font-medium">{feed.label}</span>
                  </div>
                  <span className={cn("text-[9px] font-mono uppercase tracking-widest", feed.color)}>{feed.status}</span>
                </div>
              ))}
            </div>

            <div className="pt-6 border-t border-aura-border space-y-4">
               <h4 className="text-[10px] text-gray-500 font-mono uppercase tracking-[0.2em]">INTELLIGENCE_INSIGHTS</h4>
               <p className="text-xs text-gray-400 leading-relaxed italic">
                 "Recent surge in ${activeTab === 'cves' ? 'RCE exploits' : 'TOR exit node traffic'} targeting manufacturing sector. Possible pre-campaign reconnaissance by APT-37 observed."
               </p>
               <div className="p-3 bg-aura-cyan/5 border border-aura-cyan/20 rounded">
                 <div className="flex items-center gap-2 mb-2">
                   <ShieldAlert className="w-3 h-3 text-aura-cyan" />
                   <span className="text-[10px] font-bold text-aura-cyan uppercase font-mono">Aura AI Recommendation</span>
                 </div>
                 <p className="text-[10px] text-gray-400 font-mono">
                   Enhance monitoring on ports 443/8443 for unusual encrypted heartbeats. Cross-reference with Geo-IP impossible travel alerts.
                 </p>
               </div>
            </div>
          </div>

          <div className="tactical-card p-4 h-48 bg-aura-red/5 border-aura-red/20">
             <div className="flex items-center gap-3 mb-4">
               <AlertTriangle className="w-5 h-5 text-aura-red animate-pulse" />
               <span className="text-[10px] font-bold text-aura-red font-mono uppercase tracking-widest">Active Ransomware Alert</span>
             </div>
             <div className="space-y-2">
               <div className="flex justify-between text-[10px] font-mono text-white">
                 <span>Family:</span>
                 <span className="text-aura-red uppercase">LockBit 3.0</span>
               </div>
               <div className="flex justify-between text-[10px] font-mono text-white">
                 <span>Variant:</span>
                 <span className="text-aura-red">v2.1.4_BLACK</span>
               </div>
               <div className="flex justify-between text-[10px] font-mono text-white">
                 <span>Targets:</span>
                 <span className="text-aura-red">Windows Server 2022</span>
               </div>
               <button className="w-full mt-4 py-2 bg-aura-red text-white font-bold text-[10px] font-mono rounded hover:brightness-110 transition-all uppercase">
                  DEPLOY_BLOCKLIST
               </button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
