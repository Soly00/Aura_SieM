import { AnalystRole } from '../types';
import { User, Shield, Briefcase, Zap } from 'lucide-react';
import { cn } from '../lib/utils';

export const ROLES: AnalystRole[] = [
  { id: 'analyst', name: 'SOC Analyst', permissions: ['investigate', 'respond', 'forensics'] },
  { id: 'manager', name: 'SOC Manager', permissions: ['approve', 'assign', 'report'] },
  { id: 'ciso', name: 'CISO / Executive', permissions: ['risk_overview', 'compliance', 'executive_summary'] },
  { id: 'mssp', name: 'MSSP Partner', permissions: ['customer_view', 'tenant_management'] },
];

interface Props {
  currentRole: AnalystRole;
  onRoleChange: (role: AnalystRole) => void;
}

export default function RoleSwitcher({ currentRole, onRoleChange }: Props) {
  return (
    <div className="flex bg-aura-card border border-aura-border rounded-lg p-1">
      {ROLES.map((role) => (
        <button
          key={role.id}
          onClick={() => onRoleChange(role)}
          className={cn(
            "flex items-center gap-2 px-3 py-1.5 rounded text-[10px] font-mono uppercase tracking-widest transition-all",
            currentRole.id === role.id ? "bg-aura-cyan/10 text-aura-cyan" : "text-gray-500 hover:text-gray-300"
          )}
        >
          {role.id === 'analyst' && <User className="w-3 h-3" />}
          {role.id === 'manager' && <Briefcase className="w-3 h-3" />}
          {role.id === 'ciso' && <Shield className="w-3 h-3" />}
          {role.id === 'mssp' && <Zap className="w-3 h-3" />}
          {role.name.split(' ')[0]}
        </button>
      ))}
    </div>
  );
}
