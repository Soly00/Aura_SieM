import { Shield, Target, Zap, AlertTriangle } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

const TECHNIQUES = [
  { id: 'T1566', name: 'Phishing', category: 'Initial Access', active: true },
  { id: 'T1059', name: 'Command & Scripting Interpreter', category: 'Execution', active: true },
  { id: 'T1547', name: 'Boot or Logon Autostart', category: 'Persistence', active: false },
  { id: 'T1053', name: 'Scheduled Task/Job', category: 'Execution', active: false },
  { id: 'T1110', name: 'Brute Force', category: 'Credential Access', active: true },
  { id: 'T1021', name: 'Remote Services', category: 'Lateral Movement', active: true },
  { id: 'T1041', name: 'Exfiltration Over C2 Channel', category: 'Exfiltration', active: false },
  { id: 'T1486', name: 'Data Encrypted for Impact', category: 'Impact', active: true },
];

export default function MitreAttackGrid() {
  return (
    <div className="flex flex-col h-full">
      <div className="panel-header">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4 text-aura-red" />
          <span className="panel-title">MITRE_ATT&CK_DETECTION_COVERAGE</span>
        </div>
      </div>
      
      <div className="flex-1 p-4 grid grid-cols-2 lg:grid-cols-4 gap-3 bg-black/20">
        {TECHNIQUES.map((tech) => (
          <motion.div 
            key={tech.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={cn(
              "p-3 rounded border flex flex-col gap-2 transition-all",
              tech.active 
                ? "bg-aura-red/5 border-aura-red/30" 
                : "bg-white/5 border-aura-border opacity-50 grayscale"
            )}
          >
            <div className="flex justify-between items-start">
              <span className="text-[10px] font-mono text-aura-red font-bold">{tech.id}</span>
              {tech.active && <div className="w-1.5 h-1.5 rounded-full bg-aura-red animate-pulse" />}
            </div>
            <div>
              <div className="text-[11px] font-bold text-white truncate">{tech.name}</div>
              <div className="text-[9px] text-gray-500 font-mono uppercase truncate">{tech.category}</div>
            </div>
          </motion.div>
        ))}
      </div>
      <div className="p-3 border-t border-aura-border bg-aura-bg/50 flex items-center justify-between">
        <span className="text-[10px] text-gray-600 font-mono">COVERAGE_INDEX: 72%</span>
        <button className="text-[10px] text-aura-cyan font-mono hover:underline uppercase tracking-widest">View_Full_Matrix</button>
      </div>
    </div>
  );
}
