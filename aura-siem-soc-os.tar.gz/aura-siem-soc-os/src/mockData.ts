import { Threat, SecurityEvent, ForensicArtifact, ThreatIntel } from './types';
import { generateId, formatTimestamp } from './lib/utils';

const LOCATIONS = [
  { name: 'New York', lat: 40.7128, lng: -74.0060 },
  { name: 'London', lat: 51.5074, lng: -0.1278 },
  { name: 'Tokyo', lat: 35.6762, lng: 139.6503 },
  { name: 'Berlin', lat: 52.5200, lng: 13.4050 },
  { name: 'Sydney', lat: -33.8688, lng: 151.2093 },
  { name: 'Moscow', lat: 55.7558, lng: 37.6173 },
  { name: 'Beijing', lat: 39.9042, lng: 116.4074 },
  { name: 'Paris', lat: 48.8566, lng: 2.3522 },
  { name: 'Sao Paulo', lat: -23.5505, lng: -46.6333 },
  { name: 'Dubai', lat: 25.2048, lng: 55.2708 },
];

const THREAT_TYPES = [
  'DDoS Attack',
  'SQL Injection',
  'Brute Force',
  'Ransomware Callback',
  'Exfiltration Detected',
  'Zero-Day Exploit',
  'Credential Spraying',
];

export function generateRandomThreat(): Threat {
  const sourceIdx = Math.floor(Math.random() * LOCATIONS.length);
  const targetIdx = Math.floor(Math.random() * LOCATIONS.length);
  const severity: any = ['low', 'medium', 'high', 'critical'][Math.floor(Math.random() * 4)];
  
  return {
    id: generateId(),
    type: THREAT_TYPES[Math.floor(Math.random() * THREAT_TYPES.length)],
    source: LOCATIONS[sourceIdx].name,
    target: LOCATIONS[targetIdx].name,
    lat: LOCATIONS[sourceIdx].lat,
    lng: LOCATIONS[sourceIdx].lng,
    targetLat: LOCATIONS[targetIdx].lat,
    targetLng: LOCATIONS[targetIdx].lng,
    timestamp: new Date().toLocaleTimeString(),
    severity,
    description: `Suspicious activity detected from ${LOCATIONS[sourceIdx].name} targeting ${LOCATIONS[targetIdx].name}.`,
    status: 'active'
  };
}

export function generateRandomEvent(): SecurityEvent {
  const types = ['LOGON', 'FILE_ACCESS', 'PROCESS_START', 'CORE_DUMP', 'NETWORK_CONN'];
  const cats = ['Authentication', 'Object Access', 'Detailed Tracking', 'System', 'Network'];
  const severities: any = ['low', 'medium', 'high', 'critical'];
  
  return {
    id: generateId(),
    timestamp: formatTimestamp(),
    source: `SRV-CORP-${Math.floor(Math.random() * 999)}`,
    event_type: types[Math.floor(Math.random() * types.length)],
    user: ['admin', 'syssvc', 'jsmith', 'rdoe', 'root'][Math.floor(Math.random() * 5)],
    category: cats[Math.floor(Math.random() * cats.length)],
    details: 'System event triggered by process ' + Math.floor(Math.random() * 65535),
    severity: severities[Math.floor(Math.random() * 4)],
  };
}

export const MOCK_FORENSICS: ForensicArtifact[] = [
  { id: '1', name: 'svchost.exe', type: 'process', path: 'C:\\Windows\\System32', timestamp: '2024-05-08 14:20:01', suspicious: true, score: 85, hash: 'SHA256: 4f8e...39d2' },
  { id: '2', name: 'payload.bin', type: 'file', path: 'C:\\Users\\Public\\Downloads', timestamp: '2024-05-08 14:22:15', suspicious: true, score: 98, hash: 'MD5: e99...f1a' },
  { id: '3', name: 'RunOnce', type: 'registry', path: 'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion', timestamp: '2024-05-08 14:18:45', suspicious: true, score: 92 },
  { id: '4', name: 'lsass.exe', type: 'process', path: 'C:\\Windows\\System32', timestamp: '2024-05-08 14:15:22', suspicious: false, score: 10 },
];

export const MOCK_THREAT_INTEL: ThreatIntel[] = [
  { id: 'TI-1', indicator: '192.168.1.105', type: 'ip', threat_actor: 'APT28', confidence: 95, first_seen: '2024-01-10', last_seen: '2024-05-08', tags: ['C2', 'Known Bad'] },
  { id: 'TI-2', indicator: 'pwned.online', type: 'domain', threat_actor: 'Unknown', confidence: 80, first_seen: '2024-04-15', last_seen: '2024-05-07', tags: ['Phishing'] },
  { id: 'TI-3', indicator: 'd41d8cd98f00b204e9800998ecf8427e', type: 'hash', confidence: 100, first_seen: '2023-12-01', last_seen: '2024-05-01', tags: ['Malware', 'Ransomware'] },
];
