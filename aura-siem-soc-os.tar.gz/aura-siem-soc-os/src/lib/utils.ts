import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTimestamp(date: Date = new Date()) {
  return date.toISOString().replace('T', ' ').substring(0, 19);
}

export function generateId() {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

export function getSeverityColor(severity: string) {
  switch (severity.toLowerCase()) {
    case 'critical': return 'text-aura-red';
    case 'high': return 'text-orange-500';
    case 'medium': return 'text-aura-yellow';
    case 'low': return 'text-aura-green';
    default: return 'text-gray-400';
  }
}

export function getSeverityBg(severity: string) {
  switch (severity.toLowerCase()) {
    case 'critical': return 'bg-aura-red/20 border-aura-red/50';
    case 'high': return 'bg-orange-500/20 border-orange-500/50';
    case 'medium': return 'bg-aura-yellow/20 border-aura-yellow/50';
    case 'low': return 'bg-aura-green/20 border-aura-green/50';
    default: return 'bg-gray-500/20 border-gray-500/50';
  }
}
