-- AURA NEXUS SOC OS - Multi-Tenant Database Schema
-- PostgreSQL Schema with Tenant Isolation

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "btree_gin";

-- ============================================================================
-- GLOBAL SCHEMA (Platform Level)
-- ============================================================================

-- Platform configuration and super admin data
CREATE SCHEMA IF NOT EXISTS platform;

-- Tenants table (global)
CREATE TABLE platform.tenants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_code VARCHAR(20) UNIQUE NOT NULL, -- e.g., T-001
    name VARCHAR(255) NOT NULL,
    domain VARCHAR(255),
    region VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'trial', 'terminated')),
    subscription_plan VARCHAR(50) NOT NULL DEFAULT 'enterprise',
    max_users INTEGER DEFAULT 1000,
    max_events_per_day BIGINT DEFAULT 10000000,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID,
    metadata JSONB DEFAULT '{}',
    
    -- Security and compliance
    compliance_standards TEXT[] DEFAULT '{}', -- GDPR, HIPAA, PCI-DSS, etc.
    data_retention_days INTEGER DEFAULT 365,
    encryption_key_id VARCHAR(255),
    
    -- Billing and limits
    storage_quota_gb BIGINT DEFAULT 1000,
    api_rate_limit INTEGER DEFAULT 10000,
    
    CONSTRAINT tenants_name_check CHECK (length(name) >= 2)
);

-- Platform users (super admins)
CREATE TABLE platform.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'super_admin',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    mfa_secret VARCHAR(255),
    mfa_enabled BOOLEAN DEFAULT FALSE,
    api_key VARCHAR(255) UNIQUE,
    permissions JSONB DEFAULT '{}',
    
    CONSTRAINT users_role_check CHECK (role IN ('super_admin', 'platform_admin', 'support'))
);

-- Platform audit log
CREATE TABLE platform.audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES platform.tenants(id),
    user_id UUID REFERENCES platform.users(id),
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_id VARCHAR(255),
    details JSONB DEFAULT '{}',
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    INDEX audit_log_tenant_idx (tenant_id),
    INDEX audit_log_user_idx (user_id),
    INDEX audit_log_timestamp_idx (timestamp)
);

-- ============================================================================
-- TENANT SCHEMA TEMPLATE
-- ============================================================================

-- Function to create tenant-specific schema
CREATE OR REPLACE FUNCTION platform.create_tenant_schema(tenant_code VARCHAR(20))
RETURNS VOID AS $$
DECLARE
    schema_name TEXT;
BEGIN
    schema_name := 'tenant_' || lower(replace(tenant_code, '-', '_'));
    
    EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I', schema_name);
    
    -- Create tables in tenant schema
    EXECUTE format('
        -- Users table (tenant-specific)
        CREATE TABLE %I.users (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            email VARCHAR(255) UNIQUE NOT NULL,
            username VARCHAR(100) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            full_name VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL DEFAULT ''tier1_analyst'',
            department VARCHAR(100),
            status VARCHAR(20) NOT NULL DEFAULT ''active'',
            last_login TIMESTAMP WITH TIME ZONE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            mfa_secret VARCHAR(255),
            mfa_enabled BOOLEAN DEFAULT FALSE,
            api_key VARCHAR(255) UNIQUE,
            phone VARCHAR(50),
            manager_id UUID REFERENCES %I.users(id),
            permissions JSONB DEFAULT ''{}'',
            preferences JSONB DEFAULT ''{}'',
            
            CONSTRAINT users_role_check CHECK (role IN (''super_admin'', ''soc_manager'', ''tier1_analyst'', ''tier2_analyst'', ''forensic_analyst'', ''ciso'', ''customer_admin'')),
            CONSTRAINT users_status_check CHECK (status IN (''active'', ''suspended'', ''pending'', ''inactive''))
        );
        
        -- Roles and permissions
        CREATE TABLE %I.roles (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            name VARCHAR(100) UNIQUE NOT NULL,
            description TEXT,
            permissions JSONB NOT NULL DEFAULT ''{}'',
            is_system_role BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );
        
        -- Security events
        CREATE TABLE %I.security_events (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            event_id VARCHAR(255) UNIQUE NOT NULL, -- External event ID
            timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
            event_type VARCHAR(100) NOT NULL,
            source VARCHAR(255) NOT NULL,
            source_ip INET,
            destination_ip INET,
            user VARCHAR(255),
            hostname VARCHAR(255),
            process_name VARCHAR(255),
            process_id INTEGER,
            severity VARCHAR(20) NOT NULL DEFAULT ''medium'',
            category VARCHAR(100),
            title TEXT,
            description TEXT,
            details JSONB DEFAULT ''{}'',
            raw_log TEXT,
            normalized_data JSONB DEFAULT ''{}'',
            enrichment JSONB DEFAULT ''{}'',
            tags TEXT[] DEFAULT ''{}'',
            status VARCHAR(20) DEFAULT ''new'',
            assigned_to UUID REFERENCES %I.users(id),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            
            CONSTRAINT events_severity_check CHECK (severity IN (''low'', ''medium'', ''high'', ''critical'')),
            CONSTRAINT events_status_check CHECK (status IN (''new'', ''investigating'', ''resolved'', ''false_positive'', ''escalated''))
        );
        
        -- Incidents
        CREATE TABLE %I.incidents (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            incident_id VARCHAR(100) UNIQUE NOT NULL,
            title VARCHAR(500) NOT NULL,
            description TEXT,
            severity VARCHAR(20) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT ''open'',
            category VARCHAR(100),
            source_event_id UUID REFERENCES %I.security_events(id),
            assigned_to UUID REFERENCES %I.users(id),
            created_by UUID REFERENCES %I.users(id),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            resolved_at TIMESTAMP WITH TIME ZONE,
            resolution_details TEXT,
            impact_assessment JSONB DEFAULT ''{}'',
            mitre_tactics TEXT[] DEFAULT ''{}'',
            mitre_techniques TEXT[] DEFAULT ''{}'',
            
            CONSTRAINT incidents_severity_check CHECK (severity IN (''low'', ''medium'', ''high'', ''critical'')),
            CONSTRAINT incidents_status_check CHECK (status IN (''open'', ''investigating'', ''resolved'', ''closed'', ''escalated''))
        );
        
        -- Detection rules
        CREATE TABLE %I.detection_rules (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            name VARCHAR(500) NOT NULL,
            description TEXT,
            rule_type VARCHAR(50) NOT NULL DEFAULT ''sigma'',
            severity VARCHAR(20) NOT NULL,
            category VARCHAR(100),
            query TEXT NOT NULL,
            conditions JSONB DEFAULT ''{}'',
            false_positive_patterns TEXT[] DEFAULT ''{}'',
            mitre_tactics TEXT[] DEFAULT ''{}'',
            mitre_techniques TEXT[] DEFAULT ''{}'',
            status VARCHAR(20) DEFAULT ''active'',
            created_by UUID REFERENCES %I.users(id),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            last_triggered TIMESTAMP WITH TIME ZONE,
            trigger_count INTEGER DEFAULT 0,
            
            CONSTRAINT rules_severity_check CHECK (severity IN (''low'', ''medium'', ''high'', ''critical'')),
            CONSTRAINT rules_status_check CHECK (status IN (''active'', ''inactive'', ''testing'', ''deprecated''))
        );
        
        -- Alerts
        CREATE TABLE %I.alerts (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            alert_id VARCHAR(255) UNIQUE NOT NULL,
            rule_id UUID REFERENCES %I.detection_rules(id),
            event_id UUID REFERENCES %I.security_events(id),
            incident_id UUID REFERENCES %I.incidents(id),
            severity VARCHAR(20) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT ''open'',
            title VARCHAR(500) NOT NULL,
            description TEXT,
            details JSONB DEFAULT ''{}'',
            confidence_score DECIMAL(3,2) DEFAULT 0.5,
            risk_score INTEGER DEFAULT 50,
            assigned_to UUID REFERENCES %I.users(id),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            acknowledged_at TIMESTAMP WITH TIME ZONE,
            acknowledged_by UUID REFERENCES %I.users(id),
            
            CONSTRAINT alerts_severity_check CHECK (severity IN (''low'', ''medium'', ''high'', ''critical'')),
            CONSTRAINT alerts_status_check CHECK (status IN (''open'', ''acknowledged'', ''investigating'', ''resolved'', ''false_positive'')),
            CONSTRAINT alerts_confidence_check CHECK (confidence_score >= 0 AND confidence_score <= 1)
        );
        
        -- Threat intelligence
        CREATE TABLE %I.threat_intel (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            indicator VARCHAR(1000) NOT NULL,
            indicator_type VARCHAR(50) NOT NULL,
            threat_actor VARCHAR(255),
            malware_family VARCHAR(255),
            confidence DECIMAL(3,2) DEFAULT 0.5,
            severity VARCHAR(20) DEFAULT ''medium'',
            first_seen TIMESTAMP WITH TIME ZONE,
            last_seen TIMESTAMP WITH TIME ZONE,
            source VARCHAR(255),
            description TEXT,
            tags TEXT[] DEFAULT ''{}'',
            context JSONB DEFAULT ''{}'',
            active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            
            CONSTRAINT intel_type_check CHECK (indicator_type IN (''ip'', ''domain'', ''url'', ''hash'', ''email'', ''filename'', ''registry_key'')),
            CONSTRAINT intel_severity_check CHECK (severity IN (''low'', ''medium'', ''high'', ''critical'')),
            CONSTRAINT intel_confidence_check CHECK (confidence >= 0 AND confidence <= 1)
        );
        
        -- Forensic artifacts
        CREATE TABLE %I.forensic_artifacts (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            case_id UUID REFERENCES %I.incidents(id),
            artifact_type VARCHAR(50) NOT NULL,
            name VARCHAR(500) NOT NULL,
            path VARCHAR(1000),
            hash_md5 VARCHAR(32),
            hash_sha256 VARCHAR(64),
            size BIGINT,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL,
            modified_at TIMESTAMP WITH TIME ZONE,
            accessed_at TIMESTAMP WITH TIME ZONE,
            suspicious BOOLEAN DEFAULT FALSE,
            threat_score INTEGER DEFAULT 0,
            description TEXT,
            metadata JSONB DEFAULT ''{}'',
            collected_by UUID REFERENCES %I.users(id),
            collected_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            
            CONSTRAINT artifacts_type_check CHECK (artifact_type IN (''file'', ''registry'', ''process'', ''network'', ''memory'', ''prefetch'', ''amcache''))
        );
        
        -- System configuration
        CREATE TABLE %I.system_config (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            key VARCHAR(255) UNIQUE NOT NULL,
            value JSONB NOT NULL,
            description TEXT,
            category VARCHAR(100),
            is_sensitive BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_by UUID REFERENCES %I.users(id)
        );
        
        -- Data sources
        CREATE TABLE %I.data_sources (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            name VARCHAR(255) NOT NULL,
            type VARCHAR(100) NOT NULL,
            description TEXT,
            connection_string TEXT,
            status VARCHAR(20) DEFAULT ''active'',
            configuration JSONB DEFAULT ''{}'',
            last_ingestion TIMESTAMP WITH TIME ZONE,
            events_ingested BIGINT DEFAULT 0,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            
            CONSTRAINT sources_status_check CHECK (status IN (''active'', ''inactive'', ''error'', ''maintenance''))
        );
        
        -- Create indexes for performance
        CREATE INDEX %I.idx_events_timestamp ON %I.security_events(timestamp);
        CREATE INDEX %I.idx_events_severity ON %I.security_events(severity);
        CREATE INDEX %I.idx_events_status ON %I.security_events(status);
        CREATE INDEX %I.idx_events_user ON %I.security_events(user);
        CREATE INDEX %I.idx_events_source_ip ON %I.security_events(source_ip);
        CREATE INDEX %I.idx_events_category ON %I.security_events(category);
        CREATE INDEX %I.idx_events_gin_details ON %I.security_events USING GIN(details);
        CREATE INDEX %I.idx_events_gin_tags ON %I.security_events USING GIN(tags);
        
        CREATE INDEX %I.idx_incidents_status ON %I.incidents(status);
        CREATE INDEX %I.idx_incidents_severity ON %I.incidents(severity);
        CREATE INDEX %I.idx_incidents_assigned ON %I.incidents(assigned_to);
        
        CREATE INDEX %I.idx_alerts_status ON %I.alerts(status);
        CREATE INDEX %I.idx_alerts_severity ON %I.alerts(severity);
        CREATE INDEX %I.idx_alerts_assigned ON %I.alerts(assigned_to);
        CREATE INDEX %I.idx_alerts_created ON %I.alerts(created_at);
        
        CREATE INDEX %I.idx_threat_intel_indicator ON %I.threat_intel(indicator);
        CREATE INDEX %I.idx_threat_intel_type ON %I.threat_intel(indicator_type);
        CREATE INDEX %I.idx_threat_intel_active ON %I.threat_intel(active);
        
        CREATE INDEX %I.idx_forensic_case ON %I.forensic_artifacts(case_id);
        CREATE INDEX %I.idx_forensic_type ON %I.forensic_artifacts(artifact_type);
        CREATE INDEX %I.idx_forensic_suspicious ON %I.forensic_artifacts(suspicious);
    ', schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name);
    
    -- Insert default roles
    EXECUTE format('
        INSERT INTO %I.roles (name, description, permissions, is_system_role) VALUES
        (''super_admin'', ''Full system access'', {''dashboard'': true, ''logs'': true, ''incidents'': true, ''forensics'': true, ''threat_intel'': true, ''admin'': true, ''users'': true, ''rules'': true}, true),
        (''soc_manager'', ''SOC team management'', {''dashboard'': true, ''logs'': true, ''incidents'': true, ''forensics'': true, ''threat_intel'': true, ''users'': true, ''reports'': true}, true),
        (''tier2_analyst'', ''Advanced security analysis'', {''dashboard'': true, ''logs'': true, ''incidents'': true, ''forensics'': true, ''threat_intel'': true, ''rules'': true}, true),
        (''tier1_analyst'', ''Basic security triage'', {''dashboard'': true, ''logs'': true, ''incidents'': true}, true),
        (''forensic_analyst'', ''Digital forensics specialist'', {''dashboard'': true, ''incidents'': true, ''forensics'': true, ''threat_intel'': true}, true),
        (''ciso'', ''Executive oversight'', {''dashboard'': true, ''incidents'': true, ''threat_intel'': true, ''reports'': true}, true),
        (''customer_admin'', ''Tenant administration'', {''dashboard'': true, ''logs'': true, ''incidents'': true, ''threat_intel'': true, ''users'': true}, true);
    ', schema_name);
    
    -- Insert default configuration
    EXECUTE format('
        INSERT INTO %I.system_config (key, value, description, category) VALUES
        (''data_retention_days'', ''365'', ''Number of days to retain security events'', ''compliance''),
        (''alert_auto_assign'', ''false'', ''Automatically assign alerts to analysts'', ''automation''),
        (''threat_intel_auto_enrich'', ''true'', ''Automatically enrich events with threat intelligence'', ''automation''),
        (''ml_detection_enabled'', ''true'', ''Enable machine learning-based detection'', ''detection''),
        (''email_notifications'', ''true'', ''Enable email notifications for critical alerts'', ''notifications'');
    ', schema_name);
    
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGERS AND FUNCTIONS
-- ============================================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION platform.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at triggers to all tables
DO $$
DECLARE
    schema_name TEXT;
    table_name TEXT;
BEGIN
    FOR schema_name, table_name IN 
        SELECT schemaname, tablename 
        FROM pg_tables 
        WHERE schemaname LIKE 'tenant_%'
    LOOP
        EXECUTE format('CREATE TRIGGER update_%I_updated_at BEFORE UPDATE ON %I.%I FOR EACH ROW EXECUTE FUNCTION platform.update_updated_at_column()', 
                      table_name, schema_name, table_name);
    END LOOP;
END $$;

-- ============================================================================
-- VIEWS FOR COMMON QUERIES
-- ============================================================================

-- Function to create tenant-specific views
CREATE OR REPLACE FUNCTION platform.create_tenant_views(tenant_code VARCHAR(20))
RETURNS VOID AS $$
DECLARE
    schema_name TEXT;
BEGIN
    schema_name := 'tenant_' || lower(replace(tenant_code, '-', '_'));
    
    -- Create summary views
    EXECUTE format('
        CREATE OR REPLACE VIEW %I.v_incident_summary AS
        SELECT 
            i.id,
            i.incident_id,
            i.title,
            i.severity,
            i.status,
            i.created_at,
            i.assigned_to,
            u.full_name as assigned_name,
            COUNT(a.id) as alert_count,
            COUNT(e.id) as event_count
        FROM %I.incidents i
        LEFT JOIN %I.users u ON i.assigned_to = u.id
        LEFT JOIN %I.alerts a ON i.id = a.incident_id
        LEFT JOIN %I.security_events e ON i.id = e.id
        GROUP BY i.id, i.incident_id, i.title, i.severity, i.status, i.created_at, i.assigned_to, u.full_name;
        
        CREATE OR REPLACE VIEW %I.v_alert_summary AS
        SELECT 
            a.id,
            a.alert_id,
            a.title,
            a.severity,
            a.status,
            a.risk_score,
            a.confidence_score,
            a.created_at,
            a.assigned_to,
            u.full_name as assigned_name,
            r.name as rule_name,
            i.incident_id
        FROM %I.alerts a
        LEFT JOIN %I.users u ON a.assigned_to = u.id
        LEFT JOIN %I.detection_rules r ON a.rule_id = r.id
        LEFT JOIN %I.incidents i ON a.incident_id = i.id;
        
        CREATE OR REPLACE VIEW %I.v_threat_dashboard AS
        SELECT 
            COUNT(*) as total_events,
            COUNT(*) FILTER (WHERE severity = ''critical'') as critical_events,
            COUNT(*) FILTER (WHERE severity = ''high'') as high_events,
            COUNT(*) FILTER (WHERE severity = ''medium'') as medium_events,
            COUNT(*) FILTER (WHERE severity = ''low'') as low_events,
            COUNT(*) FILTER (WHERE status = ''new'') as new_events,
            COUNT(*) FILTER (WHERE status = ''investigating'') as investigating_events,
            COUNT(DISTINCT source) as unique_sources,
            COUNT(DISTINCT user) as unique_users
        FROM %I.security_events
        WHERE timestamp >= NOW() - INTERVAL ''24 hours'';
    ', schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name, schema_name);
    
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- SAMPLE DATA INSERTION
-- ============================================================================

-- Function to create sample tenant with data
CREATE OR REPLACE FUNCTION platform.create_sample_tenant(tenant_code VARCHAR(20), tenant_name VARCHAR(255))
RETURNS UUID AS $$
DECLARE
    tenant_id UUID;
    schema_name TEXT;
BEGIN
    -- Insert tenant
    INSERT INTO platform.tenants (tenant_code, name, region, status)
    VALUES (tenant_code, tenant_name, 'US-EAST-1', 'active')
    RETURNING id INTO tenant_id;
    
    -- Create schema
    PERFORM platform.create_tenant_schema(tenant_code);
    PERFORM platform.create_tenant_views(tenant_code);
    
    schema_name := 'tenant_' || lower(replace(tenant_code, '-', '_'));
    
    -- Insert sample users
    EXECUTE format('
        INSERT INTO %I.users (email, username, password_hash, full_name, role, department) VALUES
        (''admin@%s.com'', ''admin'', ''$2b$12$placeholder_hash'', ''SOC Administrator'', ''soc_manager'', ''Security''),
        (''analyst1@%s.com'', ''analyst1'', ''$2b$12$placeholder_hash'', ''John Smith'', ''tier2_analyst'', ''Security Operations''),
        (''analyst2@%s.com'', ''analyst2'', ''$2b$12$placeholder_hash'', ''Jane Doe'', ''tier1_analyst'', ''Security Operations''),
        (''forensic@%s.com'', ''forensic'', ''$2b$12$placeholder_hash'', ''Mike Wilson'', ''forensic_analyst'', ''Digital Forensics'');
    ', schema_name, tenant_code, tenant_code, tenant_code, tenant_code);
    
    -- Insert sample detection rules
    EXECUTE format('
        INSERT INTO %I.detection_rules (name, description, severity, category, query, mitre_techniques) VALUES
        (''Failed Login Brute Force'', ''Detects multiple failed login attempts from same source'', ''high'', ''Authentication'', ''event_type: ''login'' AND status: ''failed'' AND count_by_source > 10'', ARRAY[''T1110'']),
        (''Suspicious PowerShell Execution'', ''Detects potentially malicious PowerShell commands'', ''critical'', ''Execution'', ''event_type: ''process'' AND process_name: ''powershell.exe'' AND command_line LIKE ''% -enc %'''', ARRAY[''T1086'', ''T1027'']),
        (''Impossible Travel'', ''Detects logins from geographically impossible locations'', ''high'', ''Authentication'', ''event_type: ''login'' AND distance_between_logins > 1000'', ARRAY[''T1078'']),
        (''Privilege Escalation'', ''Detects attempts to escalate privileges'', ''critical'', ''Privilege Escalation'', ''event_type: ''process'' AND (command_line LIKE ''%whoami%'' OR command_line LIKE ''%net user%'')'', ARRAY[''T1068'']);
    ', schema_name);
    
    RETURN tenant_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- SECURITY FUNCTIONS
-- ============================================================================

-- Row Level Security (RLS) for tenant isolation
CREATE OR REPLACE FUNCTION platform.enable_rls_for_tenant(tenant_code VARCHAR(20))
RETURNS VOID AS $$
DECLARE
    schema_name TEXT;
BEGIN
    schema_name := 'tenant_' || lower(replace(tenant_code, '-', '_'));
    
    -- Enable RLS on all tables
    EXECUTE format('ALTER TABLE %I.users ENABLE ROW LEVEL SECURITY', schema_name);
    EXECUTE format('ALTER TABLE %I.security_events ENABLE ROW LEVEL SECURITY', schema_name);
    EXECUTE format('ALTER TABLE %I.incidents ENABLE ROW LEVEL SECURITY', schema_name);
    EXECUTE format('ALTER TABLE %I.alerts ENABLE ROW LEVEL SECURITY', schema_name);
    
    -- Add policies (simplified - in production, these would be more sophisticated)
    EXECUTE format('
        CREATE POLICY tenant_isolation ON %I.users
            FOR ALL TO authenticated_user
            USING (true);
    ', schema_name);
    
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

-- Global indexes
CREATE INDEX idx_tenants_status ON platform.tenants(status);
CREATE INDEX idx_tenants_region ON platform.tenants(region);
CREATE INDEX idx_audit_log_timestamp ON platform.audit_log(timestamp DESC);
CREATE INDEX idx_audit_log_tenant_timestamp ON platform.audit_log(tenant_id, timestamp DESC);

-- ============================================================================
-- MIGRATION HELPERS
-- ============================================================================

-- Function to add new tenant
CREATE OR REPLACE FUNCTION platform.add_tenant(tenant_code VARCHAR(20), tenant_name VARCHAR(255), region VARCHAR(50))
RETURNS UUID AS $$
DECLARE
    tenant_id UUID;
BEGIN
    -- Validate tenant code format
    IF tenant_code !~ '^T-[0-9]{3}$' THEN
        RAISE EXCEPTION 'Tenant code must be in format T-XXX';
    END IF;
    
    -- Create tenant
    tenant_id := platform.create_sample_tenant(tenant_code, tenant_name);
    
    -- Log the action
    INSERT INTO platform.audit_log (tenant_id, action, resource_type, details)
    VALUES (tenant_id, 'CREATE_TENANT', 'tenant', json_build_object('tenant_code', tenant_code, 'tenant_name', tenant_name));
    
    RETURN tenant_id;
END;
$$ LANGUAGE plpgsql;

-- Sample usage:
-- SELECT platform.add_tenant('T-004', 'New Company', 'US-WEST-2');
